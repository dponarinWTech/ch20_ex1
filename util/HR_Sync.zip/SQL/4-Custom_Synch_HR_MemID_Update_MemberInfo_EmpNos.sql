USE [MEMBERID]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ===============================================================================================
-- Author:        Dmitri Ponarin
-- Last modified: 01/23/2018
-- Description:	  Updates column EMPLOYEENUMBER in table "MemberInformation" based on information 
--                in the table "Update_EmpNo".
-- Execution:	  Will be called by application HR_Sync 
-- ===============================================================================================

IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Custom_Synch_HR_MemID_Update_MemberInfo_EmpNos')
    EXEC('CREATE PROCEDURE dbo.Custom_Synch_HR_MemID_Update_MemberInfo_EmpNos AS RETURN')

ALTER PROCEDURE [dbo].[Custom_Synch_HR_MemID_Update_MemberInfo_EmpNos]
(		
	@ReturnRowCounts	INT OUT,
	@ReturnResult		BIT OUT
)
AS
BEGIN
    SET ANSI_WARNINGS OFF 
	
	DECLARE @SysError				INT;
	DECLARE @SysRowCount1			INT; 
	DECLARE @SysRowCount2			INT;
	
	SET @SysError				= 0;
	SET @SysRowCount1			= 0;
	SET @SysRowCount2			= 0;
	
	BEGIN TRANSACTION SynchHRData
		-- Update incorrect EmpNos in MemberInformation table
	    UPDATE MemberInformation
	    SET EMPLOYEENUMBER = e.EMPNO,
	        EMPLOYEENETWORKID=SUSER_NAME()
	    FROM MemberInformation m
	    JOIN Update_EmpNo e on m.SSN=e.SSN
	    WHERE m.EMPLOYEENUMBER <> e.EMPNO OR m.EMPLOYEENUMBER is null
	
	    -- Capture return values
	    SELECT 	@SysError 	 = @@ERROR, 
	            @SysRowCount1 = @@ROWCOUNT;
				
		IF @SysError <> 0
			BEGIN
				ROLLBACK TRANSACTION SynchHRData
				
				SET @ReturnRowCounts 	= 0		-- Retrun zero row counts
				SET @ReturnResult 		= 0		-- "BAD" result	
				
				RETURN							-- End further processing
			END
		ELSE
		    -- Update EmpNos that should be null on MemberInfo Table
			UPDATE MemberInformation
	        SET EMPLOYEENUMBER = NULL,EMPLOYEENETWORKID=SUSER_NAME()
	        FROM MemberInformation m
	        LEFT OUTER JOIN Update_EmpNo e on m.SSN=e.SSN
	        WHERE e.SSN IS NULL AND m.EMPLOYEENUMBER IS NOT NULL AND m.EMPLOYEENUMBER < 30000
			
			-- Capture return values
	        SELECT 	@SysError 	 = @@ERROR, 
			        @SysRowCount2 = @@ROWCOUNT;
			
			IF @SysError <> 0
			    BEGIN
				    ROLLBACK TRANSACTION SynchHRData
				
				    SET @ReturnRowCounts 	= 0		-- Retrun zero row counts
				    SET @ReturnResult 		= 0		-- "BAD" result	
				
				    RETURN							-- End further processing
			    END
            ELSE
			    BEGIN
				    COMMIT TRANSACTION SynchHRData
				
				    SET @ReturnRowCounts = @SysRowCount1 + @SysRowCount2	
				    SET @ReturnResult 		= 1					-- "GOOD" result						
			    END
	;		--	END TRANSACTION SynchHRData
	
-- -------------------------------------------------------------------------------
END  -- End stored procedure "Custom_Synch_HR_MemID_Update_MemberInfo_EmpNos"
GO

