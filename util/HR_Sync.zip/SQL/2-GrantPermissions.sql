USE MEMBERID
GO

DECLARE @DOMAIN varchar(20)
DECLARE @HREmpSync_ServiceAccount varchar(40)
DECLARE @HREmpSync_Login varchar(40)

-- NOTE: Update @DOMAIN  and  @HREmpSync_ServiceAccount for target environment.
-- Contact S-Team to determine correct service account for the target environment for application HR_Sync
SET @DOMAIN = 'DEVNCSECU\'
SET @HREmpSync_ServiceAccount = 'svc-dimg-memidProces'
SET @HREmpSync_Login = @DOMAIN + @HREmpSync_ServiceAccount

-- Create user/login 
DECLARE @sqlstmt varchar(200)

IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = @HREmpSync_Login)
BEGIN
	SET @sqlstmt = 'DROP LOGIN [' + @HREmpSync_Login + ']'
	PRINT @sqlstmt
	EXEC(@sqlstmt)
END
SET @sqlstmt = 'CREATE LOGIN [' + @HREmpSync_Login + '] FROM WINDOWS WITH DEFAULT_DATABASE=[MEMBERID], DEFAULT_LANGUAGE=[us_english]'
PRINT @sqlstmt
EXEC(@sqlstmt)
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = @HREmpSync_ServiceAccount)
BEGIN
	SET @sqlstmt = 'DROP USER [' + @HREmpSync_ServiceAccount + ']'
	PRINT @sqlstmt
	EXEC(@sqlstmt)
END
SET @sqlstmt = 'CREATE USER [' + @HREmpSync_ServiceAccount + '] FOR LOGIN [' + @HREmpSync_Login + '] WITH DEFAULT_SCHEMA=[dbo]'
PRINT @sqlstmt
EXEC(@sqlstmt)

-- Grant permissions
SET @sqlstmt = 'GRANT SELECT,INSERT,UPDATE,DELETE, ALTER ON Update_EmpNo to [' + @HREmpSync_ServiceAccount +']'
PRINT @sqlstmt
EXEC(@sqlstmt)

SET @sqlstmt = 'GRANT SELECT,UPDATE ON MemberInformation to [' + @HREmpSync_ServiceAccount +']'
PRINT @sqlstmt
EXEC(@sqlstmt)

SET @sqlstmt = 'GRANT INSERT,UPDATE ON MemberInformationSync to [' + @HREmpSync_ServiceAccount +']'
PRINT @sqlstmt
EXEC(@sqlstmt)

SET @sqlstmt = 'GRANT INSERT,UPDATE ON MemberInformation_Audit_Trail to [' + @HREmpSync_ServiceAccount +']'
PRINT @sqlstmt
EXEC(@sqlstmt)

SET @sqlstmt = 'GRANT EXECUTE ON Custom_Synch_HR_MemID_Update_MemberInfo_EmpNos to [' + @HREmpSync_ServiceAccount +']'
PRINT @sqlstmt
EXEC(@sqlstmt)

SET @sqlstmt = 'GRANT EXECUTE ON Custom_HRSync_TruncateTable to [' + @HREmpSync_ServiceAccount +']'
PRINT @sqlstmt
EXEC(@sqlstmt)

GO



