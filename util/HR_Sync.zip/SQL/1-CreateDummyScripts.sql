USE [MEMBERID]
GO

-- ===================================================================================================================
-- Description: Creates dummy script of Stored Procedure for initial set up. All necessary permissions will be granted 
--              on this dummy SP. Later actual scripts will replace this dummy procedure with real one.
--				Benefit: Developers can create scripts as "ALTER" instead of "CREATE", so changing and re-running 
--                        script defining actual stored procedure wouldn't erase permissions granted on this SP.
-- -------------------------------------------------------------------------------------------------
-- Special Instructions: Run ONLY ONCE in each environment during initial set up in target database	      
-- ===================================================================================================================

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Custom_Synch_HR_MemID_Update_MemberInfo_EmpNos')
    DROP PROCEDURE Custom_Synch_HR_MemID_Update_MemberInfo_EmpNos
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Custom_HRSync_TruncateTable')
    DROP PROCEDURE Custom_HRSync_TruncateTable
GO

CREATE PROCEDURE dbo.Custom_Synch_HR_MemID_Update_MemberInfo_EmpNos AS RETURN
GO

CREATE PROCEDURE dbo.Custom_HRSync_TruncateTable AS RETURN
GO