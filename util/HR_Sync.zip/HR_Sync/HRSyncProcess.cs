﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;

namespace HR_Sync
{
    public class HRSyncProcess
    {
        private static Logger log;
        public const double TIMEOUT_SEC = 120.0;  // Timeout (seconds) to complete copying input file

        public HRSyncProcess(Logger logger)
        {
            log = logger;
        }

        public void Run()
        {
            try
            {
                log.LogInfo("    Current thread is running under credentials: " + System.Security.Principal.WindowsIdentity.GetCurrent().Name);
                log.LogInfo("    Backup folder for old input files: " + Properties.Settings.Default.BackupFolder);

                // make sure the input file finished copying
                try
                {
                    WaitToFinishCopying(Properties.Settings.Default.InputFile, TIMEOUT_SEC);
                }
                catch (TimeoutException)
                {
                    string msg = "Application HR Sync has failed. Error:" + Environment.NewLine + Environment.NewLine;
                    msg += $"Timeout: Input file {Properties.Settings.Default.InputFile} has not completed copying within {TIMEOUT_SEC} seconds.";

                    SendEmailToTechService(Properties.Resources.subjError, msg);
                    SendEmailToUsers(Properties.Resources.subjError, Properties.Resources.bodyFail);
                    Environment.Exit(Program.TIMEOUT_FINISHING_FILE_COPYING);
                }


                if (RunSyncProcess(Properties.Settings.Default.InputFile))
                {
                    if (Properties.Settings.Default.EmailUsersOnSuccess)
                    {
                        SendEmailToUsers(Properties.Resources.subjSuccess, Properties.Resources.bodySuccess);
                    }

                }
                else
                {
                    SendEmailToUsers(Properties.Resources.subjError, Properties.Resources.bodyFail);
                    Environment.Exit(Program.SYNC_PROCESS_FAILED);
                }

            }
            catch (Exception ex)
            {
                log.LogError("Exception in HRSyncProcess.Run(): " + ex.ToString());

                BackupInputFile(Properties.Settings.Default.InputFile);
                try
                {
                    File.Delete(Properties.Settings.Default.InputFile);
                }
                catch
                {
                    log.LogWarn($"Failed to delete file [{Properties.Settings.Default.InputFile}]");
                }

                SendEmailToTechService(Properties.Resources.subjError, string.Format(Properties.Resources.bodyError, Environment.MachineName,
                        ex.ToString(), Environment.NewLine));
            }

        }

        public void WaitToFinishCopying(string inputFile, double timeoutSec)
        {
            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Start();
            while (!CheckIfFileFinishedCopying(inputFile) && GetElapsedMsec(stopWatch) < timeoutSec)
            {
                log.LogInfo($" ... Waiting for file [{inputFile}] to finish copying");
                Thread.Sleep(500);
            }

            if (GetElapsedMsec(stopWatch) >= timeoutSec)
            {
                throw new TimeoutException($"Input file has not finished copying in {timeoutSec} seconds.");
            }
        }

        private double GetElapsedMsec(Stopwatch stopWatch)
        {
            stopWatch.Stop();
            TimeSpan ts = stopWatch.Elapsed;
            stopWatch.Start();
            return ts.TotalSeconds;
        }
        

        public bool RunSyncProcess(string inputFileName)
        {
            SqlConnection connection = null;
            try
            {
                log.LogInfo("RunSyncProcess(): Start");

                // Dictionary to keep data from input file
                Dictionary<string, string> inputDataDict;

                // lock input file for the time of reading by opening FileStream with last parameter FileShare.Read
                using (FileStream fStream = new FileStream(inputFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    string errorMsg = String.Empty;
                    // Dictionary to keep information about SSNs that appear in the input file more than once with different EmpNo
                    Dictionary<string, string> badRecords;

                    // fill Dictionary with pairs (SSN,EmpNo); treat duplicate/multiple entries in the input file in this step.
                    inputDataDict = GetDictionaryWithInputData(fStream, out errorMsg, out badRecords);
                    if (badRecords.Count > 0)
                    {
                        string ignoredRecords = badRecords.Values.Aggregate((concat, str) => $"{concat}{str}");
                        string msg =
                            "Some SSNs appear in the input file more than once with different employee numbers." +
                            " All entries with these SSNs will be ignored by HR Sync. Problematic entries:" +
                            ignoredRecords;
                        log.LogWarn(msg);

                        SendEmailToTechService(Properties.Resources.subjBadRecordsInInput,
                            string.Format(Properties.Resources.bodyBadRecordsInInput, Environment.NewLine, msg));
                    }

                    if (!string.IsNullOrEmpty(errorMsg))
                    {
                        string msg = "Application HR Sync has failed. Error:" + Environment.NewLine;
                        msg +=
                            $"  Failure in HR Sync while reading data from input file: '{errorMsg}'. {Environment.NewLine}Check log file for more details.";
                        SendEmailToTechService(Properties.Resources.subjError, msg);
                        return false;
                    }
                }

                // make DataTable out of data in the dictionary
                DataTable inputTable = GetTableWithInputData(inputDataDict);

                // open SqlConnection using class SqlHelper, so that SQL Server errors will propagate to the application for logging
                SqlHelper sqlHelper = new SqlHelper(log);
                connection = sqlHelper.SetupConnection(Properties.Settings.Default.MemberIDConnString);
                if (connection == null || connection.State == ConnectionState.Closed)
                {
                    log.LogError("Failed to open DB connection");
                    string msg = "Application HR Sync has failed. Error:" + Environment.NewLine;
                    msg += $"  Failed to open connection to {sqlHelper.GetDbInfo(Properties.Settings.Default.MemberIDConnString)}";
                    SendEmailToTechService(Properties.Resources.subjError, msg);
                    return false;
                }

                string dbUser = sqlHelper.GetDBUser(connection);
                log.LogInfo($"    DB user: {dbUser}");

                if (!TruncateTable(connection, Properties.Settings.Default.SPTruncateName, Properties.Settings.Default.SSNUpdateTableName))
                {
                    log.LogError($"Truncation of DB table [{Properties.Settings.Default.SSNUpdateTableName}] has failed");
                    string msg = "Application HR Sync has failed. Error:" + Environment.NewLine;
                    msg += $"  Truncation of DB table [{Properties.Settings.Default.SSNUpdateTableName}] has failed.";
                    SendEmailToTechService(Properties.Resources.subjError, msg);
                    if (connection.State == ConnectionState.Open) { connection.Close(); }
                    return false;
                }

                // BulkCopy input data to DB using that connection 
                if (!BulkCopyInputData(connection, inputTable, Properties.Settings.Default.SSNUpdateTableName))
                {
                    log.LogError($"BulkCopy to DB table [{Properties.Settings.Default.SSNUpdateTableName}] has failed");
                    string msg = "Application HR Sync has failed. Error:" + Environment.NewLine;
                    msg += $"  BulkCopy to DB table [{Properties.Settings.Default.SSNUpdateTableName}] has failed.";
                    SendEmailToTechService(Properties.Resources.subjError, msg);
                    if (connection.State == ConnectionState.Open) { connection.Close(); }
                    return false;
                }

                if (!ExecuteStoredProcedure(connection, Properties.Settings.Default.SPSyncName))
                {
                    log.LogError($"Stored Procedure [{Properties.Settings.Default.SPSyncName}] returned code indicating failure.");
                    string msg = "Application HR Sync has failed. Error:" + Environment.NewLine;
                    msg += $"Stored procedure [{Properties.Settings.Default.SPSyncName}] has failed.";
                    SendEmailToTechService(Properties.Resources.subjError, msg);
                    if (connection.State == ConnectionState.Open) { connection.Close(); }
                    return false;
                }

                BackupInputFile(inputFileName);

                try
                {
                    File.Delete(inputFileName);
                }
                catch
                {
                    log.LogWarn($"Failed to delete file [{inputFileName}]");
                }

                return true;
            }
            catch (Exception ex)
            {
                BackupInputFile(inputFileName);
                try { File.Delete(inputFileName); }
                catch { log.LogWarn($"Failed to delete file [{inputFileName}]"); }

                log.LogError($"Exception in RunSyncProcess(): {ex.ToString()}");
                SendEmailToTechService(Properties.Resources.subjError,
                    "Error while running synch process in HR_Sync. Check log file for more details.");

                return false;
            }
            finally
            {
                if (connection != null && connection.State == ConnectionState.Open) { connection.Close(); }
                log.LogInfo("RunSyncProcess(): End");
            }
        }

        /// <summary>
        /// Reads from input file (through specified FileSteam) pairs (SSN, employee number) and returns them in a dictionary.
        /// Also stores records with repeating SSN in a out parameter dictionary '<paramref name="badRecords"/>'. 
        /// </summary>
        /// <remarks>
        /// Treating situation when same SSN appears in the input file more than once:
        /// - The method takes as out parameter dictionary 'badRecords' (initially empty) that will hold such records; its keys
        ///   are SSNs of repeating records
        /// - When record with SSN that is already added to main dictionary is detected:
        ///      - if EMPNO in new record is the same as one already in the main dictionary - ignore it (just add warning to log file)
        ///      - if EMPNO in new record is different from one in the main dictionary - add this this record to 'badRecords' dictionary
        ///          (if the same SSN with different value will appear again later, its EMPNO values will be added to the value in 'badRecords')
        /// - If 'badRecords' is not empty after finishing processing input file - remove from main dictionary all records with SSNs from 'badRecords'
        ///   (these records will not be processed).
        /// </remarks>
        /// <param name="fileStream"></param>
        /// <param name="errorMessage">String to keep information about exceptions (would it be thrown)</param>
        /// <param name="badRecords"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetDictionaryWithInputData(FileStream fileStream, out string errorMessage, 
                                                                     out Dictionary<string, string> badRecords)
        {
            Dictionary<string, string> result = new Dictionary<string, string>();
            badRecords = new Dictionary<string, string>();
            try
            {
                using (StreamReader streamReader = new StreamReader(fileStream))
                {
                    string line;
                    while ((line = streamReader.ReadLine()) != null)
                    {
                        string[] ssnCoords = Properties.Settings.Default.SSNCoords.Split(',');
                        string ssn = line.Substring(int.Parse(ssnCoords[0]), int.Parse(ssnCoords[1])).Trim();
                        string[] empCoords = Properties.Settings.Default.EMPCoords.Split(',');
                        string empNumber = line.Substring(int.Parse(empCoords[0]), int.Parse(empCoords[1])).Trim();
                        try
                        {
                            result.Add(ssn, empNumber);
                        }
                        catch (ArgumentException) // this SSN is already in the dictionary 
                        {
                            string[] nameCoords = Properties.Settings.Default.NameCoords.Split(',');
                            string empName = line.Substring(int.Parse(nameCoords[0]), int.Parse(nameCoords[1])).Trim();

                            if (result[ssn] == empNumber) // the same employee number entered second time
                            {
                                log.LogWarn($"Input file contains duplicate entry with same employee number for SSN {MaskString(ssn)} (name: {empName})");
                            }
                            else
                            {
                                if (!badRecords.Keys.Contains(ssn)) // add entry for this SSN to "bad records" dictionary
                                {
                                    string entry = Environment.NewLine + $"  SSN {MaskString(ssn)} (name: {empName}), " +
                                                   $"Employee numbers: {result[ssn]}; {empNumber}";
                                    badRecords.Add(ssn, entry);
                                }
                                else // entry for this SSN already exists in "bad records" dictionary - add new Employee number to it
                                {
                                    badRecords[ssn] = badRecords[ssn] + $"; {empNumber}";
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            log.LogError($"Exception in GetDictionaryWithInputData() adding data to dictionary: " + e.ToString());
                            errorMessage = $"Exception thrown when reading input data: " + e.Message;
                            return null;
                        }
                    }
                }

                if (badRecords.Count > 0)  // remove from result bad records that are still there
                {
                    foreach (var badKey in badRecords.Keys)
                    {
                        result.Remove(badKey);
                    }
                }

                errorMessage = "";
                return result;
            }
            catch (Exception ex)
            {
                log.LogError($"Exception in GetDictionaryWithInputData(): " + ex.ToString());
                errorMessage = $"Exception thrown when reading input data: " + ex.Message;
                return null;
            }
        }

        /// <summary>
        /// Truncates specified DB table by calling specified stored procedure
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="spName"></param>
        /// <param name="dbTableName"></param>
        /// <returns></returns>
        public bool TruncateTable(SqlConnection connection, string spName, string dbTableName)
        {
            try
            {
                log.LogInfo("TruncateTable(): Start");
                using (SqlCommand sqlCommand = connection.CreateCommand())
                {
                    sqlCommand.CommandText = spName;
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    sqlCommand.ExecuteNonQuery();

                    if ((bool)retVal.Value)
                    {
                        log.LogInfo($"  Successfully truncated table {dbTableName}");
                        return true;  
                    }
                    else
                    {
                        log.LogError($"  Failed to truncate table {dbTableName}");
                        return false;
                    }
                }
            }
            catch (SqlException s)
            {
                log.LogError("TruncateTable - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.LogError("TruncateTable - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.LogError("TruncateTable - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log.LogInfo("TruncateTable(): End");
            }
        }

        public bool BulkCopyInputData(SqlConnection connection, DataTable inMemoryTable, string dbTableName)
        {
            try
            {
                log.LogInfo("Start BulkCopyInputData()");
                SqlBulkCopy bulkCopy = new SqlBulkCopy(connection);
                bulkCopy.ColumnMappings.Add("SSN", "SSN");
                bulkCopy.ColumnMappings.Add("EMPNO", "EMPNO");
                bulkCopy.DestinationTableName = Properties.Settings.Default.SSNUpdateTableName;
                bulkCopy.WriteToServer(inMemoryTable);

                // because bulkCopy.WriteToServer() does not throw exception on SQL Server errors, to detect error
                // we compare numbers of rows in the database after insertion with number of rows in the DataTable
                int dbCount = GetRowCountFromDBTable(dbTableName, connection);
                if (dbCount < 0)
                {
                    throw new Exception($"Failed to get count of rows in the DB table [{dbTableName}] after BulkCopy");
                }

                if (inMemoryTable.Rows.Count != dbCount)
                {
                    string msg = $"BulkCopy to DB table {dbTableName} has failed: number of rows in DB table is {dbCount}, ";
                    msg += $"while number of rows in in-memory DataTable is {inMemoryTable.Rows.Count}";
                    throw new Exception(msg);
                }

                log.LogDebug($"    Performed BulkCopy of {dbCount} rows from in-memory table to DB table [{dbTableName}]");
                return true;
            }
            catch (SqlException s)
            {
                log.LogError("BulkCopyInputData - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.LogError("BulkCopyInputData - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.LogError("BulkCopyInputData - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log.LogInfo("End BulkCopyInputData()");
            }
        }

        /// <summary>
        /// Returns number of rows in the specified table. On failure returns -1.
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="connection"></param>
        /// <returns></returns>
        private int GetRowCountFromDBTable(string tableName, SqlConnection connection)
        {
            try
            {
                string query = $"SELECT COUNT(*) FROM {tableName} WITH(NOLOCK)";
                int count = -1;
                using (SqlCommand cmdCount = new SqlCommand(query, connection))
                {
                    count = (int)cmdCount.ExecuteScalar();
                }
                return count;
            }
            catch (Exception)
            {
                return -1;
            }
        }

        /// <summary>
        /// Returns DataTable with columns SSN and EMPNO filled with data from specified dictionary.
        /// </summary>
        /// <param name="dict"></param>
        /// <returns></returns>
        public DataTable GetTableWithInputData(Dictionary<string, string> dict)
        {
            DataTable table = new DataTable(Properties.Settings.Default.SSNUpdateTableName);
            table.Columns.Add("SSN");
            table.Columns.Add("EMPNO");
            foreach (var ssn in dict.Keys)
            {
                DataRow row = table.NewRow();
                row["SSN"] = ssn;
                row["EMPNO"] = dict[ssn];
                table.Rows.Add(row);
            }
            return table;
        }

        /// <summary>
        /// Executes specified stored procedure using specified SqlConnection.
        /// Stored procedure does not take any input parameters and returns int @ReturnRowCounts and bool "@ReturnResult".
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="spName"></param>
        /// <returns></returns>
        public bool ExecuteStoredProcedure(SqlConnection connection, string spName)
        {
            try
            {
                log.LogInfo($"ExecuteStoredProcedure(): Start");
                using (SqlCommand sqlCommand = connection.CreateCommand())
                {
                    sqlCommand.CommandText = spName;
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = connection.ConnectionTimeout;

                    SqlParameter retCount = sqlCommand.Parameters.AddWithValue("@ReturnRowCounts", 0);
                    retCount.Direction = ParameterDirection.Output;
                    retCount.SqlDbType = SqlDbType.Int;

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    sqlCommand.ExecuteNonQuery();

                    if ((bool)retVal.Value)
                    {
                        int affectedRows = (int)retCount.Value;
                        log.LogInfo($"  Stored procedure [{spName}] successfully updated {affectedRows} rows.");
                        return true;
                    }
                    else
                    {
                        log.LogError($"  Stored procedure [{spName}] has failed.");
                        return false;
                    }
                }
            }
            catch (SqlException s)
            {
                log.LogError($"  ExecuteStoredProcedure() - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.LogError($"  ExecuteStoredProcedure() - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.LogError($"  ExecuteStoredProcedure() - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log.LogInfo($"ExecuteStoredProcedure(): End");
            }
        }


        /// <summary>
        /// Copies specified file (name with full path expected) to backup folder; deletes oldest backup if number of files in backup folder exceeds
        /// max number (configurable).
        /// </summary>
        /// <param name="fileName">Fully qualified file name of input file to be copied to backup</param>
        public void BackupInputFile(string fileName)
        {
            try
            {
                log.LogInfo($"Entering BackupInputFile()");
                string backupFolder = Properties.Settings.Default.BackupFolder; // for convenience

                if (!File.Exists(fileName))
                {
                    log.LogError($"Input file [{fileName}] does not exist. Aborting backup.");
                    return;
                }

                string backupFileName = Path.GetFileNameWithoutExtension(fileName);
                backupFileName = backupFileName + DateTime.Now.ToString("_yyyy_MM_dd__HH_mm_ss") + ".txt";

                if (!Directory.Exists(backupFolder))
                {
                    Directory.CreateDirectory(backupFolder);
                }

                backupFileName = Path.Combine(backupFolder, backupFileName);

                File.Copy(fileName, backupFileName);

                while (Directory.GetFiles(backupFolder).Length > Properties.Settings.Default.MaxNumberOfBackups)
                {
                    string oldestFile = new DirectoryInfo(backupFolder).GetFileSystemInfos()
                        .OrderBy(fi => fi.CreationTime).First().FullName;
                    File.Delete(oldestFile);
                }
            }
            catch (Exception ex)
            {
                log.LogError("Exception in BackupInputFile(): " + ex.ToString());
            }
            finally
            {
                log.LogInfo($"Exiting BackupInputFile()");
            }
        }


        public static bool CheckIfFileFinishedCopying(string fileFullPath)
        {
            try
            {
                using (File.OpenRead(fileFullPath))
                {
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Returns string <paramref name="inputStr"/> with all characters except for last several chars (their number is configurable) replaced with 'x'.
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static string MaskString(string inputStr)
        {
            if (string.IsNullOrWhiteSpace(inputStr)) { return inputStr; }

            string inputTrimmed = inputStr.Trim();
            int len = inputTrimmed.Length;
            if (len <= Properties.Settings.Default.NumberOfUnmaskedChars) { return inputStr; }

            return new string('x', len - Properties.Settings.Default.NumberOfUnmaskedChars) +
                   inputTrimmed.Substring(len - Properties.Settings.Default.NumberOfUnmaskedChars);
        }

        public static void SendEmailToTechService(string subject, string mailBody)
        {
            if (Properties.Settings.Default.SendTechServicesEmails)
            {
                log.LogInfo("SendEmailToTechService(): Start");
                SendEmail(Properties.Settings.Default.TechEmailRecipients, subject, mailBody);
                log.LogInfo("SendEmailToTechService(): End");
            }
        }

        public static void SendEmailToUsers(string subject, string mailBody)
        {
            if (Properties.Settings.Default.SendUsersEmails)
            {
                log.LogInfo("SendEmailToUsers(): Start");
                SendEmail(Properties.Settings.Default.UserEmailRecipients, subject, mailBody);
                log.LogInfo("SendEmailToUsers(): End");
            }
        }

        public static void SendEmail(string toAddress, string subject, string mailBody)
        {
            try
            {
                SECUEmailEWS secuEmail = CreateSECUEmail(toAddress, subject, mailBody);
                secuEmail.FromAddress = Properties.Settings.Default.EmailFrom;

                secuEmail.SendEmail();
                if (!string.IsNullOrEmpty(secuEmail.ErrorMessage))
                {
                    log.LogError($"Failed to send email with subject '{subject}'. Error message: " + secuEmail.ErrorMessage);
                }
            }
            catch (Exception ex)
            {
                log.LogError("Exception caught in SendEmail(): " + ex.ToString());
            }
        }

        public static SECUEmailEWS CreateSECUEmail(string toAddress, string subject, string mailBody)
        {
            SECUEmailEWS secuEmail = new SECUEmailEWS(log, "    ")
            {
                MustHaveAttachment = false,
                MustHaveSubject = false,
                Subject = subject,
                Body = mailBody,
                Autodiscover = true,  // Autodiscover is preferred method
                EWSUri = Properties.Settings.Default.ExchangeURL,
                EwsUserName = Properties.Settings.Default.EwsUserName,
                EwsPassword = Properties.Settings.Default.EwsPassword,
                ToAddress = new List<string>()
            };
            foreach (var address in toAddress.Split(new[] { ";", ",", " " }, StringSplitOptions.RemoveEmptyEntries))
            {
                secuEmail.ToAddress.Add(address);
            }

            return secuEmail;
        }

    }
}
