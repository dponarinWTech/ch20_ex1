USE [Kofax_FormInfo]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF  NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[ExecutionHistory]') AND type in (N'U'))
    CREATE TABLE [dbo].[ExecutionHistory](
	    [ProcessName] 			[varchar](50) NOT NULL,
	    [ExecutionParameters] 	[varchar](100) NULL,
	    [ExecutionDateTime] 	[datetime] NOT NULL,
	    [LogDetails] 			[varchar](250) NOT NULL,
	    [ErrorStatus] 			[bit] NOT NULL,
    ) ON [PRIMARY]
GO

SET ANSI_PADDING OFF
GO
-- ===============================================================================================
-- Author:      Yogesh Sanghvi
-- Create date: 08/01/2018
-- Description:	Table to hold "Found AND Missing" records for "Branch Scan Report" weekly report
-- Execution:	Will be called by other SQL scripts for "KofaxMargoBranchScanReport" application
-- ===============================================================================================
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[BranchScanReport]') AND type in (N'U'))
    DROP TABLE [dbo].[BranchScanReport]
GO
-- --------------------------------------------------------------------------
CREATE TABLE [dbo].[BranchScanReport](
	[UniqueID] 		[varchar](12) NOT NULL,
	[BranchNum] 	[varchar](8) NULL,
	[EmpID]			[varchar](9) NULL,
	[WorkstationID]	[varchar](10) NULL,
	[NumberOfDays]	[INT]NULL,
	[Status]		[varchar](30) NULL,
	[CreateDate]	[DateTime] NULL,
	[AccountList] 	[varchar](Max) NULL,
	[SSNList] 		[varchar](Max) NULL
) ON [PRIMARY]
GO 

SET ANSI_PADDING OFF
GO
-- -----------------------------------------------------------------------------------------------------



-- ===============================================================================================
-- Author:      Yogesh Sanghvi
-- Create date: 08/01/2018
-- Description:	Table to hold "Partial" records for "Margo Form Errors" weekly report
-- Execution:	Will be called by other SQL scripts for "KofaxMargoBranchScanReport" application
-- ===============================================================================================

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[MargoFormErrorReport]') AND type in (N'U'))
    DROP TABLE [dbo].[MargoFormErrorReport]
GO
-- --------------------------------------------------------------------------
CREATE TABLE [dbo].[MargoFormErrorReport](
	[UniqueID] 		[varchar](12) NOT NULL,
	[BranchNum] 	[varchar](8) NULL,
	[EmpID]			[varchar](9) NULL,
	[WorkstationID]	[varchar](10) NULL,
	[NumberOfDays]	[INT]NULL,
	[Status]		[varchar](30) NULL,
	[CreateDate]	[DateTime] NULL,
	[AccountList] 	[varchar](Max) NULL,
	[SSNList] 		[varchar](Max) NULL
) ON [PRIMARY]
GO 