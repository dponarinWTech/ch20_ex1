USE [Kofax_FormInfo]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ======================================================================================================
-- Author:      Yogesh Sanghvi
-- Create date: 08/01/2018
-- Description:	Select records to create weekly "Branch Scan Report" for "Found AND Missing" records
-- Execution:	Will be (called by) C# application during weekly process
-- ======================================================================================================
ALTER PROCEDURE [dbo].[KofMargoBrScanRep_BranchScan]
(		
	@DayDifference		INT,
	@ReturnFoundRows	INT OUT,
	@ReturnMissingRows	INT OUT,
	@ReturnResult		BIT OUT
) 
AS
BEGIN	
	DECLARE @ErrorStatus			BIT;
	DECLARE @ExecutionParameters	VARCHAR(100);
	DECLARE @LogDetails 			VARCHAR(250);
	DECLARE @ProcessName			VARCHAR(50);
	DECLARE @SysError				INT;
	DECLARE @SysRowCount			INT;
	
	SET @ErrorStatus			= 0;
	SET @ExecutionParameters 	= NULL;
	SET @LogDetails 			= NULL;
	SET @ProcessName 			= 'KofMargoBrScanRep_BranchScan';
	SET @SysError				= 0;
	SET @SysRowCount			= 0;
	-- -----------------------------------------------------------------------------
	SET @LogDetails = 'Starting to drop temporary tables and truncate "BranchScanReport" table';
	SET @ExecutionParameters = NULL;
	SET @ErrorStatus = 0;
	
	INSERT INTO ExecutionHistory (ProcessName,ExecutionParameters,ExecutionDateTime,LogDetails,ErrorStatus)
	VALUES (@ProcessName,@ExecutionParameters,GETDATE(),@LogDetails,@ErrorStatus)
	-- ---------------
	
	-- Drop temporary tables, if exists
	IF OBJECT_ID('tempdb..#ReportFoundRecordsTemp') IS NOT NULL 
		DROP TABLE #ReportFoundRecordsTemp
		
	IF OBJECT_ID('tempdb..#ReportMissingRecordsTemp') IS NOT NULL 
		DROP TABLE #ReportMissingRecordsTemp
	-- -------------
	
	-- Delete existing records, if any
	TRUNCATE TABLE BranchScanReport
	-- ------------
	
	-- Capture values as it will be reset to zero in next step
	SELECT 	@SysError = @@ERROR
	
	IF @SysError <> 0
		BEGIN
			SET @ReturnResult = 0		-- "BAD" result		
			
			RETURN						-- End further processing
		END
	ELSE
		BEGIN
			SET @LogDetails = 'Successfully dropped temporary tables and truncated "BranchScanReport" table';
			SET @ExecutionParameters = NULL;
			SET @ErrorStatus = 0;
			
			INSERT INTO ExecutionHistory (ProcessName,ExecutionParameters,ExecutionDateTime,LogDetails,ErrorStatus)
			VALUES (@ProcessName,@ExecutionParameters,GETDATE(),@LogDetails,@ErrorStatus)
		END
		
	WAITFOR DELAY '00:00:00:002'
	-- ------------

	SET @LogDetails = 'Starting to select "Found AND Missing" records from "FormInfo" table';
	SET @ExecutionParameters = NULL;
	SET @ErrorStatus = 0;
	
	INSERT INTO ExecutionHistory (ProcessName,ExecutionParameters,ExecutionDateTime,LogDetails,ErrorStatus)
	VALUES (@ProcessName,@ExecutionParameters,GETDATE(),@LogDetails,@ErrorStatus)
	
	WAITFOR DELAY '00:00:00:002'
	-- ---------------
	
	BEGIN TRANSACTION BranchScanRptRec	
		SET @LogDetails = 'Starting to select "Found" records from "FormInfo" table into temporary table';
		SET @ExecutionParameters = NULL;
		SET @ErrorStatus = 0;
		
		INSERT INTO ExecutionHistory (ProcessName,ExecutionParameters,ExecutionDateTime,LogDetails,ErrorStatus)
		VALUES (@ProcessName,@ExecutionParameters,GETDATE(),@LogDetails,@ErrorStatus)
		-- ---------------

		-- Select "Found" records for report
		-- NOTE: The "Outer" option will parse SSN and Account from XML creating seprate row for each SSN/Account pair
		SELECT f.FormType + RIGHT(REPLICATE('0', 8) + CONVERT(varChar(8), f.Id), 8) AS UniqueID,  
				CONVERT(VARCHAR(10),f.CreateDate,101) AS CreateDate, f.Status, DATEDIFF(DAY, CreateDate, GETDATE()) As NumberOfDays,
				z.value('.','varchar(9)') AS SSN, 
				y.value('.','varchar(20)') AS Account,
				x.value('.','varchar(5)') AS BranchNumber, 
				w.value('.','varchar(7)') AS EmpID,
				u.value('.','varchar(8)') AS WorkStationID	
		INTO #ReportFoundRecordsTemp
		FROM FormInfo AS f
			OUTER APPLY f.InfoXml.nodes('/form/ssnlist/ssn') a(z)
			OUTER APPLY f.InfoXml.nodes('/form/accountlist/account') b(y)
			OUTER APPLY f.InfoXml.nodes('/form/branchnum') c(x)
			OUTER APPLY f.InfoXml.nodes('/form/empid') d(w)
			OUTER APPLY f.InfoXml.nodes('/form/workstationid') e(u)
		WHERE Status = 'FOUND'  
		ORDER BY NumberOfDays DESC, ID			
		-- ---------------
		
		-- Capture values as it will be reset to zero in next step
		SELECT 	@SysError 	 = @@ERROR,
				@SysRowCount = @@ROWCOUNT;
		
		IF @SysError <> 0
			BEGIN
				ROLLBACK TRANSACTION BranchScanRptRec
				
				SET @ReturnFoundRows 	= 0		-- Return zero row counts
				SET @ReturnResult 		= 0		-- "BAD" result			
				
				RETURN							-- End further processing
			END
		ELSE
			BEGIN			
				SET @ExecutionParameters = NULL;
				SET @ReturnFoundRows 	= @SysRowCount		-- Retrun selected row counts
				SET @LogDetails = 'Successfully selected ' + CONVERT(VARCHAR(9), @ReturnFoundRows) + ' "Found" records into temporary table';
				SET @ErrorStatus = 0;

				INSERT INTO ExecutionHistory (ProcessName,ExecutionParameters,ExecutionDateTime,LogDetails,ErrorStatus)
				VALUES (@ProcessName,@ExecutionParameters,GETDATE(),@LogDetails,@ErrorStatus)
				
				WAITFOR DELAY '00:00:00:002'
				-- -----------------------

				-- Format "Found" records for report
				SET @LogDetails = 'Starting to format and insert "Found" records from temporary table into "BranchScanReport" table';
				SET @ExecutionParameters = NULL;
				SET @ErrorStatus = 0;
				
				INSERT INTO BranchScanReport (UniqueID,BranchNum,EmpID,WorkstationID,NumberOfDays,Status,CreateDate,SSNList,AccountList)
				SELECT a.uniqueid, RIGHT('0000' + ISNULL(a.BranchNumber, ''), 4) As BranchNumber, a.EmpID, a.WorkStationID, a.NumberOfDays, a.Status, a.CreateDate,
					LTRIM(RTRIM(STUFF(
						 (SELECT DISTINCT ('; ' + SSN)
						  FROM #ReportFoundRecordsTemp as b
						  WHERE a.uniqueid = b.uniqueid
						  FOR XML PATH (''))
						  , 1, 1, '')))  AS SSN,
					LTRIM(RTRIM(STUFF(
						 (SELECT DISTINCT ('; ' + Account)
						  FROM #ReportFoundRecordsTemp as b
						  WHERE a.uniqueid = b.uniqueid
						  FOR XML PATH (''))
						  , 1, 1, '')))  AS Account
				FROM #ReportFoundRecordsTemp AS a
				GROUP BY a.uniqueid, a.BranchNumber, a.EmpID, a.WorkStationID, a.NumberOfDays, a.Status, a.CreateDate
				--ORDER BY CAST(a.BranchNumber AS INT) ASC, a.uniqueid ASC
				-- ---------------

				-- Capture values as it will be reset to zero in next step
				SELECT 	@SysError 	 = @@ERROR,
						@SysRowCount = @@ROWCOUNT;
						
				IF @SysError <> 0
					BEGIN
						ROLLBACK TRANSACTION BranchScanRptRec
						
						SET @ReturnFoundRows 	= 0		-- Return zero row counts
						SET @ReturnResult 		= 0		-- "BAD" result			
						
						RETURN							-- End further processing
					END
				ELSE
					BEGIN				
						SET @ExecutionParameters = NULL;
						SET @ReturnFoundRows 	= @SysRowCount		-- Retrun selected row counts
						SET @LogDetails = 'Successfully inserted formated ' + CONVERT(VARCHAR(9), @ReturnFoundRows) + ' "Found" records into "BranchScanReport" table';
						SET @ErrorStatus = 0;

						INSERT INTO ExecutionHistory (ProcessName,ExecutionParameters,ExecutionDateTime,LogDetails,ErrorStatus)
						VALUES (@ProcessName,@ExecutionParameters,GETDATE(),@LogDetails,@ErrorStatus)
						
						-- END of "Found" records
						WAITFOR DELAY '00:00:00:002'
						-- ======================================================================

						-- Start "Missing" records
						SET @LogDetails = 'Starting to select "Missing" records from "FormInfo" table into temporary table';
						SET @ExecutionParameters = NULL;
						SET @ErrorStatus = 0;

						INSERT INTO ExecutionHistory (ProcessName,ExecutionParameters,ExecutionDateTime,LogDetails,ErrorStatus)
						VALUES (@ProcessName,@ExecutionParameters,GETDATE(),@LogDetails,@ErrorStatus)
						-- ---------------

						-- Select "Missing" records for report
						-- NOTE: The "Outer" option will parse SSN and Account from XML creating seprate row for each SSN/Account pair
						SELECT f.FormType + RIGHT(REPLICATE('0', 8) + CONVERT(varChar(8), f.Id), 8) AS UniqueID,  
								CONVERT(VARCHAR(10),f.CreateDate,101) AS CreateDate, f.Status, DATEDIFF(DAY, CreateDate, GETDATE()) As NumberOfDays,
								z.value('.','varchar(9)') AS SSN, 
								y.value('.','varchar(20)') AS Account,
								x.value('.','varchar(5)') AS BranchNumber, 
								w.value('.','varchar(7)') AS EmpID,
								u.value('.','varchar(8)') AS WorkStationID	
						INTO #ReportMissingRecordsTemp
						FROM FormInfo AS f
							OUTER APPLY f.InfoXml.nodes('/form/ssnlist/ssn') a(z)
							OUTER APPLY f.InfoXml.nodes('/form/accountlist/account') b(y)
							OUTER APPLY f.InfoXml.nodes('/form/branchnum') c(x)
							OUTER APPLY f.InfoXml.nodes('/form/empid') d(w)
							OUTER APPLY f.InfoXml.nodes('/form/workstationid') e(u)
						WHERE Status = 'MISSING' 
							AND DATEDIFF(DAY, CreateDate, GETDATE()) > @DayDifference 
							AND FormType NOT IN('FAF','SPF','SPC','SPD','DCF')
						ORDER BY NumberOfDays DESC, ID			
						-- ---------------

						-- Capture values as it will be reset to zero in next step
						SELECT 	@SysError 	 = @@ERROR,
								@SysRowCount = @@ROWCOUNT;

						IF @SysError <> 0
							BEGIN
								ROLLBACK TRANSACTION BranchScanRptRec
								
								SET @ReturnMissingRows 	= 0		-- Return zero row counts
								SET @ReturnResult 		= 0		-- "BAD" result			
								
								RETURN							-- End further processing
							END
						ELSE
							BEGIN			
								SET @ExecutionParameters = NULL;
								SET @ReturnMissingRows 	= @SysRowCount		-- Retrun selected row counts
								SET @LogDetails = 'Successfully selected ' + CONVERT(VARCHAR(9), @ReturnMissingRows) + ' "Missing" records into temporary table';
								SET @ErrorStatus = 0;

								INSERT INTO ExecutionHistory (ProcessName,ExecutionParameters,ExecutionDateTime,LogDetails,ErrorStatus)
								VALUES (@ProcessName,@ExecutionParameters,GETDATE(),@LogDetails,@ErrorStatus)
								
								WAITFOR DELAY '00:00:00:002'
								-- -----------------------

								-- Format "Missing" records for report
								SET @LogDetails = 'Starting to format and insert "Missing" records from temporary table into "BranchScanReport" table';
								SET @ExecutionParameters = NULL;
								SET @ErrorStatus = 0;

								INSERT INTO BranchScanReport (UniqueID,BranchNum,EmpID,WorkstationID,NumberOfDays,Status,CreateDate,SSNList,AccountList)
								SELECT a.uniqueid, RIGHT('0000' + ISNULL(a.BranchNumber, ''), 4) As BranchNumber, a.EmpID, a.WorkStationID, a.NumberOfDays, a.Status, a.CreateDate,
									LTRIM(RTRIM(STUFF(
										 (SELECT DISTINCT ('; ' + SSN)
										  FROM #ReportMissingRecordsTemp as b
										  WHERE a.uniqueid = b.uniqueid
										  FOR XML PATH (''))
										  , 1, 1, '')))  AS SSN,
									LTRIM(RTRIM(STUFF(
										 (SELECT DISTINCT ('; ' + Account)
										  FROM #ReportMissingRecordsTemp as b
										  WHERE a.uniqueid = b.uniqueid
										  FOR XML PATH (''))
										  , 1, 1, '')))  AS Account
								FROM #ReportMissingRecordsTemp AS a
								GROUP BY a.uniqueid, a.BranchNumber, a.EmpID, a.WorkStationID, a.NumberOfDays, a.Status, a.CreateDate
								--ORDER BY CAST(a.BranchNumber AS INT) ASC, a.NumberOfDays DESC, a.uniqueid ASC
								-- ---------------

								-- Capture values as it will be reset to zero in next step
								SELECT 	@SysError 	 = @@ERROR,
										@SysRowCount = @@ROWCOUNT;

								IF @SysError <> 0
									BEGIN
										ROLLBACK TRANSACTION BranchScanRptRec
										
										SET @ReturnMissingRows 	= 0		-- Return zero row counts
										SET @ReturnResult 		= 0		-- "BAD" result			
										
										RETURN							-- End further processing
									END
								ELSE
									BEGIN				
										SET @ExecutionParameters = NULL;
										SET @ReturnMissingRows 	= @SysRowCount		-- Retrun selected row counts
										SET @LogDetails = 'Successfully inserted formated ' + CONVERT(VARCHAR(9), @ReturnMissingRows) + ' "Missing" records into "BranchScanReport" table';
										SET @ErrorStatus = 0;

										INSERT INTO ExecutionHistory (ProcessName,ExecutionParameters,ExecutionDateTime,LogDetails,ErrorStatus)
										VALUES (@ProcessName,@ExecutionParameters,GETDATE(),@LogDetails,@ErrorStatus)
						
										WAITFOR DELAY '00:00:00:002'
										-- -----------------------

										COMMIT TRANSACTION BranchScanRptRec

										SET @LogDetails = 'Successfully selected "Found AND Missing" records from "FormInfo" table';
										SET @ExecutionParameters = NULL;
										SET @ErrorStatus = 0;
										
										INSERT INTO ExecutionHistory (ProcessName,ExecutionParameters,ExecutionDateTime,LogDetails,ErrorStatus)
										VALUES (@ProcessName,@ExecutionParameters,GETDATE(),@LogDetails,@ErrorStatus)

										SET @ReturnResult 	= 1		-- "GOOD" result
									END
							END
					END
			END
;		--	END TRANSACTION BranchScanRptRec
-- -------------------------------------------------------------------------------
END;  -- End stored procedure "KofMargoBrScanRep_BranchScan"
