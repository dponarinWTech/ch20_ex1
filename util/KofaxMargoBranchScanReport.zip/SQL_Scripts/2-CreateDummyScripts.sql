USE [Kofax_FormInfo]
GO

-- ========================================================================================================================
-- Description: Create dummy script for initial set up
--				It will create dummy scripts for Stored procedures 
--				Later actual scripts will replace this dummy procedures with correct procedures 
--				Benefit - Developers can create scripts as "ALTER" instead of "CREATE". 
--							AS "ALTER" set up does NOT deletes existing procedures, this arrangement will help 
--							DBAs to maintain granted permissions to all database stored procedures
-- -------------------------------------------------------------------------------------------------
-- Special Instructions: Run ONLY ONCE in each environment during initial set up in target database	      
-- ========================================================================================================================

DECLARE @sql varchar(200);

IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'KofMargoBrScanRep_BranchScan')
    BEGIN
        SET @sql = 'CREATE PROCEDURE dbo.KofMargoBrScanRep_BranchScan AS RETURN';
	    PRINT(@sql);
	    EXEC(@sql);
	END
GO

DECLARE @sql varchar(200);
IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'KofMargoBrScanRep_MargoFormError')
    BEGIN
        SET @sql = 'CREATE PROCEDURE dbo.KofMargoBrScanRep_MargoFormError AS RETURN';
	    PRINT(@sql);
	    EXEC(@sql);
	END
GO



