USE [Kofax_FormInfo]
GO

-- NOTE: Update "Domain"  AND  "UserID" for target environment
-- These changes are valid for following applications - 
--	1 - Kofax Index Recon - Nightly and weekly process
--  2 - Kofax Margo Branch Scan Report [future]
-- 	3 - Kofax Index Recon User Interface (UI)
--  4 - Kofax UID Batch class


IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE NAME = 'DEVNCSECU\svc-dkfx-process')
	CREATE USER [DEVNCSECU\svc-dkfx-process]  FOR LOGIN [DEVNCSECU\svc-dkfx-process] WITH DEFAULT_SCHEMA=[dbo]
GO

-- Permissions for database Tables
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.FormInfo TO [DEVNCSECU\svc-dkfx-process]
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.ExecutionHistory TO [DEVNCSECU\svc-dkfx-process]
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.FormIDs_To_Process TO [DEVNCSECU\svc-dkfx-process]
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.Tower_MemdocRecords TO [DEVNCSECU\svc-dkfx-process]
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.BranchScanReport TO [DEVNCSECU\svc-dkfx-process]
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.MargoFormErrorReport TO [DEVNCSECU\svc-dkfx-process]
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.FormInfoView TO [DEVNCSECU\svc-dkfx-process]

-- Permissions for database stored procedures
GRANT EXECUTE ON GetFormInfo TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON InsertXmlIntoFormInfo TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON KfxIndxRcon_SelectRecFromKofaxInfo TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON KfxIndxRcon_UpdtRecScannedButMissingInTower TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON KfxIndxRcon_UpdateFormInfoTable TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON KfxIndxRcon_UpdtRecNotScanned TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON KfxIndxRcon_WklyBranchScan TO [DEVNCSECU\svc-dkfx-process]         -- remove when KofaxMargoBranchScanReport will replace KofaxIndexRecon weekly run
GRANT EXECUTE ON KfxIndxRcon_WklyRpt_MargoFormError TO [DEVNCSECU\svc-dkfx-process] -- remove when KofaxMargoBranchScanReport will replace KofaxIndexRecon weekly run
GRANT EXECUTE ON KfxIndxRcon_TruncateTables TO [DEVNCSECU\svc-dkfx-process]        
GRANT EXECUTE ON SelectFormInfo TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON UpdateFormInfo TO [DEVNCSECU\svc-dkfx-process]

--  Permissions for stored procedures for KofaxMargoBranchScanReport application
-- GRANT EXECUTE ON KofMargoBrScanRep_BranchScan TO [DEVNCSECU\svc-dkfx-process]
-- GRANT EXECUTE ON KofMargoBrScanRep_MargoFormError TO [DEVNCSECU\svc-dkfx-process]
GO

