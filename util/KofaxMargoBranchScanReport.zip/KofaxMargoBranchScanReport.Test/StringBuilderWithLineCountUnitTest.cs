﻿using System;
using System.Text.RegularExpressions;
using NUnit.Framework;

namespace KofaxMargoBranchScanReport.Test
{
    [TestFixture]
    class StringBuilderWithLineCountUnitTest
    {
        private StringBuilderWithLineCount sb;

        [OneTimeSetUp]
        public void SetupOnce()
        {
            sb = new StringBuilderWithLineCount();
        }

        [SetUp]
        public void Setup()
        {
            sb.Clear();
        }

        [Test]
        public void AppendLineTest()
        {
            int lineCount = 0; // running count of lines in StringBuilder

            // make sure StringBuilderWithLineCount initially is empty
            Assert.AreEqual(lineCount, sb.LineCount, "StringBuilderWithLineCount initially is not empty");
            Assert.AreEqual(string.Empty, sb.ToString(), "StringBuilderWithLineCount initially is not empty");

            // append blank line (default parameter value)
            lineCount = sb.LineCount;
            sb.AppendLine();
            //lineCount++;
            Assert.AreEqual(lineCount + 1, sb.LineCount, $"sb.AppendLine() added {sb.LineCount} lines instead of one");

            // append null - should add one line
            lineCount = sb.LineCount;
            sb.AppendLine(null);
            //lineCount++;
            Assert.AreEqual(lineCount + 1, sb.LineCount, $"sb.AppendLine(null) produced wrong result");

            // append blank string
            lineCount = sb.LineCount;
            sb.AppendLine(string.Empty);
            Assert.AreEqual(lineCount + 1, sb.LineCount, $"sb.AppendLine(string.Empty) produced wrong result");

            // append single line of text
            string hello = "Hello world";
            lineCount = sb.LineCount;
            sb.AppendLine(hello);
            Assert.AreEqual(lineCount + 1, sb.LineCount, $"Appending single line '{hello}' produced wrong result");
            Assert.IsTrue(sb.ToString().Contains(hello), $"After appending line '{hello}' StringBuilder does not contain this text");

            // append multiple lines
            string multiline = "Hello " + Environment.NewLine + "again \n"; // should add 3 lines
            lineCount = sb.LineCount;
            sb.AppendLine(multiline);
            Assert.AreEqual(lineCount + 3, sb.LineCount, $"Appending line with multiple NewLines produced wrong result");
        }

        [Test]
        public void AppendTest()
        {
            int lineCount = 0;                    // running count of lines in StringBuilder
            StringBuilderWithLineCount toAppend;  // StringBuilder to be appended

            // make sure StringBuilderWithLineCount initially is empty
            Assert.AreEqual(0, sb.LineCount, "StringBuilderWithLineCount initially is not empty");
            Assert.AreEqual(string.Empty, sb.ToString(), "StringBuilderWithLineCount initially is not empty");

            // append null
            lineCount = sb.LineCount;
            sb.AppendLine();  // add 1 line
            sb.Append(null);  // should not change LineCount
            Assert.AreEqual(lineCount + 1, sb.LineCount, $"sb.Append(null) produced wrong result");

            // append empty StringBuilderWithLineCount
            toAppend = new StringBuilderWithLineCount();
            lineCount = sb.LineCount;
            sb.Append(toAppend);       // should not change LineCount
            Assert.AreEqual(lineCount, sb.LineCount, $"Appending empty StringBuilder produced wrong result");

            // append StringBuilder with 1 line
            toAppend.AppendLine("Line 1");
            lineCount = sb.LineCount;
            sb.Append(toAppend);
            Assert.AreEqual(lineCount + 1, sb.LineCount, $"Appending StringBuilder with 1 line produced wrong result");

            // append StringBuilder with multiple lines
            lineCount = sb.LineCount;
            toAppend.Clear();
            toAppend.AppendLine("Hi" + Environment.NewLine + "there \n");
            lineCount += toAppend.LineCount;
            sb.Append(toAppend);
            Assert.AreEqual(lineCount, sb.LineCount, $"Appending StringBuilder with multiple lines produced wrong result");
        }

        [Test]
        public void InsertBeforeLastNewLineTest()
        {
            // make sure StringBuilderWithLineCount initially is empty
            Assert.AreEqual(0, sb.LineCount, "StringBuilderWithLineCount initially is not empty");
            Assert.AreEqual(string.Empty, sb.ToString(), "StringBuilderWithLineCount initially is not empty");

            // null parameter
            string str = "Hi there!";
            sb.AppendLine(str);
            sb.InsertBeforeLastNewLine(null);
            Assert.AreEqual(1, sb.LineCount, "Inserting null produced wrong result");
            Assert.AreEqual(str + Environment.NewLine, sb.ToString(), "After inserting null StringBuilder contains wrong text");

            // insert empty string
            sb.InsertBeforeLastNewLine(String.Empty);
            Assert.AreEqual(1, sb.LineCount, "Inserting empty string produced wrong result");
            Assert.AreEqual(str + Environment.NewLine, sb.ToString(), "After inserting empty string StringBuilder contains wrong text");

            // insert unique substring and verify it was inserted once and in the right place
            string toInsert = ((char)0x0C).ToString();
            sb.AppendLine(str);
            sb.AppendLine(str);
            sb.InsertBeforeLastNewLine(toInsert);
            string strng = sb.ToString();
            int count = CountSubstringAppearances(strng, toInsert);
            Assert.AreEqual(1, count, $"Inserted string appeared {count} times instead of once");
            Assert.AreEqual(strng.Length - Environment.NewLine.Length - toInsert.Length, strng.LastIndexOf(toInsert),
                $"Inserted substring '{toInsert}' appears on the wrong position in string '{strng}'");
        }

        [Test]
        public void ReplaceLastOccurrenceTest()
        {
            string str = "Hi there!";
            string target = ((char)0x0C).ToString();

            sb.AppendLine(str).InsertBeforeLastNewLine(target);
            sb.AppendLine(str).InsertBeforeLastNewLine(target);
            sb.AppendLine(str).InsertBeforeLastNewLine(target);

            string origString = sb.ToString();
            int origCount = CountSubstringAppearances(origString, target);

            // make sure replacing non-existent substring does not change StringBuilder
            sb.ReplaceLastOccurrence("ZZZ", "YYY");
            Assert.AreEqual(origString, sb.ToString(), "Replacing non-existent substring produced wrong result");

            // replace existing substring and verify results
            sb.ReplaceLastOccurrence(target + Environment.NewLine, Environment.NewLine);
            string updatedStr = sb.ToString();
            Assert.AreEqual(origCount - 1, CountSubstringAppearances(updatedStr, target),
                "Replacing existing substring produced wrong count of substring appearances");
            Assert.IsFalse(updatedStr.Substring(updatedStr.Length - Environment.NewLine.Length - target.Length - 1).Contains(target),
                "After replacing the end of StringBuilder still contains replaced string");
        }


        public int CountSubstringAppearances(string wholeString, string subString)
        {
            if (String.IsNullOrEmpty(wholeString) || String.IsNullOrEmpty(subString)) return 0;

            return new Regex(Regex.Escape(subString)).Matches(wholeString).Count;
        }

    }
}
