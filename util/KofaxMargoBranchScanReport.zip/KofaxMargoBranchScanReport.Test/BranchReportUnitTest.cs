﻿using System;
using NUnit.Framework;
using System.Data;
using System.IO;
using Rhino.Mocks;
using TestContext = NUnit.Framework.TestContext;


namespace KofaxMargoBranchScanReport.Test
{
    [TestFixture]
    class BranchReportUnitTest
    {
        private BranchReport branchReportObject;
        private log4net.ILog _mockLog;

        private StringBuilderWithLineCount report;
        private DataSet dataSet;
        char formFeed = (char)0x0C;

        [OneTimeSetUp]
        public void SetupOnce()
        {
            _mockLog = MockRepository.GenerateStub<log4net.ILog>();
            report = new StringBuilderWithLineCount();
            dataSet = Utils.CreateEmptyDataSet();
        }

        [SetUp]
        public void Setup()
        {
            Utils.TruncateTables(ref dataSet);
            report.Clear();
            branchReportObject = new BranchReport(dataSet, "0021", _mockLog);
            //privateObjBranchReport = new PrivateObject(branchReportObject);
        }

        [Test]
        public void WriteOneRowFoundTest()
        {
            // add 1st row which produces multiple data lines in the report
            DataRow row = Utils.GetRow(dataSet.Tables["BranchScanReport"], "TST00000001", "0021", 0, "FOUND",
                Utils.GetStringList(5, 8), // account list with 5  8-digit accounts
                Utils.GetStringList(7, 9)  /* SSN list with 7   9-digit SSNs */);

            branchReportObject.WriteOneRowFound(ref report, row);
            // assert that header with "PAGE   1" was added
            string text = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"Resources\Header_found_page1_03_04_19_br21.txt"));
            text = text.Replace("03/04/2019", DateTime.Now.ToString("MM/dd/yyyy"));
            Assert.IsTrue(report.ToString().Contains(text.TrimStart()));
            int lineCount = report.LineCount; // number of lines before insertion of 2nd data row

            // insert 2nd row that will produce 1 data line in the report
            row = Utils.GetRow(dataSet.Tables["BranchScanReport"], "TST00000002", "0021", 0, "FOUND", "00000022", "222222222");
            branchReportObject.WriteOneRowFound(ref report, row);
            // assert that exactly 1 row was added
            Assert.AreEqual(lineCount + 1, report.LineCount);

            // insert dummy data rows until length of 1st page of report is NumberOfLinesPerPageInReport
            row = Utils.GetRow(dataSet.Tables["BranchScanReport"], "DUMMY", "0021", 0, "FOUND", "99", "999999999");
            lineCount = report.LineCount;
            for (int i = 0; i < Properties.Settings.Default.NumberOfLinesPerPageInReport - lineCount; ++i)
            {
                branchReportObject.WriteOneRowFound(ref report, row);
            }
            // make sure we haven't completed first page of report by mistake
            Assert.IsFalse(report.ToString().Contains(formFeed.ToString()));
            Assert.AreEqual(Properties.Settings.Default.NumberOfLinesPerPageInReport, report.LineCount);

            // insert next data row which should go to the second page of report
            row = Utils.GetRow(dataSet.Tables["BranchScanReport"], "TST00000003", "0021", 0, "FOUND", "00000033", "333333333");
            branchReportObject.WriteOneRowFound(ref report, row);

            // assert that header with "PAGE  2" was inserted
            Assert.IsTrue(report.ToString().Contains(formFeed.ToString()));
            text = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"Resources\Header_Found_page1_03_04_19_br21.txt"));
            text = text.Replace("03/04/2019", DateTime.Now.ToString("MM/dd/yyyy"));
            text = text.Replace("PAGE   1", "PAGE   2");
            Assert.IsTrue(report.ToString().Contains(text.TrimStart()));
        }

        [Test]
        public void WriteOneRowMissingTest()
        {
            string text = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"Resources\Header_Missing_page1_03_04_19_br21.txt"));
            text = text.Replace("03/04/2019", DateTime.Now.ToString("MM/dd/yyyy"));
            // make sure report is empty initially
            Assert.AreEqual(0, report.LineCount, "Report is not blank initially");

            // add 1 row that produces single line in report
            DataRow row = Utils.GetRow(dataSet.Tables["BranchScanReport"], "TST00000000", "0021", 0, 
                "MISSING", Utils.GetStringList(1, 8), Utils.GetStringList(1, 9));
            branchReportObject.WriteOneRowMissing(ref report, row);
            // assert that header with "PAGE   1" was added
            Assert.IsTrue(report.ToString().Contains(text.Trim()), "Report with 1 data row does not contain Missing header with 'PAGE   1'");

            // add one row which produces multiple data lines in the report
            row = Utils.GetRow(dataSet.Tables["BranchScanReport"], "TST00000001", "0021", 0, "MISSING",
                Utils.GetStringList(5, 8), // account list with 5  8-digit accounts
                Utils.GetStringList(7, 9)  /* SSN list with 7   9-digit SSNs */);
            branchReportObject.WriteOneRowMissing(ref report, row);
            int lineCount = report.LineCount;

            // insert 2nd row that will produce 1 data line in the report
            row = Utils.GetRow(dataSet.Tables["BranchScanReport"], "TST00000002", "0021", 0, "MISSING", "00000022", "222222222");
            branchReportObject.WriteOneRowMissing(ref report, row);
            // assert that exactly 1 row was added
            Assert.AreEqual(lineCount + 1, report.LineCount);

            // insert dummy data rows until length of 1st page of report is NumberOfLinesPerPageInReport
            row = Utils.GetRow(dataSet.Tables["BranchScanReport"], "DUMMY", "0021", 0, "FOUND", "99", "999999999");
            lineCount = report.LineCount;
            int i = -1;
            for (i = 0; i < Properties.Settings.Default.NumberOfLinesPerPageInReport - lineCount; ++i)
            {
                branchReportObject.WriteOneRowMissing(ref report, row);
            }
            // make sure we haven't completed first page of report by mistake
            Assert.IsFalse(report.ToString().Contains(formFeed.ToString()));
            Assert.AreEqual(Properties.Settings.Default.NumberOfLinesPerPageInReport, report.LineCount);

            // insert next data row which should go to the second page of report
            row = Utils.GetRow(dataSet.Tables["BranchScanReport"], "TST00000003", "0021", 0, "FOUND", "00000033", "333333333");
            branchReportObject.WriteOneRowMissing(ref report, row);

            // assert that header with "PAGE  2" was inserted
            Assert.IsTrue(report.ToString().Contains(formFeed.ToString()));
            text = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"Resources\Header_Missing_page1_03_04_19_br21.txt"));
            text = text.Replace("03/04/2019", DateTime.Now.ToString("MM/dd/yyyy"));
            text = text.Replace("PAGE   1", "PAGE   2");
            Assert.IsTrue(report.ToString().Contains(text.TrimStart()));
        }

        // make data with several branches with Found and Missing data, one branch with Found only data, and one branch with
        // Missing only data. 
        // Make sure for Found branch Found header is there, while missing - not. 
        // Make sure for Missing branch Missing header is there, while found - not.
        [Test]
        public void GetBranchReportTest()
        {
            string FOUND_MESSAGE = "These items have been scanned into the imaging system and can be destroyed";
            string MISSING_MESSAGE = "These items have been created through Margo, but cannot be found in the imaging system";
            int count = 0;

            // branch 0001 has both Found and Missing records
            // Some previous versions failed to insert correct page delimiter [FF][CR][LF] between Found and missing parts of branch report if there
            // was exactly 1 Missing record - need to test it
            Utils.AddRows(dataSet.Tables["BranchScanReport"], "0001", "FOUND", ref count, 6);
            Utils.AddRows(dataSet.Tables["BranchScanReport"], "0001", "MISSING", ref count, 1);

            // branch 0002 has Found records only
            Utils.AddRows(dataSet.Tables["BranchScanReport"], "0002", "FOUND", ref count, 9);

            // branch 0003 has Missing records only
            Utils.AddRows(dataSet.Tables["BranchScanReport"], "0003", "MISSING", ref count, 10);

            // instantiate BranchReport for branch 0001
            branchReportObject = new BranchReport(dataSet, "0001", _mockLog);
            // verify that report for Branch 0001 has both Found and Missing headers
            report = branchReportObject.GetBranchReport(true); // parameter 'true' signals to make very first line of report blank
            Assert.IsTrue(report.ToString().Contains(FOUND_MESSAGE), "Report for branch 0001 does not contain Found header");
            Assert.IsTrue(report.ToString().Contains(MISSING_MESSAGE), "Report for branch 0001 does not contain Missing header");
            // verify that BranchReport ends with formFeed followed by NewLine
            string rep = report.ToString();
            Assert.AreEqual(3, rep.Length - rep.LastIndexOf(formFeed + Environment.NewLine),
                "BranchReport for branch 0001 does not end with formFeed followed by NewLine");

            // verify that very first line is blank and 1st page has correct number of lines
            var tuple = Utils.GetFirstLineAndLineCount(rep);
            Assert.IsTrue(string.IsNullOrEmpty(tuple.firstLine),
                $"Very first line of report for branch 0001 is not blank. First line: [{tuple.firstLine}]");
            int linesPerPage = Properties.Settings.Default.NumberOfLinesPerPageInReport;
            Assert.AreEqual(tuple.lineCount, linesPerPage,
                $"On first page of branch 0001 report there are {tuple.lineCount} lines, but expected {linesPerPage} lines");

            // instantiate BranchReport for branch 0002
            branchReportObject = new BranchReport(dataSet, "0002", _mockLog);
            report = branchReportObject.GetBranchReport(); // very first line of report is not blank by default
            rep = report.ToString();
            // verify that report for Branch 0002 has Found only header
            Assert.IsTrue(report.ToString().Contains(FOUND_MESSAGE), "Report for branch 0002 does not contain Found header");
            Assert.IsFalse(report.ToString().Contains(MISSING_MESSAGE), "Report for branch 0002 should not contain Missing header, but it does");
            // verify that very first line is not blank and 1st page has correct number of lines
            tuple = Utils.GetFirstLineAndLineCount(rep);
            Assert.IsFalse(string.IsNullOrEmpty(tuple.firstLine), "Very first line of report for branch 0002 is blank.");
            Assert.AreEqual(tuple.lineCount, linesPerPage,
                $"On first page of branch 0002 report there are {tuple.lineCount} lines, but expected {linesPerPage} lines");


            // instantiate BranchReport for branch 0003
            branchReportObject = new BranchReport(dataSet, "0003", _mockLog);
            // verify that report for Branch 0003 has Missing only header
            report = branchReportObject.GetBranchReport();
            Assert.IsFalse(report.ToString().Contains(FOUND_MESSAGE), "Report for branch 0003 should not contain Found header, but it does");
            Assert.IsTrue(report.ToString().Contains(MISSING_MESSAGE), "Report for branch 0003 does not contain Missing header");

            // instantiate BranchReport for nonexistent branch 0004
            branchReportObject = new BranchReport(dataSet, "0004", _mockLog);
            //privateObjBranchReport = new PrivateObject(branchReportObject);
            Assert.AreEqual(0, branchReportObject.FoundRowCount, "Report for branch 0004 must be blank, but contains some Found records");
            Assert.AreEqual(0, branchReportObject.MissingRowCount, "Report for branch 0004 must be blank, but contains some Missing records");
            report = branchReportObject.GetBranchReport();
            Assert.AreEqual(0, report.LineCount, "Report for non-existent branch 0004 have non-zero number of lines");
            Assert.IsFalse(report.ToString().Contains(FOUND_MESSAGE), "Report for branch 0004 must be blank, but contains Found header");
            Assert.IsFalse(report.ToString().Contains(MISSING_MESSAGE), "Report for branch 0004 must be blank, but contains Missing header");
        }

        /// <summary>
        /// Verifies that fields _foundRows and _missingRows include only records with correct status
        /// </summary>
        [Test]
        public void BranchReportTest()
        {
            int count = 0;

            Utils.AddRows(dataSet.Tables["BranchScanReport"],"0001", null, ref count, 1);
            Utils.AddRows(dataSet.Tables["BranchScanReport"], "0001", "Not Found", ref count, 3);
            Utils.AddRows(dataSet.Tables["BranchScanReport"], "0001", "COMPLETE", ref count, 3);
            Utils.AddRows(dataSet.Tables["BranchScanReport"], "0001", "PARTIAL", ref count, 4);
            Utils.AddRows(dataSet.Tables["BranchScanReport"], "0001", "FOUND", ref count, 5);
            Utils.AddRows(dataSet.Tables["BranchScanReport"], "0001", "MISSING", ref count, 6);

            branchReportObject = new BranchReport(dataSet, "0001", _mockLog);
            Assert.AreEqual(5, branchReportObject.FoundRowCount, "Wrong count of Found records");
            Assert.AreEqual(6, branchReportObject.MissingRowCount, "Wrong count of Missing records");
        }


    }
}
