﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using NUnit.Framework;
using Assert = NUnit.Framework.Assert;

namespace KofaxMargoBranchScanReport.Test
{
    [TestFixture]
    class WeeklyReportUnitTest
    {
        private StringBuilderWithLineCount reportSB;
        private DataSet dataSet;
        char formFeed = (char)0x0C;

        private WeeklyReport weeklyReportObject;

        [OneTimeSetUp]
        public void SetupOnce()
        {
            reportSB = new StringBuilderWithLineCount();
            dataSet = Utils.CreateEmptyDataSet();
        }

        [SetUp]
        public void Setup()
        {
            Utils.TruncateTables(ref dataSet);
            reportSB.Clear();
            weeklyReportObject = new WeeklyReport();
        }

        /// <summary>
        /// Generates Branch Scan report with 3 branches: two with Found and Missing records and last branch
        /// with Found records only. Then verifies report formatting.
        /// </summary>
        [Test]
        public void CreateFoundMissingReportTest1()
        {
            int count = 0;
            DataTable tbl = dataSet.Tables["BranchScanReport"];

            // populate DataSet - branches 0001 and 0002 both with Found and Missing records, branch 0003 - Found records only
            Utils.AddRows(tbl, "0001", "FOUND", ref count, 47);
            AddMultilineRow(tbl, "0001", "FOUND", ref count, 15);
            Utils.AddRows(tbl, "0001", "FOUND", ref count, 5);
            Utils.AddRows(tbl, "0001", "MISSING", ref count, 45);
            AddMultilineRow(tbl, "0001", "MISSING", ref count, 15);
            Utils.AddRows(tbl, "0001", "MISSING", ref count, 5);

            Utils.AddRows(tbl, "0002", "FOUND", ref count, 6);
            Utils.AddRows(tbl, "0002", "MISSING", ref count, 1);

            Utils.AddRows(tbl, "0003", "FOUND", ref count, 7);

            // create Branch Scan Report for all branches in DataSet
            reportSB = weeklyReportObject.CreateFoundMissingReport(dataSet);
            string report = reportSB.ToString();

            // verify that very first line is blank
            var tuple = Utils.GetFirstLineAndLineCount(report);
            Assert.IsTrue(string.IsNullOrEmpty(tuple.firstLine),
                $"Very first line of report for branch 0001 is not blank. First line: [{tuple.firstLine}]");
            int linesPerPage = Properties.Settings.Default.NumberOfLinesPerPageInReport;
            Assert.AreEqual(tuple.lineCount, linesPerPage,
                $"On first page of branch 0001 report there are {tuple.lineCount} lines, but expected {linesPerPage} lines");

            // verify that total number of pages is correct (by number of formFeeds)
            var pages = report.Split(new char[] { (char)0x0C }, StringSplitOptions.RemoveEmptyEntries);
            Assert.AreEqual(7, pages.Length, "Wrong number of lines on first page.");

            // verify that page delimiter between branch 1 and branch 2 is correct
            string headerStart = $"1 0002  {DateTime.Now:MM/dd/yyyy}"; // beginning of header for Branch 0002
            var lines = Utils.GetAllLinesFromString(report);
            string lastLineOfBranch0001 = GetLineBefore(lines, headerStart);
            Assert.IsNotNull(lastLineOfBranch0001, "Last line of branch 0001 is null");
            Assert.AreEqual(formFeed.ToString(), lastLineOfBranch0001.Substring(lastLineOfBranch0001.Length - 1),
                "Last line of branch 0001 does not end with [FF]. Last line of branch 001: \n" + lastLineOfBranch0001);

            // verify that very last line ends with [CR][LF][FF]
            Assert.AreEqual(Environment.NewLine + formFeed.ToString(),
                report.Substring(report.Length - 1 - Environment.NewLine.Length),
                "Very last line does not end with [CR][LF][FF]");
        }

        [Test]
        public void CreateFoundMissingReportTest2()
        {
            int count = 0;
            DataTable tbl = dataSet.Tables["BranchScanReport"];
            // populate DataSet - branches 0001  with Found and Missing records, branch 0002 - Missing records only
            Utils.AddRows(tbl, "0001", "FOUND", ref count, 47);
            AddMultilineRow(tbl, "0001", "FOUND", ref count, 15);
            Utils.AddRows(tbl, "0001", "FOUND", ref count, 5);
            Utils.AddRows(tbl, "0001", "MISSING", ref count, 1);
            Utils.AddRows(tbl, "0002", "MISSING", ref count, 5);

            // create Branch Scan Report for all branches in DataSet
            reportSB = weeklyReportObject.CreateFoundMissingReport(dataSet);
            string report = reportSB.ToString();

            // verify that very first line is blank
            var tuple = Utils.GetFirstLineAndLineCount(report);
            Assert.IsTrue(string.IsNullOrEmpty(tuple.firstLine),
                $"Very first line of report for branch 0001 is not blank. First line: [{tuple.firstLine}]");
            int linesPerPage = Properties.Settings.Default.NumberOfLinesPerPageInReport;
            Assert.AreEqual(tuple.lineCount, linesPerPage,
                $"On first page of branch 0001 report there are {tuple.lineCount} lines, but expected {linesPerPage} lines");

            // verify that total number of pages is correct (by number [FF][CR][LF])
            var pages = report.Split(new string[] { formFeed + Environment.NewLine }, StringSplitOptions.RemoveEmptyEntries);
            Assert.AreEqual(4, pages.Length, "Wrong number of pages (using String.Split with RemoveEmptyEntries)");

            // verify that very last line ends with [CR][LF][FF]
            Assert.AreEqual(Environment.NewLine + formFeed.ToString(),
                report.Substring(report.Length - 1 - Environment.NewLine.Length),
                "Very last line does not end with [CR][LF][FF]");
        }

        [Test]
        public void CreatePartialReportTest()
        {
            int count = 0;
            DataTable tbl = dataSet.Tables["MargoFormErrorReport"];
            Utils.AddRows(tbl, "0001", "PARTIAL", ref count, 52);
            AddMultilineRow(tbl, "0001", "PARTIAL", ref count, 17);
            Utils.AddRows(tbl, "0001", "PARTIAL", ref count, 4);

            // create Partial Report for all branches in DataSet
            reportSB = weeklyReportObject.CreatePartialReport(dataSet);
            string report = reportSB.ToString();

            // verify that very first line is blank
            var tuple = Utils.GetFirstLineAndLineCount(report);
            Assert.IsTrue(string.IsNullOrEmpty(tuple.firstLine),
                $"Very first line of Partial report is not blank. First line: [{tuple.firstLine}]");
            int linesPerPage = Properties.Settings.Default.NumberOfLinesPerPageInReport;
            Assert.AreEqual(tuple.lineCount, linesPerPage,
                $"On first page of Partial report there are {tuple.lineCount} lines, but expected {linesPerPage} lines");

            // verify that [FF][CR][LF] appears exactly once (between 1st and 2nd pages)
            Assert.IsTrue(
                report.IndexOf(formFeed + Environment.NewLine) == report.LastIndexOf(formFeed + Environment.NewLine),
                "[FF][CR][LF] appears more than once in Partial report");
            Assert.IsTrue(report.IndexOf(formFeed + Environment.NewLine) > 0,
                "[FF][CR][LF] does not appear in Partial report");

            // verify that very last line ends with [CR][LF], not [FF][CR][LF] or [CR][LF][FF]
            string lastChars = report.Substring(report.Length - 4);
            Assert.IsTrue(lastChars.Contains(Environment.NewLine) && !lastChars.Contains(formFeed),
                $"Very last line of Partial report should end with [CR][LF], but it ends with '{lastChars}'");
        }

        // ======================  Helper methods ====================== 

        private void AddMultilineRow(DataTable tbl, string branch, string status, ref int count, int numOfSSNs)
        {
            count += 1;
            string ssnList = "";
            for (int i = 1; i <= numOfSSNs; ++i)
            {
                ssnList += i.ToString("D9") + "; ";
            }

            ssnList = ssnList.TrimEnd(';', ' ');
            string uid = "TST" + count.ToString("D8");
            DataRow row = Utils.GetRow(tbl, uid, branch, 0, status, "000099", ssnList);
            tbl.Rows.Add(row);
        }

        private string GetLineBefore(List<string> lines, string filter)
        {
            for (int i = 0; i < lines.Count; ++i)
            {
                if (lines[i].StartsWith(filter))
                {
                    return i == 0 ? null : lines[i - 1];
                }
            }
            return null;
        }

    }
}
