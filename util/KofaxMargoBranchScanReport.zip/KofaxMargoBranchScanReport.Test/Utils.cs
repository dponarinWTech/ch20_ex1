﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace KofaxMargoBranchScanReport.Test
{
    class Utils
    {
        public static void TruncateTables(ref DataSet ds)
        {
            ds.Tables["MargoFormErrorReport"]?.Rows?.Clear();
            ds.Tables["BranchScanReport"]?.Rows?.Clear();
        }

        public static DataSet CreateEmptyDataSet()
        {
            DataSet ds = new DataSet("testDataSet");
            DataTable tbl1 = ds.Tables.Add("MargoFormErrorReport");
            AddColumns(ref tbl1);

            DataTable tbl2 = ds.Tables.Add("BranchScanReport");
            AddColumns(ref tbl2);

            return ds;
        }

        public static void AddColumns(ref DataTable table)
        {
            DataColumn uid = table.Columns.Add("UniqueID", typeof(string));
            uid.AllowDBNull = false;
            table.Columns.Add("BranchNum", typeof(string));
            table.Columns.Add("EmpID", typeof(string));
            table.Columns.Add("WorkstationID", typeof(string));
            table.Columns.Add("NumberOfDays", typeof(int));
            table.Columns.Add("Status", typeof(string));
            table.Columns.Add("CreateDate", typeof(DateTime));
            table.Columns.Add("AccountList", typeof(string));
            table.Columns.Add("SSNList", typeof(string));
        }

        public static DataRow GetRow(DataTable tbl, string uid, string branch = "0021", int numOfDays = 0,
            string status = null, string accList = null, string ssnList = null)
        {
            DataRow row = tbl.NewRow();
            row["UniqueID"] = uid;
            row["BranchNum"] = branch;
            row["EmpID"] = "S12345D";
            row["WorkstationID"] = "WWSN0227";
            row["NumberOfDays"] = numOfDays;
            row["Status"] = status;
            row["CreateDate"] = DateTime.Now.AddDays(-1 * numOfDays).Date;
            row["AccountList"] = accList;
            row["SSNList"] = ssnList;
            return row;
        }

        /// <summary>
        /// Returns string with semicolon-separated generated accounts. 
        /// First parameter: desired number of accounts in the string (maximum 100).
        /// Second parameter determines number of digits in the account (maximum 12)
        /// 
        /// </summary>
        /// <param name="numOfAccounts"></param>
        /// <param name="numOfDigits"></param>
        /// <returns></returns>
        public static string GetStringList(int numOfAccounts, int numOfDigits = 9)
        {
            // if invalid numOfDigits received set it to dafault value 9
            if (numOfDigits <= 0 || numOfDigits > 12) { numOfDigits = 9; }

            string result = "";
            for (int i = 1; i <= Math.Min(numOfAccounts, 100); ++i)
            {
                result += i.ToString("D" + numOfDigits.ToString()) + "; ";
            }
            result = result.TrimEnd(new char[] { ';', ',', '.', ' ' });
            return result;
        }

        // <param name="count">Running variable used as ID field of the inserted row</param>

        /// <summary>
        /// Adds specified number of rows, all with specified branch (<paramref name="branch"/>) and status (<paramref name="status"/>),
        /// to the specified table (<paramref name="tbl"/>), each with single SSN "999999999" and single Account "000099".
        /// UID in the rows are "TST" and number; starting number is initial value of '<paramref name="count"/>' + 1. 
        /// </summary>
        /// <param name="tbl"></param>
        /// <param name="branch"></param>
        /// <param name="status"></param>
        /// <param name="count">Running variable used as ID field of the inserted row</param>
        /// <param name="numOfRows"></param>
        public static void AddRows(DataTable tbl, string branch, string status, ref int count, int numOfRows)
        {
            DataRow row;
            int i;
            for (i = 1; i <= numOfRows; ++i)
            {
                string uid = "TST" + (count + i).ToString("D8");
                row = GetRow(tbl, uid, branch, 0, status, "000099", "999999999");
                tbl.Rows.Add(row);
            }
            count += i;
        }


        public static Stream GenerateStreamFromString(string s)
        {
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;

            // Don't dispose StreamWriter: it is just a wrapper around the base stream, and doesn't use any resources that need to be disposed;
            // disposing StreamWriter will close the stream that we're returning
            return stream;
        }

        /// <summary>
        /// Returns tuple with first line and number of lines on first page in the string representing a branch report.
        /// Page delimiter is FormFeed.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static (string firstLine, int lineCount) GetFirstLineAndLineCount(string input)
        {
            string formFeedStr = ((char)0x0C).ToString();
            int counter = 1;
            string line1 = string.Empty;
            using (var stream = GenerateStreamFromString(input))
            {
                using (StreamReader reader = new StreamReader(stream))
                {
                    line1 = reader.ReadLine();
                    string tmpLine = string.Empty;
                    if (!line1.Contains(formFeedStr.ToString()))
                    {
                        while (!tmpLine.Contains(formFeedStr.ToString()))
                        {
                            counter++;
                            tmpLine = reader.ReadLine();
                        }
                    }
                }
            }

            return (firstLine: line1, lineCount: counter);
        }

        /// <summary>
        /// Breaks down specified string into lines and returns them (in natural order) as a List.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static List<string> GetAllLinesFromString(string input)
        {
            List<string> result = new List<string>();
            string currentLine;
            using (StringReader strReader = new StringReader(input))
            {
                while ((currentLine = strReader.ReadLine()) != null)
                {
                    result.Add(currentLine);
                }
            }
            return result;
        }

    }
}
