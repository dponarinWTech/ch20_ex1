﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using log4net;

namespace KofaxMargoBranchScanReport
{

    /// <summary>
    /// Contains implementations of methods used by all derived classes (BranchReport and PartialReport).
    /// </summary>
    public class Report
    {
        public static string FORM_FEED = ((char)0x0C).ToString();

        /// <summary>
        /// Returns line with given word followed by semicolon and, if space allows, blank space. 
        /// If word with semicolon is longer than '<paramref name="slotSize"/>' characters - throws ArgumentException.
        /// </summary>
        /// <param name="word"></param>
        /// <param name="slotSize"></param>
        /// <returns></returns>
        public string GetNewLineWithWord(string word, int slotSize)
        {
            if (String.IsNullOrWhiteSpace(word)) return String.Empty;

            if ((word + "; ").Length < slotSize)
            {
                return word + "; ";
            }
            else if ((word + ";").Length == slotSize)
            {
                return word + ";";
            }
            else // word is too long
            {
                throw new ArgumentException($"GetNewLineWithWord(): entry '{word}' in input string exceeds slot size = {slotSize}.");
            }
        }

        /// <summary>
        /// Splits string on 'words' and combines them into strings not longer then number of characters defined by '<paramref name="slotSize"/>'.
        /// Returns array of newly created strings.
        /// </summary>
        /// <remarks>
        /// Original string is splitted on commas, semicolons and blank spaces.
        /// Single 'words' in return array strings are separated by semicolons.
        /// </remarks>
        /// <param name="originalString"></param>
        /// <param name="slotSize"></param>
        /// <returns></returns>
        public string[] SplitStringToFormattedArray(string originalString, int slotSize)
        {
            if (String.IsNullOrWhiteSpace(originalString)) { return new string[0]; }

            List<string> result = new List<string>();
            string[] words = originalString.Split(new string[] { ",", ";" }, StringSplitOptions.RemoveEmptyEntries);

            string currentLine = String.Empty;
            foreach (string wrd in words)
            {
                string word = wrd.Trim();
                if (string.IsNullOrWhiteSpace(word)) continue;   
                if (currentLine.Length + word.Length + "; ".Length <= slotSize)
                {
                    currentLine += word + "; ";
                }
                else if (currentLine.Length + word.Length + ";".Length == slotSize)
                {
                    currentLine += word + ";";
                }
                else
                {
                    result.Add(currentLine);
                    currentLine = GetNewLineWithWord(word, slotSize);
                }
            }
            if (currentLine.Length > 0)
            {
                result.Add(currentLine);
            }

            // remove semicolon and blank space at the end of last string
            string trimmedLastLine = result.Last().TrimEnd(new char[] { ' ', ';' });
            result[result.Count - 1] = trimmedLastLine;

            return result.ToArray();
        }

        /// <summary>
        /// Should be called immediately before inserting a line to report.
        /// If last page already has exactly NumberOfLinesPerPageInReport lines, it inserts formFeed and starts new page with header.
        /// Returns one-char string that will be a first character of the next row; it is "0" if the header was inserted 
        /// and blank otherwise.
        /// </summary>
        /// <param name="branchReport"></param>
        /// <param name="CreateHeader">Delegate that points to the method generating appropriate page header</param>
        /// <returns>"0" if the header was inserted, blank 1-character string otherwise.</returns>
        public string TreatNewPage(ref StringBuilderWithLineCount branchReport, Func<int, StringBuilderWithLineCount> CreateHeader)
        {
            int linesPerPage = Properties.Settings.Default.NumberOfLinesPerPageInReport; // for convenience
            string firstChar = " ";

            // if number of lines in report divides by linesPerPage (i.e. last page is completed) - insert form feed
            // and start new page (i.e. add page header)
            if (branchReport.LineCount % linesPerPage == 0)
            {
                branchReport.InsertBeforeLastNewLine(FORM_FEED);
                branchReport.Append(CreateHeader(branchReport.LineCount));
                firstChar = "0";
            }
            else if (branchReport.LineCount == 1) // case when we're dealing with very 1st (blank) line of report
            {
                branchReport.Append(CreateHeader(branchReport.LineCount));
                firstChar = "0";
            }

            return firstChar;
        }
    } // end class Report 


    /// <summary>
    /// An object representing report for one branch. It contains methods for generating Found report, Missing report 
    /// and combined Branch report.
    /// </summary>
    public class BranchReport : Report
    {
        const int FOUND_SSN_LINE_LENGTH = 33;
        const int FOUND_ACCOUNT_LINE_LENGTH = 38;
        const int MISSING_SSN_LINE_LENGTH = 22;
        const int MISSING_ACCOUNT_LINE_LENGTH = 36;

        const string FORMAT_STRING_FOUND = "{0,-3}{1,-13}{2,-15}{3,-16}{4,-13}{5,-34}{6,-38}";
        const string FORMAT_STRING_MISSING = "{0,-3}{1,-13}{2,-15}{3,-16}{4,-13}{5,-23}{6,-37}{7,-12}";

        private DataRow[] _foundRows;
        private DataRow[] _missingRows;
        private string _branch;
        private ILog _log;

        //private bool _isVeryFirstLine;  // flag indicating very first line of weekly report - this line should be blank

        public int FoundRowCount { get { return _foundRows.Length; } }

        public int MissingRowCount { get { return _missingRows.Length; } }

        public BranchReport(DataSet dataSet, string branch, ILog log)
        {
            // checking that DataSet is not null and has required tables was done in class WeeklyRecon, so the DataSet assumed to be valid
            ValidateArguments(branch);
            _branch = branch;
            _foundRows = dataSet.Tables["BranchScanReport"]
                .Select("Status = 'FOUND' AND BranchNum =" + _branch, "BranchNum ASC, UniqueID ASC")
                ?? new DataRow[0];
            _missingRows = dataSet.Tables["BranchScanReport"]
                .Select("Status = 'MISSING'AND BranchNum =" + _branch, "BranchNum ASC, NumberOfDays DESC, UniqueID ASC")
                ?? new DataRow[0];
            _log = log;
        }

        private bool ValidateArguments(string branch)
        {
            if (String.IsNullOrWhiteSpace(branch))
            {
                throw new ArgumentException("BranchReport object constructor: String argument 'branch' cannot be null or blank.");
            }
            return true;
        }

        public StringBuilderWithLineCount GetBranchReport(bool isVeryFirst = false)
        {
            _log.Info("\t\t Current Branch = " + _branch);
            _log.Info("\t\t Number of Found Rows = " + FoundRowCount);
            _log.Info("\t\t Number of Missing Rows = " + MissingRowCount + Environment.NewLine);

            StringBuilderWithLineCount branchReport = GetFoundBranchReport(isVeryFirst);

            if (FoundRowCount > 0)
            {
                PadPage(branchReport);
            }

            if (MissingRowCount > 0)
            {
                GetMissingBranchReport(ref branchReport);
            }

            // add form feed at the end of branch's subreport (if the report is not empty)
            if (branchReport.LineCount > 0)
            {
                branchReport.InsertBeforeLastNewLine(FORM_FEED);
            }

            return branchReport;
        }

        /// <summary>
        /// Returns Found part of branch report created from scratch.
        /// </summary>
        /// <returns></returns>
        public StringBuilderWithLineCount GetFoundBranchReport(bool isVeryFirst = false)
        {
            StringBuilderWithLineCount branchReport = new StringBuilderWithLineCount();

            // adding blank line if it is a beginning of Branch Scan report
            if (isVeryFirst)
            {
                branchReport.AppendLine("");
            }

            for (int i = 0; i < _foundRows.Length; i++)
            {
                WriteOneRowFound(ref branchReport, _foundRows[i]);
            }

            return branchReport;
        }

        /// <summary>
        /// Writes to Found report one data row (that may span over multiple report lines). Checks if it is the end of page, and if so 
        /// inserts formFeed (if there are more Found rows in this report) and starts new page with the header.
        /// </summary>
        /// <param name="branchReport">Report to be updated</param>
        /// <param name="row">Data row </param>
        /// <returns>Updated report</returns>
        public void WriteOneRowFound(ref StringBuilderWithLineCount branchReport, DataRow row)
        {
            string ssnOriginalString = row.IsNull("SSNList") ? null : row.Field<string>("SSNList");
            string[] ssnLines = SplitStringToFormattedArray(ssnOriginalString, FOUND_SSN_LINE_LENGTH);
            string accountOriginalString = row.IsNull("AccountList") ? null : row.Field<string>("AccountList");
            string[] accountLines = SplitStringToFormattedArray(accountOriginalString, FOUND_ACCOUNT_LINE_LENGTH);

            int maxLines = Math.Max(ssnLines.Length, accountLines.Length); // number of formatted report lines produced by this DataRow
            if (maxLines == 0) maxLines = 1;
            string firstChar = " ";

            for (int i = 0; i < maxLines; ++i)
            {
                string ssn = ssnLines.Length >= i + 1 ? ssnLines[i] : null;
                string acc = accountLines.Length >= i + 1 ? accountLines[i] : null;
                string uid = i == 0 ? row["UniqueID"] as String : null;
                string workstationID = i == 0 ? row.IsNull("WorkstationID") ? String.Empty : row["WorkstationID"] as String : String.Empty;
                string empID = i == 0 ? row.IsNull("EmpID") ? String.Empty : row["EmpID"] as String : String.Empty;
                string createDate;
                if (i == 0)
                {
                    createDate = row.IsNull("CreateDate") || row["CreateDate"] == null ? String.Empty : row.Field<DateTime>("CreateDate").ToShortDateString();
                }
                else { createDate = String.Empty; }

                firstChar = TreatNewPage(ref branchReport, CreateFoundHeader);
                branchReport.AppendLine(String.Format(FORMAT_STRING_FOUND, firstChar, uid, createDate, workstationID, empID, ssn, acc));
                firstChar = " "; // reset first character to blank for the case if the header was inserted and firstChar was set to '0'
            }

        }


        public StringBuilderWithLineCount CreateFoundHeader(int currentLineCounter)
        {
            StringBuilderWithLineCount result = new StringBuilderWithLineCount();

            String headerDate = DateTime.Now.ToString("MM/dd/yyyy");
            int pageNumber = currentLineCounter / Properties.Settings.Default.NumberOfLinesPerPageInReport + 1;

            //  Line Length = 133 characters; Max Line Count/Page = [Properties.Settings.Default.NumberOfLinesPerPageInReport] Lines
            result.AppendLine(String.Format("{0,-2}{1,-6}{2,-47:mm/dd/yyyy}{3,-68}{4,-7}{5,-4}", "1", _branch, headerDate, "BRANCH SCANNING REPORT", "PAGE", pageNumber));
            result.AppendLine("");
            result.AppendLine(String.Format("{0,-51}{1,-30}", "", "MARGO Forms Scanned Into Image"));
            result.AppendLine(String.Format("{0,-35}{1,-62}", "", "These items have been scanned into the imaging system and can be destroyed."));
            result.AppendLine("");
            result.AppendLine(String.Format("{0,-60}{1,-9}{2}", "", "Branch", _branch));
            result.AppendLine("");
            result.AppendLine(String.Format("{0,-3}{1,-13}{2,-15}{3,-16}{4,-13}{5,-34}{6,-38}",
                                            "", "Unique ID", "Document Date", "Workstation ID", "Employee ID", "SSNs", "Account Numbers"));
            result.AppendLine("");

            return result;
        }

        public void GetMissingBranchReport(ref StringBuilderWithLineCount branchReport)
        {
            // branchReport cannot be null
            if (branchReport == null)
            {
                _log.Error($"Error creating report for branch {_branch}: method GetMissingBranchReport() received null as a parameter");
                throw new ArgumentNullException(nameof(branchReport));
            }

            // branchReport must have LineCount that divides by NumberOfLinesPerPageInReport, except for the case when it's very first branch in report
            // and there are no Found rows - then report at this point includes one blank line
            if (branchReport.LineCount % Properties.Settings.Default.NumberOfLinesPerPageInReport != 0 && branchReport.LineCount != 1)
            {
                string msg = $"Error creating report for branch {_branch}: ";
                msg += "method GetMissingBranchReport() received parameter with LineCount not dividable by NumberOfLinesPerPageInReport. ";
                msg += $"LineCount = {branchReport.LineCount}, NumberOfLinesPerPageInReport = {Properties.Settings.Default.NumberOfLinesPerPageInReport}";
                _log.Error(msg);
                throw new ArgumentException("msg");
            }

            for (int i = 0; i < _missingRows.Length; i++)
            {
                WriteOneRowMissing(ref branchReport, _missingRows[i]);
            }
        }

        /// <summary>
        /// Writes to Missing report "in place" one data row (that may span over multiple report lines). Checks if it is the end of page, and if so 
        /// inserts formFeed and starts new page with the header.
        /// </summary>
        /// <param name="branchReport"> Report to be updated </param>
        /// <param name="row"> Data row </param>
        /// <returns></returns>
        public void WriteOneRowMissing(ref StringBuilderWithLineCount branchReport, DataRow row)
        {
            string ssnOriginalString = row.IsNull("SSNList") ? null : row.Field<string>("SSNList");
            string[] ssnLines = SplitStringToFormattedArray(ssnOriginalString, MISSING_SSN_LINE_LENGTH);
            string accountOriginalString = row.IsNull("AccountList") ? null : row.Field<string>("AccountList");
            string[] accountLines = SplitStringToFormattedArray(accountOriginalString, MISSING_ACCOUNT_LINE_LENGTH);

            int maxLines = Math.Max(ssnLines.Length, accountLines.Length); // number of formatted report lines produced by this DataRow
            if (maxLines == 0) maxLines = 1;
            string firstChar = " ";

            for (int i = 0; i < maxLines; ++i)
            {
                string ssn = ssnLines.Length >= i + 1 ? ssnLines[i] : null;
                string acc = accountLines.Length >= i + 1 ? accountLines[i] : null;
                string uid = i == 0 ? row["UniqueID"] as String : null;
                string workstationID = i == 0 ? row["WorkstationID"] as String : String.Empty;
                string empID = i == 0 ? row["EmpID"] as String : String.Empty;
                string numOfDays = i == 0 ? (row.IsNull("NumberOfDays") ? String.Empty : row.Field<int>("NumberOfDays").ToString()) : String.Empty;
                string createDate;
                if (i == 0)
                {
                    createDate = row.IsNull("CreateDate") || row["CreateDate"] == null ? String.Empty : row.Field<DateTime>("CreateDate").ToShortDateString();
                }
                else { createDate = String.Empty; }

                firstChar = TreatNewPage(ref branchReport, CreateMissingHeader);
                branchReport.AppendLine(String.Format(FORMAT_STRING_MISSING, firstChar, uid, createDate, workstationID, empID, ssn, acc, numOfDays));
                firstChar = " ";
            }

        }

        public StringBuilderWithLineCount CreateMissingHeader(int currentLineCounter)
        {
            StringBuilderWithLineCount result = new StringBuilderWithLineCount();

            String headerDate = DateTime.Now.ToString("MM/dd/yyyy");
            int pageNumber = currentLineCounter / Properties.Settings.Default.NumberOfLinesPerPageInReport + 1;

            //  Line Length = 133 characters; Max Line Count/Page = [Properties.Settings.Default.NumberOfLinesPerPageInReport] Lines
            result.AppendLine(String.Format("{0,-2}{1,-6}{2,-47}{3,-68}{4,-7}{5,-4}",
                                            "1", _branch, headerDate, "BRANCH SCANNING REPORT", "PAGE", pageNumber));
            result.AppendLine("");
            result.AppendLine(String.Format("{0,-51}{1,-30}", "", "MARGO Forms Missing From Image"));
            result.AppendLine(String.Format("{0,-4}{1,-112}", "", "These items have been created through Margo, but cannot be found in the imaging system.  Please scan these items."));
            result.AppendLine("");
            result.AppendLine(String.Format("{0,-4}{1,-114}", "", "Use the path below to access Image System Services instructions or email ImageSystemServices@ncsecu.org for further assistance."));
            result.AppendLine(String.Format("{0,-10}{1,-111}", "", "S:\\Shared Forms, Instructions, etc\\Record Services\\User Manuals\\Unique ID Scanning Report Instructions.doc"));
            result.AppendLine("");
            result.AppendLine(String.Format("{0,-60}{1,-9}{2}", "", "Branch", _branch));
            result.AppendLine("");
            result.AppendLine(String.Format("{0,-3}{1,-13}{2,-15}{3,-16}{4,-13}{5,-23}{6,-37}{7,-12}",
                                            "", "Unique ID", "Document Date", "Workstation ID", "Employee ID", "SSNs", "Account Numbers", "Days Missing"));
            result.AppendLine("");

            return result;
        }

        /// <summary>
        /// Pads last page of given StringBuilderWithLineCount with blank lines to make page size equal to number of lines per page from config file. 
        /// Adds FormFeed before very last [CR][LF].
        /// </summary>
        /// <param name="branchReport"></param>
        /// <returns></returns>
        public void PadPage(StringBuilderWithLineCount branchReport)
        {
            int linesPerPage = Properties.Settings.Default.NumberOfLinesPerPageInReport; // for convenience
            // do nothing if we don't need to pad
            if (branchReport.LineCount % linesPerPage == 0) { return; }

            while (branchReport.LineCount % linesPerPage != 0)
            {
                branchReport.AppendLine("");
            }
        }

    } // end class BranchReport


    public class PartialReport : Report
    {
        const int PARTIAL_SSN_LINE_LENGTH = 22;
        const int PARTIAL_ACCOUNT_LINE_LENGTH = 36;
        const string FORMAT_STRING_PARTIAL = "{0,-3}{1,-13}{2,-15}{3,-16}{4,-13}{5,-23}{6,-37}{7,-12}";

        private DataRow[] _partialRows;

        public int RowCount { get { return _partialRows.Length; } }

        public PartialReport(DataSet dataSet)
        {
            _partialRows = dataSet.Tables["MargoFormErrorReport"].Select(null, "UniqueID ASC") ?? new DataRow[0];
        }

        public StringBuilderWithLineCount GetPartialReport()
        {
            StringBuilderWithLineCount partialReport = new StringBuilderWithLineCount();

            if (RowCount == 0)
            {
                return partialReport;
            }

            for (int i = 0; i < RowCount; i++)
            {
                if (i == 0) // very first line of report must be blank
                {
                    partialReport.AppendLine("");
                }

                WriteOneRowPartial(ref partialReport, _partialRows[i]);
            }

            return partialReport;
        }

        /// <summary>
        /// Writes to Partial report one data row (that may span over multiple report lines). It checks if it is the end 
        /// of page, and if so inserts formFeed and starts new page with the header.
        /// </summary>
        /// <param name="partialReport">Report to be updated</param>
        /// <param name="row">Data row</param>
        /// <returns>Updated report</returns>
        public void WriteOneRowPartial(ref StringBuilderWithLineCount partialReport, DataRow row)
        {
            string ssnOriginalString = row.IsNull("SSNList") ? null : row.Field<string>("SSNList");
            string[] ssnLines = SplitStringToFormattedArray(ssnOriginalString, PARTIAL_SSN_LINE_LENGTH);
            string accountOriginalString = row.IsNull("AccountList") ? null : row.Field<string>("AccountList");
            string[] accountLines = SplitStringToFormattedArray(accountOriginalString, PARTIAL_ACCOUNT_LINE_LENGTH);

            int maxLines = Math.Max(ssnLines.Length, accountLines.Length);
            if (maxLines == 0) maxLines = 1;
            string firstChar = " ";

            for (int i = 0; i < maxLines; ++i)
            {
                string ssn = ssnLines.Length >= i + 1 ? ssnLines[i] : null;
                string acc = accountLines.Length >= i + 1 ? accountLines[i] : null;
                string uid = i == 0 ? row["UniqueID"] as String : null;
                string workstationID = i == 0 ? row["WorkstationID"] as String : String.Empty;
                string empID = i == 0 ? row["EmpID"] as String : String.Empty;
                string numOfDays = i == 0 ?
                                   (row.IsNull("NumberOfDays") || row["NumberOfDays"] == null ? String.Empty : row.Field<int>("NumberOfDays").ToString())
                                   : String.Empty;
                string createDate;
                if (i == 0)
                {
                    createDate = row.IsNull("CreateDate") || row["CreateDate"] == null ? String.Empty : row.Field<DateTime>("CreateDate").ToShortDateString();
                }
                else { createDate = String.Empty; }

                firstChar = TreatNewPage(ref partialReport, CreatePartialHeader);
                partialReport.AppendLine(String.Format(FORMAT_STRING_PARTIAL, firstChar, uid, createDate, workstationID, empID, ssn, acc, numOfDays));
                firstChar = " ";
            }
        }

        public StringBuilderWithLineCount CreatePartialHeader(int currentLineCounter)
        {
            StringBuilderWithLineCount result = new StringBuilderWithLineCount();
            String headerDate = DateTime.Now.ToString("MM/dd/yyyy");
            int pageNumber = currentLineCounter / Properties.Settings.Default.NumberOfLinesPerPageInReport + 1;

            //  Line Length = 133 characters; Max Line Count/Page = [Properties.Settings.Default.NumberOfLinesPerPageInReport] Lines
            result.AppendLine(String.Format("{0,-3}{1, -45}{2,-75}{3,-6}{4,-4}", "1",
                                              headerDate, "POTENTIAL MARGO FORMS SCANNING ERRORS", "PAGE", pageNumber));
            result.AppendLine("");
            result.AppendLine(String.Format("{0,-3}{1,-13}{2,-15}{3,-16}{4,-13}{5,-23}{6,-37}{7,-12}",
                                             "", "Unique ID", "Document Date", "WorkStation ID", "Employee ID", "SSNs",
                                             "Account Numbers", "Days Partial"));
            result.AppendLine("");

            return result;
        }

    } // end class PartialReport


}
