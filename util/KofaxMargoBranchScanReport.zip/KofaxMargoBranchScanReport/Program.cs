﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace KofaxMargoBranchScanReport
{
    class Program
    {
        static void Main(string[] args)
        {
            WeeklyReport weeklyReport = new WeeklyReport();
            weeklyReport.Run();
        }

    }
}
