﻿using System;
using log4net;
using System.Diagnostics;

namespace HR_Sync
{

    public class Logger
    {
        private readonly ILog _mLog;

        public Logger(string callingType)
        {
            try
            {
                if (log4net.LogManager.GetRepository().Configured)
                {
                    _mLog = LogManager.GetLogger(callingType);
                }
                else
                {
                    log4net.Config.XmlConfigurator.Configure(new System.IO.FileInfo(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile));
                    _mLog = LogManager.GetLogger(callingType);
                }
            }
            catch (Exception ex)
            {
                WriteEventLog("Exception in Logger constructor: " + ex.ToString(), EventLogEntryType.Error);
            }
        }

        public void LogDebug(object message)
        {
            if (_mLog == null)
            {
                WriteEventLog("Log object is null.", EventLogEntryType.Information);
                return;
            }
            _mLog.Debug(message);
        }

        public void LogInfo(object message)
        {
            if (_mLog == null)
            {
                WriteEventLog("Log object is null.", EventLogEntryType.Information);
                return;
            }
            _mLog.Info(message);
        }

        public void LogWarn(object message)
        {
            if (_mLog == null)
            {
                WriteEventLog("Log object is null.", EventLogEntryType.Warning);
                return;
            }
            _mLog.Warn(message);
        }

        public void LogError(object message)
        {
            if (_mLog == null)
            {
                WriteEventLog("Log object is null.", EventLogEntryType.Error);
                return;
            }
            _mLog.Error(message);
        }

        public void LogFatal(object message)
        {
            if (_mLog == null)
            {
                WriteEventLog("Log object is null.", EventLogEntryType.Error);
                return;
            }
            _mLog.Fatal(message);
        }

        /// <summary>
        /// Writes message to EventLog without requiring elevated permissions.
        /// It assumes that EventLog exists, while the Source may not exist. 
        /// </summary>
        /// <remarks>If this method fails, it only writes message to console.</remarks>
        /// <param name="message"></param>
        /// <param name="entryType"></param>
        public static void WriteEventLog(string message, EventLogEntryType entryType)
        {
            try
            {
                using (EventLog log = new EventLog())
                {
                    log.Log = Properties.Settings.Default.EventLogName;
                    log.Source = Properties.Settings.Default.EventSourceName;
                    log.WriteEntry(message, entryType);
                }
            }
            catch (Exception ex)
            {
                string msg = "Failed to write to EventLog message: " + message + Environment.NewLine;
                msg += "Exception:  " + ex.ToString();
                Console.Error.WriteLine(msg);
            }
        } 

    }
}
