﻿using System;
using System.IO;
using System.Diagnostics;
using System.Reflection;

namespace HR_Sync
{
    class Program
    {
        #region // error codes for abnormal end of application
        public const int INPUT_FILE_DOES_NOT_EXIST = 81;
        public const int TIMEOUT_FINISHING_FILE_COPYING = 82;
        public const int SYNC_PROCESS_FAILED = 83;
        public const int INPUT_FILE_EMPTY = 84;
        #endregion

        public static Logger log;

        static void Main(string[] args)
        {
            try
            {
                log = new Logger(MethodBase.GetCurrentMethod().DeclaringType.FullName);

                string version = Assembly.GetExecutingAssembly().GetName().Version.ToString();
                log.LogInfo($"{Environment.NewLine}    **********************  HR Sync ver.{version}  **********************");

                // verify that input file exists
                string inputFile = Properties.Settings.Default.InputFile;
                HRSyncProcess hrSync = new HRSyncProcess(log);
                if (!File.Exists(inputFile))
                {
                    Logger.WriteEventLog($"Input file [{inputFile}] does not exist.", EventLogEntryType.Error);
                    log?.LogError($"Input file [{inputFile}] does not exist.");

                    HRSyncProcess.SendEmailToTechService(Properties.Resources.subjError,
                    "HR_Sync has failed: " + Environment.NewLine + $"Input file [{inputFile}] does not exist.");
                    Environment.Exit(INPUT_FILE_DOES_NOT_EXIST);
                }

                // specifically treat case when input file is blank
                string inputContent = File.ReadAllText(inputFile);
                if (string.IsNullOrWhiteSpace(inputContent))
                {
                    Logger.WriteEventLog($"Input file [{inputFile}] is empty.", EventLogEntryType.Error);
                    log?.LogWarn($"Input file [{inputFile}] is empty.");
                    HRSyncProcess.SendEmailToTechService(Properties.Resources.subjWarning, 
                        $"Input file [{inputFile}] is empty. It is indication of a potential problem in mainframe job creating the file." 
                        + Environment.NewLine + "Please notify BSD of this problem.");
                    Environment.Exit(INPUT_FILE_EMPTY);
                }

                hrSync.Run();
            }
            catch (Exception ex)
            {
                Logger.WriteEventLog($"Exception thrown in Main(): {ex.Message}", EventLogEntryType.Error);
                log?.LogError("Exception thrown in Main(): " + ex);
                HRSyncProcess.SendEmailToTechService(Properties.Resources.subjError,
                    "HR_Sync has failed: " + Environment.NewLine + $"Exception in Main(): " + ex + 
                    Environment.NewLine + "Please notify BSD of this error.");
            }
        }

    }
}

