﻿namespace HR_Sync
{
    partial class ConfigurationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfigurationForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTop = new System.Windows.Forms.Label();
            this.tbConnString = new System.Windows.Forms.TextBox();
            this.lblConnString = new System.Windows.Forms.Label();
            this.tbEmailFrom = new System.Windows.Forms.TextBox();
            this.lblEmailFrom = new System.Windows.Forms.Label();
            this.tbTechEmails = new System.Windows.Forms.TextBox();
            this.lblTechEmails = new System.Windows.Forms.Label();
            this.tbUserEmails = new System.Windows.Forms.TextBox();
            this.lblUserEmails = new System.Windows.Forms.Label();
            this.cbSendTechEmails = new System.Windows.Forms.CheckBox();
            this.cbSendUserEmails = new System.Windows.Forms.CheckBox();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.tbLogFile = new System.Windows.Forms.TextBox();
            this.lblLogFile = new System.Windows.Forms.Label();
            this.tbInputfile = new System.Windows.Forms.TextBox();
            this.lblInputFile = new System.Windows.Forms.Label();
            this.tbPDMSysAccName = new System.Windows.Forms.TextBox();
            this.lblPDMSYS = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lblTop);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(668, 65);
            this.panel1.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(576, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Padding = new System.Windows.Forms.Padding(0, 3, 0, 0);
            this.pictureBox1.Size = new System.Drawing.Size(92, 65);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lblTop
            // 
            this.lblTop.AutoSize = true;
            this.lblTop.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTop.Location = new System.Drawing.Point(179, 22);
            this.lblTop.Name = "lblTop";
            this.lblTop.Size = new System.Drawing.Size(342, 24);
            this.lblTop.TabIndex = 1;
            this.lblTop.Text = "HR Sync Configuration Settings";
            // 
            // tbConnString
            // 
            this.tbConnString.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbConnString.Location = new System.Drawing.Point(13, 105);
            this.tbConnString.Name = "tbConnString";
            this.tbConnString.Size = new System.Drawing.Size(600, 21);
            this.tbConnString.TabIndex = 4;
            // 
            // lblConnString
            // 
            this.lblConnString.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConnString.Location = new System.Drawing.Point(13, 85);
            this.lblConnString.Name = "lblConnString";
            this.lblConnString.Size = new System.Drawing.Size(251, 20);
            this.lblConnString.TabIndex = 81;
            this.lblConnString.Text = "Member ID Connection String:";
            // 
            // tbEmailFrom
            // 
            this.tbEmailFrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbEmailFrom.Location = new System.Drawing.Point(13, 385);
            this.tbEmailFrom.Name = "tbEmailFrom";
            this.tbEmailFrom.Size = new System.Drawing.Size(600, 21);
            this.tbEmailFrom.TabIndex = 9;
            // 
            // lblEmailFrom
            // 
            this.lblEmailFrom.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailFrom.Location = new System.Drawing.Point(13, 366);
            this.lblEmailFrom.Name = "lblEmailFrom";
            this.lblEmailFrom.Size = new System.Drawing.Size(274, 18);
            this.lblEmailFrom.TabIndex = 86;
            this.lblEmailFrom.Text = "Email From (Must Be Valid):";
            // 
            // tbTechEmails
            // 
            this.tbTechEmails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTechEmails.Location = new System.Drawing.Point(13, 444);
            this.tbTechEmails.Name = "tbTechEmails";
            this.tbTechEmails.Size = new System.Drawing.Size(600, 21);
            this.tbTechEmails.TabIndex = 10;
            // 
            // lblTechEmails
            // 
            this.lblTechEmails.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTechEmails.Location = new System.Drawing.Point(13, 424);
            this.lblTechEmails.Name = "lblTechEmails";
            this.lblTechEmails.Size = new System.Drawing.Size(537, 18);
            this.lblTechEmails.TabIndex = 88;
            this.lblTechEmails.Text = "Tech Service Emails to Receive Error Messages (Comma-delimited):";
            // 
            // tbUserEmails
            // 
            this.tbUserEmails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbUserEmails.Location = new System.Drawing.Point(13, 510);
            this.tbUserEmails.Name = "tbUserEmails";
            this.tbUserEmails.Size = new System.Drawing.Size(600, 21);
            this.tbUserEmails.TabIndex = 11;
            // 
            // lblUserEmails
            // 
            this.lblUserEmails.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUserEmails.Location = new System.Drawing.Point(13, 491);
            this.lblUserEmails.Name = "lblUserEmails";
            this.lblUserEmails.Size = new System.Drawing.Size(443, 18);
            this.lblUserEmails.TabIndex = 90;
            this.lblUserEmails.Text = "User Emails to Receive Notifications (Comma-delimited):";
            // 
            // cbSendTechEmails
            // 
            this.cbSendTechEmails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSendTechEmails.Location = new System.Drawing.Point(13, 542);
            this.cbSendTechEmails.Name = "cbSendTechEmails";
            this.cbSendTechEmails.Size = new System.Drawing.Size(247, 32);
            this.cbSendTechEmails.TabIndex = 91;
            this.cbSendTechEmails.Text = "Send Tech Services Emails";
            this.cbSendTechEmails.UseVisualStyleBackColor = true;
            // 
            // cbSendUserEmails
            // 
            this.cbSendUserEmails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbSendUserEmails.Location = new System.Drawing.Point(13, 582);
            this.cbSendUserEmails.Name = "cbSendUserEmails";
            this.cbSendUserEmails.Size = new System.Drawing.Size(247, 32);
            this.cbSendUserEmails.TabIndex = 92;
            this.cbSendUserEmails.Text = "Send Users Emails";
            this.cbSendUserEmails.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(370, 637);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(110, 26);
            this.btnOK.TabIndex = 12;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(507, 637);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(110, 26);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // tbLogFile
            // 
            this.tbLogFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbLogFile.Location = new System.Drawing.Point(13, 308);
            this.tbLogFile.Name = "tbLogFile";
            this.tbLogFile.Size = new System.Drawing.Size(600, 21);
            this.tbLogFile.TabIndex = 8;
            // 
            // lblLogFile
            // 
            this.lblLogFile.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogFile.Location = new System.Drawing.Point(13, 289);
            this.lblLogFile.Name = "lblLogFile";
            this.lblLogFile.Size = new System.Drawing.Size(211, 20);
            this.lblLogFile.TabIndex = 102;
            this.lblLogFile.Text = "Log File (Full Path):";
            // 
            // tbInputfile
            // 
            this.tbInputfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbInputfile.Location = new System.Drawing.Point(13, 249);
            this.tbInputfile.Name = "tbInputfile";
            this.tbInputfile.Size = new System.Drawing.Size(600, 21);
            this.tbInputfile.TabIndex = 7;
            // 
            // lblInputFile
            // 
            this.lblInputFile.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInputFile.Location = new System.Drawing.Point(13, 228);
            this.lblInputFile.Name = "lblInputFile";
            this.lblInputFile.Size = new System.Drawing.Size(408, 18);
            this.lblInputFile.TabIndex = 100;
            this.lblInputFile.Text = "HR Text File, Full Path (Change Drive Letter Only):";
            // 
            // tbPDMSysAccName
            // 
            this.tbPDMSysAccName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPDMSysAccName.Location = new System.Drawing.Point(12, 158);
            this.tbPDMSysAccName.Name = "tbPDMSysAccName";
            this.tbPDMSysAccName.Size = new System.Drawing.Size(308, 21);
            this.tbPDMSysAccName.TabIndex = 103;
            // 
            // lblPDMSYS
            // 
            this.lblPDMSYS.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPDMSYS.Location = new System.Drawing.Point(14, 139);
            this.lblPDMSYS.Name = "lblPDMSYS";
            this.lblPDMSYS.Size = new System.Drawing.Size(270, 18);
            this.lblPDMSYS.TabIndex = 104;
            this.lblPDMSYS.Text = "PDMSYS Account Name:";
            // 
            // ConfigurationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(668, 674);
            this.Controls.Add(this.tbPDMSysAccName);
            this.Controls.Add(this.lblPDMSYS);
            this.Controls.Add(this.tbLogFile);
            this.Controls.Add(this.lblLogFile);
            this.Controls.Add(this.tbInputfile);
            this.Controls.Add(this.lblInputFile);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.cbSendUserEmails);
            this.Controls.Add(this.cbSendTechEmails);
            this.Controls.Add(this.tbUserEmails);
            this.Controls.Add(this.lblUserEmails);
            this.Controls.Add(this.tbTechEmails);
            this.Controls.Add(this.lblTechEmails);
            this.Controls.Add(this.tbEmailFrom);
            this.Controls.Add(this.lblEmailFrom);
            this.Controls.Add(this.tbConnString);
            this.Controls.Add(this.lblConnString);
            this.Controls.Add(this.panel1);
            this.Name = "ConfigurationForm";
            this.Text = "Settings Configuration Form";
            this.Load += new System.EventHandler(this.ConfigurationForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTop;
        private System.Windows.Forms.TextBox tbConnString;
        private System.Windows.Forms.Label lblConnString;
        private System.Windows.Forms.TextBox tbEmailFrom;
        private System.Windows.Forms.Label lblEmailFrom;
        private System.Windows.Forms.TextBox tbTechEmails;
        private System.Windows.Forms.Label lblTechEmails;
        private System.Windows.Forms.TextBox tbUserEmails;
        private System.Windows.Forms.Label lblUserEmails;
        private System.Windows.Forms.CheckBox cbSendTechEmails;
        private System.Windows.Forms.CheckBox cbSendUserEmails;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox tbLogFile;
        private System.Windows.Forms.Label lblLogFile;
        private System.Windows.Forms.TextBox tbInputfile;
        private System.Windows.Forms.Label lblInputFile;
        private System.Windows.Forms.TextBox tbPDMSysAccName;
        private System.Windows.Forms.Label lblPDMSYS;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}