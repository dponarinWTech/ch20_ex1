﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Mail;
using Microsoft.Exchange.WebServices.Data;

namespace HR_Sync
{
    public class SECUEmail
    {
        /// <summary>
        /// Logger object
        /// </summary>
        private Logger log;

        /// <summary>
        /// SmtpClient object used to send smtp eamil report message
        /// </summary>
        private static SmtpClient smtp;

        /// <summary>
        /// ExchangeService object used to send MSExchange email report message
        /// </summary>
        private static ExchangeService service;

        /// <summary>
        /// Subject of the Email Message
        /// </summary>
        public string Subject { get; set; }

        /// <summary>
        /// Body of the Email Message
        /// </summary>
        public string Body { get; set; }

        /// <summary>
        /// Priority of the SMTP message
        /// </summary>
        private static MailPriority Priority { get; set; }

        /// <summary>
        /// Importance of the EWS email message
        /// </summary>
        private static Importance Importance { get; set; }


        /// <summary>
        /// Get or set the Autodiscover
        /// </summary>
        public bool Autodiscover { get; set; }


        /// <summary>
        /// Get or set the SMTP username
        /// </summary>
        public string SmtpUserName { get; set; }

        /// <summary>
        /// Get or set the SMTP password
        /// </summary>
        public string SmtpPassword { get; set; }

        /// <summary>
        /// Get or set the Exchange username
        /// </summary>
        public string EwsUserName { get; set; }

        /// <summary>
        /// Get or set the Exchange password
        /// </summary>
        public string EwsPassword { get; set; }

        /// <summary>
        /// Get or set the send SMTP email message
        /// </summary>
        public bool SendSmtpEmail { get; set; }

        /// <summary>
        /// Get or set the from address
        /// </summary>
        public string FromAddress { get; set; }

        /// <summary>
        /// Get or set the To address
        /// </summary>
        public List<string> ToAddress { get; set; }

        /// <summary>
        /// Get or set the CC address
        /// </summary>
        public List<string> CcAddress { get; set; }


        /// <summary>
        /// Get or set the SMTPHostAddress
        /// </summary>
        public string SMTPHost { get; set; }

        /// <summary>
        /// Get or set the SMTPPort
        /// </summary>
        public int SMTPPort { get; set; }

        /// <summary>
        /// URI of the Exchange Web Service
        /// </summary>
        public string EWSUri { get; set; }

        /// <summary>
        /// Public property to receive information about desired Exchange Server version
        /// </summary>
        public string exchangeVersion;

        /// <summary>
        /// Get or set the Exchange Server version
        /// </summary>
        private ExchangeVersion exchVersion;

        /// <summary>
        /// List of attachment file names. Empty list by default.
        /// </summary>
        public List<string> Attachments { get; set; }

        /// <summary>
        /// Boolean flag, if true - the email must have valid attachment. False by default.
        /// </summary>
        public bool MustHaveAttachment { get; set; }

        /// <summary>
        /// Boolean flag, if true - the email must have non-blank subject. False by default.
        /// </summary>
        public bool MustHaveSubject { get; set; }

        /// <summary>
        /// Non-empty string indicates error and contains error information.
        /// </summary>
        public string ErrorMessage { get; private set; }

        /// <summary>
        /// Turns on Trace. Optional feature, only helps in console application.
        /// False by default.
        /// </summary>
        public bool TurnTraceOn { get; set; }

        /// <summary>
        /// Maximum allowed attachment size (bytes)
        /// </summary>
        public long MaxAttachmentSize { get; set; }

        /// <summary>
        /// Default constructor
        /// </summary>
        public SECUEmail(Logger logger)
        {
            // private members default values
            log = logger;
            Body = "";
            Subject = "";
            service = new ExchangeService();
            smtp = new SmtpClient();
            Importance = Importance.Normal;
            Priority = MailPriority.Normal;
            SMTPPort = 25;

            // public attributes default values
            Subject = String.Empty;
            Body = String.Empty;
            MustHaveSubject = false;
            MustHaveAttachment = false;
            ErrorMessage = String.Empty;
            TurnTraceOn = false;
            SendSmtpEmail = false;
            Autodiscover = false;
            MaxAttachmentSize = 10485760; // max attachment size for MultiScan

            Attachments = new List<string>();
            CcAddress = new List<string>();
            ToAddress = new List<string>();
        }

        public void SetPriorityHigh()
        {
            log.LogDebug("SECUEmail.SetPriorityHigh(): Start");
            Priority = MailPriority.High;
            Importance = Importance.High;
            log.LogDebug("SECUEmail.SetPriorityHigh(): End");
        }

        public void SetPriorityLow()
        {
            log.LogDebug("SECUEmail.SetPriorityLow(): Start");
            Priority = MailPriority.Low;
            Importance = Importance.Low;
            log.LogDebug("SECUEmail.SetPriorityLow(): End");
        }

        public void SetPriorityNormal()
        {
            log.LogDebug("SECUEmail.SetPriorityNormal(): Start");
            Priority = MailPriority.Normal;
            Importance = Importance.Normal;
            log.LogDebug("SECUEmail.SetPriorityNormal(): End");
        }


        public void SendMail()
        {
            log.LogInfo("SECUEmail.SendEmail(): Start");

            if (VerifyFields())
            {
                // We always verify attachments. To skip this verification keep default settings: MustHaveAttachment is 'false'
                // and Attachments list is empty.
                string errorMsg = String.Empty;
                bool result = !MustHaveAttachment;
                foreach(string attch in Attachments)
                {
                    result = VerifyAttachment(attch, MustHaveAttachment);
                    if (!result) break;
                }
                if (result) // all attachments are valid
                {
                    try
                    {
                        EstablishConnection();
                        if (String.IsNullOrEmpty(ErrorMessage))
                        {
                            SendEmail();
                        }
                    }
                    catch (Exception e)
                    {
                        log.LogError($"SendEmail(): Unable to send email: {e.Message}");
                        ErrorMessage = "Exception caught while sending email: " + e.Message;
                    }
                }
                else
                {
                    log.LogWarn("SECUEmail.SendEmail(): Email message not sent");
                }

            }
            else
            {
                log.LogWarn("SECUEmail.SendEmail(): Email message not sent");
            }
            log.LogInfo("SECUEmail.SendEmail(): End");
        }

        private void SendEmail()
        {
            log.LogDebug("  SECUEmail.SendEmail(): Start");
            if (SendSmtpEmail)
            {
                SendSmtpMessage(BuildSmtpMessage());
            }
            else
            {
                SendEwsMessage(BuildEwsMessage());
            }

            log.LogDebug("  SECUEmail.SendEmail(): End");
        }

        /// <summary>
        /// Builds a smtp email message
        /// </summary>
        /// <returns>Smtp MailMessage</returns>
        private MailMessage BuildSmtpMessage()
        {
            log.LogDebug("    SECUEmail.BuildSmtpMessage(): Start");
            MailMessage report = new MailMessage();
            foreach (string address in ToAddress)
            {
                report.To.Add(address);
            }
            foreach (string address in CcAddress)
            {
                report.CC.Add(address);
            }
            report.From = new MailAddress(FromAddress);
            report.Subject = Subject;
            report.IsBodyHtml = false;
            report.Body = Body;
            report.Priority = Priority;

            // Create the file attachments
            foreach (string attch in Attachments)
            {
                using (System.Net.Mail.Attachment data = new System.Net.Mail.Attachment(attch, System.Net.Mime.MediaTypeNames.Application.Octet))
                {
                    report.Attachments.Add(data);
                }
            }

            log.LogDebug("    SECUEmail.BuildSmtpMessage(): End");
            return report;
        }

        /// <summary>
        /// Sends a smtp message
        /// </summary>
        /// <param name="report">Smtp MailMessage to be sent</param>
        private void SendSmtpMessage(MailMessage report)
        {
            log.LogDebug("    SECUEmail.SendSmtpMessage(): Start");
            try
            {
                log.LogInfo("      SECUEmail.SendSmtpMessage(): Sending Message");
                smtp.Send(report);
                log.LogInfo("      SECUEmail.SendSmtpMessage(): Message Sent");
            }
            catch (Exception e)
            {
                log.LogError($"    SECUEmail.SendSmtpMessage(): Unable to send email: {e.ToString()}");
                ErrorMessage = "Exception caught while sending SMTP email: " + e.Message;
            }
            finally
            {
                log.LogDebug("    SECUEmail.SendSmtpMessage(): End");
            }
        }

        /// <summary>
        /// Builds an EWS email message
        /// </summary>
        /// <returns>Returns EWS EmailMessage</returns>
        private EmailMessage BuildEwsMessage()
        {
            log.LogDebug("    SECUEmail.BuildEwsMessage(): Start");
            EmailMessage report = new EmailMessage(service)
            {
                Subject = Subject,
                Importance = Importance
            };

            report.Body = new MessageBody(BodyType.Text, Body); 

            report.From = FromAddress;
            foreach (string address in ToAddress)
            {
                report.ToRecipients.Add(address);
            }
            foreach (string address in CcAddress)
            {
                report.CcRecipients.Add(address);
            }

            foreach(string attch in Attachments)
            {
                report.Attachments.AddFileAttachment(attch);
            }

            log.LogDebug("    SECUEmail.BuildEwsMessage(): End");
            return report;
        }


        private void SendEwsMessage(EmailMessage report)
        {
            log.LogDebug("    SECUEmail.SendEwsMessage(): Start");
            string toAddresses = "";
            foreach (EmailAddress address in report.ToRecipients)
            {
                toAddresses += $"{address};";
            }
            log.LogInfo($"      SendEWSMessage(): Sending Message to: {toAddresses}");
            try
            {
                report.Send();
                log.LogInfo("      SendEWSMessage(): Message Sent");
            }
            catch (Exception e)
            {
                log.LogError($"    SECUEmail.SendEwsMessage(): Unable to send email: {e.ToString()}");
                ErrorMessage = "Exception caught while sending EWS email: " + e.Message;
            }
            finally
            {
                log.LogDebug("    SECUEmail.SendEwsMessage(): End");
            }
        }


        /// <summary>
        /// Helper method that verifies that subject and body are not empty
        /// </summary>
        /// <returns>Returns true if verified, false otherwise</returns>
        private bool VerifyFields()
        {
            log.LogDebug("  SECUEmail.VerifyFields(): Start");

            if (String.IsNullOrEmpty(Body))
            {
                log.LogError("    SECUEmail.VerifyFields(): Email body is empty");
                ErrorMessage = "Email body is empty";
                log.LogDebug("  SECUEmail.VerifyFields(): End");
                return false;
            }else if (MustHaveSubject && String.IsNullOrEmpty(Subject))
            {
                log.LogError("    SECUEmail.VerifyFields(): Subject is empty");
                ErrorMessage = "Email subject is empty";
                log.LogDebug("  SECUEmail.VerifyFields(): End");
                return false;
            }
            else if (ToAddress == null || ToAddress.Count == 0)
            {
                log.LogError("    SECUEmail.VerifyFields(): No recipient email address was provided");
                ErrorMessage = "No recipient email address was provided";
                log.LogDebug("  SECUEmail.VerifyFields(): End");
                return false;
            }

            log.LogDebug("  SECUEmail.VerifyFieldsAndAttachment(): End");
            return true;
        }

        /// <summary>
        /// Verifies if attachment file exists and its size does not exceed the limit.
        /// </summary>
        /// <param name="attachmentFileName">Attachment file name (fully qualified)</param>
        /// <param name="mustHaveAttachment">Boolean flag, if true - email must have valid attachment</param>
        /// <param name="errormessage">Error message.</param>
        /// <returns></returns>
        private bool VerifyAttachment(string attachmentFileName, bool mustHaveAttachment)
        {
            log.LogDebug("  SECUEmail.VerifyAttachment(): Start");

            if ( !mustHaveAttachment && String.IsNullOrEmpty(attachmentFileName) ) { return true; }

            // Email must have valid attachment or attachment is not required, but non-blank attachment filename was provided.

            if ( String.IsNullOrEmpty(attachmentFileName) || !File.Exists(attachmentFileName) )
            {
                log.LogError($"    SECUEmail.VerifyAttachment(): Attachment file name is blank or the file '{attachmentFileName}' does not exist.");
                log.LogDebug("  SECUEmail.VerifyAttachment(): End");
                ErrorMessage = "Attachment file name is blank or the attachment file does not exist.";
                return false;
            }
            else
            {
                FileInfo fileInfo = new FileInfo(attachmentFileName);
                if (fileInfo.Length > MaxAttachmentSize)
                {
                    float sizeMB = fileInfo.Length / 1024f / 1024f;
                    float maxSize = MaxAttachmentSize / 1024f / 1024f;
                    string msg = "The current batch PDF size is " + sizeMB.ToString("0.##") + "megabytes. This is greater than the max allowed email size of " +
                        maxSize.ToString("0.##") + " megabytes. The email will not be sent.";
                    log.LogError(msg);
                    ErrorMessage = msg;
                    return false;
                }
            }

            log.LogDebug("  SECUEmail.VerifyAttachment(): End");
            return true;
        }

        /// <summary>
        /// Helper method that establish SMTP client connection and EWS connection
        /// </summary>
        private void EstablishConnection()
        {
            log.LogDebug("  SECUEmail.EstablishConnection(): Start");
            try
            {
                if (SendSmtpEmail)
                {
                    smtp = GetSmtpEmailConnection();
                }
                else
                {
                    service = GetEwsEmailConnection();
                }
            }
            catch (Exception ex)
            {
                log.LogError("    SECUEmail.EstablishConnection(): Unable to establish connection: " + ex);
                ErrorMessage = "Unable to establish connection: " + ex.Message;
            }
            finally
            {
                log.LogDebug("  SECUEmail.EstablishConnection(): End");
            }
        }

        /// <summary>
        /// An EstablishConnection helper method that returns a smtp client connection.
        /// If SmtpUserName and SmtpPassword are not empty authentication will be done using these credentials, 
        /// if they are blank - credentials of currently logged user will be used.
        /// </summary>
        /// <returns>Returns a smtp client connection</returns>
        private SmtpClient GetSmtpEmailConnection()
        {
            log.LogDebug("    SECUEmail.EstablishConnection(): Start");
            SmtpClient mySmtpClient = new SmtpClient { UseDefaultCredentials = false };
            if (!String.IsNullOrEmpty(SMTPHost))
            {
                mySmtpClient.Host = SMTPHost;
            }

            if (String.IsNullOrWhiteSpace(SmtpUserName) || String.IsNullOrWhiteSpace(SmtpPassword))
            {
                try
                {
                    mySmtpClient.Credentials = CredentialCache.DefaultNetworkCredentials;
                }
                catch (Exception e)
                {
                    log.LogError("      SECUEmail.GetSmtpEmailConnection(): Exception caught when setting DefaultNetworkCredentials for SMTP clien.  " + e.ToString());
                    ErrorMessage = "Exception caught when setting DefaultNetworkCredentials for SMTP clien.";
                }
            }
            else
            {
                try
                {
                    mySmtpClient.Credentials = new NetworkCredential(SmtpUserName, SmtpPassword);
                    mySmtpClient.UseDefaultCredentials = false;
                }
                catch (Exception e)
                {
                    log.LogError("      SECUEmail.GetSmtpEmailConnection(): Exception caught when setting up SMTP authentication using provided username and password.  " + e.ToString());
                    ErrorMessage = "Exception caught when setting up SMTP authentication using provided username and password.";
                }
            }

            mySmtpClient.Port = SMTPPort;

            log.LogDebug("    SECUEmail.EstablishConnection(): End");
            return mySmtpClient;
        }

        /// <summary>
        /// An EstablishConnection helper method that returns an EWS connection service
        /// </summary>
        /// <returns>Returns an EWS connection service</returns>
        private ExchangeService GetEwsEmailConnection()
        {
            log.LogDebug("    SECUEmail.GetEwsEmailConnection(): Start");

            // set Exchange server version
            switch (exchangeVersion)
            {
                case "Exchange2007_SP1":
                    {
                        exchVersion = ExchangeVersion.Exchange2007_SP1;
                        break;
                    }
                case "Exchange2010":
                    {
                        exchVersion = ExchangeVersion.Exchange2010;
                        break;
                    }
                case "Exchange2010_SP1":
                    {
                        exchVersion = ExchangeVersion.Exchange2010_SP1;
                        break;
                    }
                case "Exchange2010_SP2":
                    {
                        exchVersion = ExchangeVersion.Exchange2010_SP2;
                        break;
                    }
                case "Exchange2013":
                    {
                        exchVersion = ExchangeVersion.Exchange2013;
                        break;
                    }
                default:
                    {
                        exchVersion = ExchangeVersion.Exchange2013;
                        break;
                    }
            }

            ExchangeService myExchangeService = new ExchangeService(exchVersion);

            // PreAuthenticate turns on caching mechanism that caches the connection credentials for a given domain in the active process 
            // and resends it on subsequent requests.
            myExchangeService.PreAuthenticate = true;

            myExchangeService.TraceEnabled = TurnTraceOn;
            myExchangeService.TraceFlags = TraceFlags.All;

            if (String.IsNullOrWhiteSpace(EwsUserName) || String.IsNullOrWhiteSpace(EwsPassword))
            {
                try
                {
                    myExchangeService.Credentials = CredentialCache.DefaultNetworkCredentials;
                }
                catch (Exception e)
                {
                    log.LogError("      SECUEmail.GetEwsEmailConnection(): Exception caught when setting DefaultNetworkCredentials for Exchange clien.  " + e.ToString());
                    ErrorMessage = "Exception caught when setting DefaultNetworkCredentials for Exchange clien.";
                    return null;
                }
            }
            else
            {
                try
                {
                    myExchangeService.Credentials = new WebCredentials(EwsUserName, EwsPassword);
                    myExchangeService.UseDefaultCredentials = false;
                }
                catch (Exception e)
                {
                    log.LogError("      SECUEmail.GetEwsEmailConnection(): Exception caught when setting up Exchange authentication using provided username and password.  " + e.ToString());
                    ErrorMessage = "Exception caught when setting up Exchange authentication using provided username and password.";
                    return null;
                }
            }

            try
            {
                // get Exchange web service URL
                if (Autodiscover || String.IsNullOrEmpty(EWSUri))
                {
                    myExchangeService.AutodiscoverUrl(FromAddress, RedirectionUrlValidationCallback);
                }
                else
                {
                    myExchangeService.Url = new Uri(EWSUri);

                    // if URL from app settings is invalid - run Autodiscover
                    if(myExchangeService.Url.Scheme != "https")
                    {
                        myExchangeService.AutodiscoverUrl(FromAddress, RedirectionUrlValidationCallback);
                    }
                }
                log.LogDebug($"EWS Endpoint: {myExchangeService.Url}");
            }
            catch (AutodiscoverLocalException e1)
            {
                log.LogError("      SECUEmail.GetEwsEmailConnection(): A local failure in autodiscover EWS URL.  " + e1.ToString());
                ErrorMessage = "Failed to autodiscover EWS URL. Check log file for more details. Please contact Support Services.";
            }
            catch (Microsoft.Exchange.WebServices.Autodiscover.AutodiscoverRemoteException e2)
            {
                log.LogError("      SECUEmail.GetEwsEmailConnection(): The Autodiscover server returned an error.  " + e2.ToString());
                ErrorMessage = "Failed to autodiscover EWS URL: the Autodiscover server returned an error. Check log file for more details. Please contact Support Services.";
            }
            catch (Exception e)
            {
                log.LogError("      SECUEmail.GetEwsEmailConnection(): Exception caught when setting EWS URL.  " + e.ToString());
                ErrorMessage = "Exception caught when setting EWS URL.";
            }

            log.LogDebug("    SECUEmail.GetEwsEmailConnection(): End");
            return myExchangeService;
        }

        private static bool RedirectionUrlValidationCallback(string redirectionUrl)
        {
            Uri redirectionUri = new Uri(redirectionUrl);

            // Validate the contents of the redirection URL. In this simple validation
            // callback, the redirection URL is considered valid if it is using HTTPS
            // to encrypt the authentication credentials. 

            return redirectionUri.Scheme == "https";
        }
    }
}
