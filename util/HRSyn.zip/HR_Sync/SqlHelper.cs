﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HR_Sync
{
    class SqlHelper
    {
        private Logger log;
        private string spacer;

        public SqlHelper(Logger logger)
        {
            log = logger;
            this.spacer = "    ";
        }

        public void SqlInfoMessage(object sender, SqlInfoMessageEventArgs ea)
        {
            WriteSqlMsgs(ea.Errors);
        }

        public void WriteSqlMsgs(SqlErrorCollection msgs)
        {
            string message = "";
            foreach (SqlError e in msgs)
            {

                message += spacer + $"Message: '{e.Message}', Error Number: {e.Number}, Severity: {e.Class}, State: {e.State}, Procedure: {e.Procedure}, Line no: {e.LineNumber}" + Environment.NewLine;
                message += spacer + e.Message + Environment.NewLine;
            }

            log?.LogError(spacer + "SQL Error: " + Environment.NewLine + message);
        }

        /// <summary>
        /// Returns opened SqlConnection which writes user SQL errors into caller application log
        /// </summary>
        /// <param name="connectionString"></param>
        /// <returns></returns>
        public SqlConnection SetupConnection(string connectionString)
        {
            SqlConnection cn;
            log?.LogDebug(spacer + $"Start connecting to {GetDbInfo(connectionString)}");

            cn = new SqlConnection(connectionString);

            // Handle user errors with callbacks, rather than exception.
            cn.InfoMessage += SqlInfoMessage;
            cn.FireInfoMessageEventOnUserErrors = true;

            cn.Open();
            log?.LogDebug(spacer + $"Connection to {GetDbInfo(connectionString)} successfully open");

            return cn;
        }

        public string GetDbInfo(string connectionString)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(connectionString);
            string server = builder.DataSource;
            string db = builder.InitialCatalog;

            return $"database [{db}] on server [{server}]";
        }

        /// <summary>
        /// Returns current user from DB query using specified Sql connection
        /// </summary>
        /// <param name="conn">Sql connection</param>
        /// <returns></returns>
        public string GetDBUser(SqlConnection conn)
        {
            try
            {
                string result = String.Empty;
                using (SqlCommand selectCommand = conn.CreateCommand())
                {
                    selectCommand.CommandText = "SELECT SYSTEM_USER";

                    SqlDataReader myReader;
                    myReader = selectCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        result += myReader[0].ToString() + "  ";
                    }
                    myReader.Close();
                }

                return result;
            }
            catch (SqlException s)
            {
                log?.LogError("GetDBUser - SQL Exception: " + s.ToString());
                return null;
            }
            catch (TimeoutException t)
            {
                log?.LogError("GetDBUser - Timeout Exception: " + t.ToString());
                return null;
            }
            catch (Exception e)
            {
                log?.LogError("GetDBUser - Exception: " + e.ToString());
                return null;
            }
        }

    }
}
