﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration.Install;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using System.Configuration;

namespace HR_Sync
{
    [RunInstaller(true)]
    public partial class HRSync_Installer : System.Configuration.Install.Installer
    {
        public HRSync_Installer()
        {
            InitializeComponent();
        }

        protected override void OnBeforeInstall(IDictionary savedState)
        {
            base.OnBeforeInstall(savedState);
            SetupEventLogEventSource();
        }

        public override void Install(IDictionary savedState)
        {
            base.Install(savedState);

            // make sure config file is in place
            string configPath = Context.Parameters["assemblypath"] + ".config"; // fully qualifies name of config file    
            if (!File.Exists(configPath))
            {
                Logger.WriteEventLog($"Config file [{configPath}] does not exist. Installation failed.", EventLogEntryType.Error);
                MessageBox.Show($"Config file [{configPath}] does not exists. Installation failed.", 
                    "Installation failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw new InstallException($"Config file [{configPath}] does not exist.");
            }

            // call ConfigurationForm to update values in config file
            ConfigurationForm confForm = new ConfigurationForm(configPath) { TopLevel = true };

            DialogResult dialog = confForm.ShowDialog();
            if (dialog != DialogResult.OK)
            {
                MessageBox.Show("User has cancelled installation.", "HR_Sync Installer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                throw new InstallException("User has cancelled installation.");
            }
        }

        public static void SetupEventLogEventSource()
        {
            EventLog log = null;
            try
            {
                // make sure EventLog exists and Source is registered with it
                if (!EventLog.Exists(Properties.Settings.Default.EventLogName))
                {
                    if (EventLog.SourceExists(Properties.Settings.Default.EventSourceName))
                    {
                        EventLog.DeleteEventSource(Properties.Settings.Default.EventSourceName);
                    }

                    log = new EventLog();
                    log.Log = Properties.Settings.Default.EventLogName;


                    EventLog.CreateEventSource(Properties.Settings.Default.EventSourceName, Properties.Settings.Default.EventLogName);
                    log.Source = Properties.Settings.Default.EventSourceName;

                    // configure EventLog Overflow properties
                    log.MaximumKilobytes = 4096; // Max log size in KB
                    //log.ModifyOverflowPolicy(OverflowAction.OverwriteAsNeeded, 0);
                    log.ModifyOverflowPolicy(OverflowAction.OverwriteOlder, 10); // records in the log will be retained for 10 days
                }
                else  // configure existing EventLog
                {
                    log = GetEventLogByName(Properties.Settings.Default.EventLogName);
                    if (log == null)
                    {
                        Logger.WriteEventLog("Failed to retrieve EventLog by name. Installation events will not be logged to EventLog.", EventLogEntryType.Error);
                        return;
                    }
                    log.Log = Properties.Settings.Default.EventLogName;

                    // if desired source is not already registered with our Log, delete and recreate the source
                    if (EventLog.SourceExists(Properties.Settings.Default.EventSourceName))
                    {
                        string logFromSource = EventLog.LogNameFromSourceName(Properties.Settings.Default.EventSourceName, ".");
                        if (Properties.Settings.Default.EventLogName != logFromSource)
                        {
                            EventLog.DeleteEventSource(Properties.Settings.Default.EventSourceName);
                            EventLog.CreateEventSource(Properties.Settings.Default.EventSourceName, Properties.Settings.Default.EventLogName);
                        }
                    }

                    log.Source = Properties.Settings.Default.EventSourceName;

                    // configure EventLog Overflow properties
                    log.MaximumKilobytes = 4096; // Max log size in KB
                    //log.ModifyOverflowPolicy(OverflowAction.OverwriteAsNeeded, 0);
                    log.ModifyOverflowPolicy(OverflowAction.OverwriteOlder, 10);  // records in the log will be retained for 10 days
                }
            }
            catch (Exception ex)
            {
                string msg = $"Failed to create EventLog '{Properties.Settings.Default.EventLogName}' and register source ";
                msg += $"'{Properties.Settings.Default.EventSourceName}' with it. ";
                msg += $"Installation events will not be logged to Event Log." + Environment.NewLine + Environment.NewLine;
                msg += "Exception: " + ex.Message;
                MessageBox.Show(msg, "Event Log Not Created", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public static EventLog GetEventLogByName(string name)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(name))
                {
                    return null;
                }

                EventLog[] eventLogs = EventLog.GetEventLogs();
                foreach (EventLog eLog in eventLogs)
                {
                    if (eLog.Log.ToLower() == name.ToLower())
                    {
                        return eLog;
                    }
                }

                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

    }
}
