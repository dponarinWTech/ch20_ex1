﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Windows.Forms;
using System.Xml.Linq;

namespace HR_Sync
{
    public partial class ConfigurationForm : Form
    {
        private readonly string configFile;
        private string appName; // Name of the application; we need it because it appears in the setting names

        public ConfigurationForm(string configFile)
        {
            InitializeComponent();
            this.configFile = configFile;

            appName = Path.GetFileName(configFile);
            var tokens = appName.Split('.');
            appName = tokens.Length > 0 ? tokens[0] : "HR_Sync";
        }

        private void ConfigurationForm_Load(object sender, EventArgs e)
        {
            if (!File.Exists(configFile))
            {
                string msg = $"Config file '{configFile}' not found. Installation aborted." + Environment.NewLine +
                             Environment.NewLine + "Please notify BSD of this problem.";
                MessageBox.Show(msg, "Configure Settings", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult = DialogResult.Abort;
                Close();
            }

            PopulateForm(configFile);

            // We don't want text in tbConnString to be highlighted when the form opens
            tbConnString.SelectionStart = tbConnString.Text.Length;
            tbConnString.DeselectAll();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("The installation is not yet complete. Are you sure you want to exit?", "Configure Settings", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DialogResult = DialogResult.Cancel;
                Close();
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;
                if (AreThereBlankFields()) { return; }

                string inputFolder = Path.GetDirectoryName(tbInputfile.Text);
                string backupFolder = Path.Combine(inputFolder, "Archive");

                if (!UpdateConfig(configFile, backupFolder))
                {
                    return;
                }

                if (CreateFolder(inputFolder))
                {
                    AddDirectorySecurity(inputFolder, tbEmailFrom.Text.Trim(), FileSystemRights.FullControl,
                        AccessControlType.Allow);
                    AddDirectorySecurity(inputFolder, tbPDMSysAccName.Text.Trim(), FileSystemRights.FullControl,
                        AccessControlType.Allow);
                }
                else
                {
                    string msg = $"Failed to create folder [{inputFolder}] where HR Text file will be dropped. ";
                    msg += Environment.NewLine + "Please create this folder manually and re-run installation process.";
                    MessageBox.Show(new Form { TopMost = true }, msg);
                    ShutDown();
                }

                if (CreateFolder(backupFolder))
                {
                    AddDirectorySecurity(backupFolder, tbEmailFrom.Text.Trim(), FileSystemRights.FullControl,
                        AccessControlType.Allow);
                }
                else
                {
                    string msg = $"Failed to create folder [{backupFolder}] where backup copies of input files will be stored. ";
                    msg += Environment.NewLine + "Please create this folder manually and grant FullControl permission on it ";
                    msg += "to service account." + Environment.NewLine;
                    msg += "The application wouldn't run properly if that folder does not exist or does not have correct permissions.";
                    MessageBox.Show(new Form { TopMost = true }, msg);
                }

                if (CreateFolder(Path.GetDirectoryName(tbLogFile.Text)))
                {
                    AddDirectorySecurity(Path.GetDirectoryName(tbLogFile.Text), tbEmailFrom.Text.Trim(), FileSystemRights.FullControl,
                        AccessControlType.Allow);
                }
                else
                {
                    string msg = $"Failed to create Log folder [{tbLogFile.Text}]. ";
                    msg += Environment.NewLine + "Please create this folder manually and grant FullControl permission on it ";
                    msg += "to service account.";
                    MessageBox.Show(new Form { TopMost = true }, msg);
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception thrown: " + ex.Message);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        public void PopulateForm(string configFileName)
        {
            try
            {
                tbConnString.Text = GetConnStringValue(configFileName,
                    $"{appName}.Properties.Settings.MemberIDConnString");
                tbLogFile.Text = GetLogFile(configFileName);

                tbPDMSysAccName.Text = Environment.UserDomainName + @"\PDMSYS";

                List<XElement> settings = GetAllSettings(configFile);
                tbInputfile.Text = FetchSettingStringValue(settings, "InputFile").Trim();
                tbEmailFrom.Text = FetchSettingStringValue(settings, "EmailFrom").Trim();
                tbUserEmails.Text = FetchSettingStringValue(settings, "UserEmailRecipients").Trim();
                tbTechEmails.Text = FetchSettingStringValue(settings, "TechEmailRecipients").Trim();

                cbSendTechEmails.Checked =
                    FetchSettingStringValue(settings, "SendTechServicesEmails").Trim().ToLower() == "true";
                cbSendUserEmails.Checked =
                    FetchSettingStringValue(settings, "SendUsersEmails").Trim().ToLower() == "true";
            }
            catch (Exception ex)
            {
                string msg = "Installation aborted. Exception caught when populating Settings Configuration Form:  ";
                msg += ex.ToString() + Environment.NewLine + Environment.NewLine + "Please notify BSD of this problem.";
                MessageBox.Show(msg, "Configure Settings", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ShutDown();
            }
        }

        public string GetConnStringValue(string configFileName, string connStringName)
        {
            try
            {
                XDocument doc = XDocument.Load(configFileName);
                var conString = doc.Element("configuration")?.Element("connectionStrings")?.Elements("add");
                var attr = conString?.FirstOrDefault(x => x.Attribute("name")?.Value?.ToLower() == connStringName?.ToLower())
                    ?.Attribute("connectionString");
                return attr?.Value?.Trim();
            }
            catch { return string.Empty; }
        }

        public string GetLogFile(string configFileName)
        {
            try
            {
                XDocument doc = XDocument.Load(configFileName);
                XElement fileAppender = doc.Element("configuration")?.Element("log4net")?.Elements("appender")
                    ?.Where(x => x.Attribute("name")?.Value == "RollingFileAppender").First();


                var attrib = fileAppender?.Elements("param")?.FirstOrDefault(x => x.Attribute("name")?.Value == "File")
                    ?.Attribute("value");
                return attrib?.Value;
            }
            catch { return string.Empty; }
        }

        public string FetchSettingStringValue(List<XElement> settings, string settingName)
        {
            if (settings == null || settings.Count == 0 || string.IsNullOrWhiteSpace(settingName)) return string.Empty;
            settingName = settingName.Trim();

            try
            {
                return settings.FirstOrDefault(x => x.Attribute("name")?.Value?.ToLower() == settingName?.ToLower())?.Element("value")?.Value;
            }
            catch { return string.Empty; }
        }

        public List<XElement> GetAllSettings(XDocument doc)
        {
            try
            {
                return doc.Element("configuration")?.Element("applicationSettings")
                    ?.Element($"{appName}.Properties.Settings")?.Elements("setting").ToList();
            }
            catch { return new List<XElement>(); }
        }

        public List<XElement> GetAllSettings(string configFileName)
        {
            try
            {
                XDocument doc = XDocument.Load(configFileName);
                return doc.Element("configuration")?.Element("applicationSettings")
                    ?.Element($"{appName}.Properties.Settings")?.Elements("setting").ToList();
            }
            catch { return new List<XElement>(); }
        }

        public XAttribute GetConnStringAttribute(XDocument doc, string connStringName)
        {
            try
            {
                var conStrings = doc.Element("configuration")?.Element("connectionStrings")?.Elements("add");
                return conStrings?.FirstOrDefault(x => x.Attribute("name")?.Value?.ToLower() == connStringName?.ToLower())
                    ?.Attribute("connectionString");
            }
            catch { return null; }
        }

        public XAttribute GetLogFileAttribute(XDocument doc)
        {
            try
            {
                XElement fileAppender = doc.Element("configuration")?.Element("log4net")?.Elements("appender")
                    ?.Where(x => x.Attribute("name")?.Value == "RollingFileAppender").First();
                return fileAppender?.Elements("param")?.FirstOrDefault(x => x.Attribute("name")?.Value == "File")
                    ?.Attribute("value");
            }
            catch { return null; }
        }

        public XElement GetSettingElement(List<XElement> settings, string settingName)
        {
            if (settings == null || settings.Count == 0 || string.IsNullOrWhiteSpace(settingName)) return null;
            settingName = settingName.Trim();

            try
            {
                return settings.FirstOrDefault(x => x.Attribute("name")?.Value?.ToLower() == settingName?.ToLower())?.Element("value");
            }
            catch { return null; }
        }

        private void ShutDown()
        {
            Cursor.Current = Cursors.Default;
            DialogResult = DialogResult.Abort;
            Close();
        }

        public bool AreThereBlankFields()
        {
            var emptyTextBox = Controls.OfType<TextBox>().FirstOrDefault(t => string.IsNullOrWhiteSpace(t.Text));
            if (emptyTextBox != null)
            {
                MessageBox.Show(new Form { TopMost = true }, "All input fields are required.");
                emptyTextBox.Focus();
                return true;
            }
            else { return false; }
        }

        public static void AddDirectorySecurity(string fullDirectoryName, string account, FileSystemRights rights, AccessControlType controlType)
        {
            try
            {
                // Create a new DirectoryInfo object.
                DirectoryInfo dInfo = new DirectoryInfo(fullDirectoryName);

                // Get a DirectorySecurity object that represents the current security settings.
                DirectorySecurity dSecurity = dInfo.GetAccessControl();

                // Add the FileSystemAccessRule to the security settings. 
                dSecurity.AddAccessRule(new FileSystemAccessRule(account, rights, controlType));

                // Set the new access settings.
                dInfo.SetAccessControl(dSecurity);
            }
            catch (Exception ex)
            {
                string msg = $"Failed to grant access rights to folder [{fullDirectoryName}] to account '{account}'. ";
                msg += "Please complete this step manually. " + Environment.NewLine + Environment.NewLine;
                msg += "Error: " + ex.Message;
                MessageBox.Show(msg);
            }
        }

        public bool CreateFolder(string folderPath)
        {
            try
            {
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to create folder [{folderPath}]. Error : {ex.Message}");
                return false;
            }
        }

        public bool UpdateConfig(String configFileName, string backupFolder)
        {
            try
            {
                XDocument doc = XDocument.Load(configFileName);

                XAttribute connString = GetConnStringAttribute(doc, $"{appName}.Properties.Settings.MemberIDConnString");
                if (connString != null) connString.Value = tbConnString.Text.Trim();
                else { ShowError("connection string", $"{appName}.Properties.Settings.MemberIDConnString"); }

                XAttribute logFile = GetLogFileAttribute(doc);
                if (logFile != null) logFile.Value = tbLogFile.Text.Trim();
                else { ShowError("log file name in element 'LogFileAppender', sub-element", "File"); }

                List<XElement> settings = GetAllSettings(doc);

                XElement bkFolder = GetSettingElement(settings, "BackupFolder");
                if (bkFolder != null) bkFolder.Value = backupFolder;
                else { ShowError("setting", $"BackupFolder"); }

                XElement pdmSysAcc = GetSettingElement(settings, "PDMSysAccount");
                if (pdmSysAcc != null) pdmSysAcc.Value = tbPDMSysAccName.Text.Trim();
                else { ShowError("setting", $"PDMSysAccount"); }

                XElement inputFile = GetSettingElement(settings, "InputFile");
                if (inputFile != null) inputFile.Value = tbInputfile.Text.Trim();
                else { ShowError("setting", $"InputFile"); }

                XElement emailFrom = GetSettingElement(settings, "EmailFrom");
                if (emailFrom != null) emailFrom.Value = tbEmailFrom.Text.Trim();
                else { ShowError("setting", $"EmailFrom"); }

                XElement techEmail = GetSettingElement(settings, "TechEmailRecipients");
                if (techEmail != null) techEmail.Value = tbTechEmails.Text.Trim();
                else { ShowError("setting", $"TechEmailRecipients"); }

                XElement usersEmail = GetSettingElement(settings, "UserEmailRecipients");
                if (usersEmail != null) usersEmail.Value = tbUserEmails.Text.Trim();
                else { ShowError("setting", $"UserEmailRecipients"); }

                XElement sendTechEmails = GetSettingElement(settings, "SendTechServicesEmails");
                if (sendTechEmails != null) sendTechEmails.Value = cbSendTechEmails.Checked ? "True" : "False";
                else { ShowError("setting", $"SendTechServicesEmails"); }

                XElement sendUserEmails = GetSettingElement(settings, "SendUsersEmails");
                if (sendUserEmails != null) sendUserEmails.Value = cbSendUserEmails.Checked ? "True" : "False";
                else { ShowError("setting", $"SendUsersEmails"); }

                doc.Save(configFileName);
                return true;
            }
            catch (Exception ex)
            {
                String msg = "Installation aborted. Exception caught when saving configuration settings:  " + ex.ToString() +
                             Environment.NewLine + Environment.NewLine + "Please notify BSD of this problem.";
                MessageBox.Show(msg, "Configuration Settings", MessageBoxButtons.OK, MessageBoxIcon.Error);
                //ShutDown();
                return false;
            }
        }

        public void ShowError(string settingKind, string settingName)
        {
            string msg = $"Installer failed to update {settingKind} '{settingName}' in the config file. "
                         + Environment.NewLine + "Please update this setting manually.";
            MessageBox.Show(msg, "Installer Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        public void ParseAccountName(string fullAccountName, out string account, out string domain)
        {
            if (string.IsNullOrWhiteSpace(fullAccountName))
            {
                account = string.Empty;
                domain = string.Empty;
                return;
            }

            fullAccountName = fullAccountName.Trim();

            var slashIndex = fullAccountName.IndexOf("\\");
            var atIndex = fullAccountName.IndexOf("@");
            if (slashIndex > -1)
            {
                domain = fullAccountName.Substring(0, slashIndex);
                account = fullAccountName.Substring(slashIndex + 1);
            }
            else if (atIndex > -1)
            {
                account = fullAccountName.Substring(0, atIndex);
                if (fullAccountName.Substring(atIndex + 1)?.ToLower()?.Trim() == "ncsecu.dev") { domain = "DEVNCSECU"; }
                else if (fullAccountName.Substring(atIndex + 1)?.ToLower()?.Trim() == "ncsecu.org") { domain = "NCSECU"; }
                else { domain = string.Empty; }
            }
            else
            {
                account = string.Empty;
                domain = string.Empty;
            }
        }

    }
}
