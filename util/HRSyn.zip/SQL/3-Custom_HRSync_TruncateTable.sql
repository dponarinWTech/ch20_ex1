USE [MEMBERID]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[Custom_HRSync_TruncateTable]
(
	@ReturnResult	BIT OUT	
) 
AS
BEGIN
    DECLARE @SysError     INT;
	
	BEGIN TRANSACTION TruncateTable
	    TRUNCATE TABLE Update_EmpNo
		
		SELECT 	@SysError = @@ERROR
		IF @SysError <> 0
			BEGIN
				ROLLBACK TRANSACTION TruncateTables
				
				SET @ReturnResult = 0		-- "BAD" result		
				RETURN						
			END
		ELSE
		    BEGIN
			    COMMIT TRANSACTION TruncateTable
				SET @ReturnResult = 1		-- "GOOD" result
			END
	;		--	END TRANSACTION TruncateTable
	
END;  -- End stored procedure