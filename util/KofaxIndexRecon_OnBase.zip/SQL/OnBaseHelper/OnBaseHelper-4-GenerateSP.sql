USE [OnBaseHelper]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

DECLARE @KeytypeNumUniqID     bigint;
DECLARE @UniqIDTableName      nvarchar(40);
DECLARE @KeytypeNumSSN        bigint;
DECLARE @SSNTableName         nvarchar(40);
DECLARE @KeytypeNumAcc        bigint;
DECLARE @AccTableName         nvarchar(40);
DECLARE @KeytypeNumDataStored bigint;
DECLARE @DateTableName        nvarchar(40);

SELECT @KeytypeNumUniqID = (SELECT TOP 1 keytypenum 
                            FROM OnBase.hsi.keytypetable 
                            WHERE keytype like 'SOURCE UNI%');
SET @UniqIDTableName = N'[OnBase].[hsi].[keyitem' + CONVERT(nvarchar, @KeytypeNumUniqID) + N']';

SELECT @KeytypeNumSSN = (SELECT TOP 1 keytypenum 
                         FROM OnBase.hsi.keytypetable 
                         WHERE keytype like 'SSN%');
SET @SSNTableName = N'[OnBase].[hsi].[keyitem' + CONVERT(nvarchar, @KeytypeNumSSN) + N']';

SELECT @KeytypeNumAcc = (SELECT TOP 1 keytypenum 
                         FROM OnBase.hsi.keytypetable 
                         WHERE keytype like 'Account Nu%');
SET @AccTableName = N'[OnBase].[hsi].[keyitem' + CONVERT(nvarchar, @KeytypeNumAcc) + N']';

SELECT @KeytypeNumDataStored = (SELECT TOP 1 keytypenum 
                                FROM OnBase.hsi.keytypetable 
                                WHERE keytype like 'Date Stor%');
SET @DateTableName = N'[OnBase].[hsi].[keyitem' + CONVERT(nvarchar, @KeytypeNumDataStored) + N']';

IF TYPE_ID(N'[dbo].[list_varchar]') IS NULL
    EXEC('CREATE TYPE dbo.list_varchar AS TABLE (id varchar(20) NOT NULL PRIMARY KEY);')

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[KfxIndxRconOB_SelectRecFromOnBase]') AND type in (N'P', N'PC'))
    EXEC('CREATE PROCEDURE dbo.KfxIndxRconOB_SelectRecFromOnBase AS RETURN')

DECLARE @sqlstmt nvarchar(MAX);

SET @sqlstmt = 
    N'ALTER PROCEDURE [dbo].[KfxIndxRconOB_SelectRecFromOnBase] (' +  CHAR(13) + CHAR(10) +
	'@id_list list_varchar READONLY, @StartDate datetime, @ReturnRowCounts INT OUT, @ReturnResult BIT OUT) ' + CHAR(13) + CHAR(10) +
	'AS ' +  CHAR(13) + CHAR(10) +
	'BEGIN ' +  CHAR(13) + CHAR(10) +
    '  DECLARE @SysError INT; DECLARE @SysRowCount INT; SET @SysError = 0; ' + CHAR(13) + CHAR(10) +
	'  SELECT a.keyvaluechar as SpStr3, b.keyvaluechar as Account, c.keyvaluechar as SSN, d.itemdate as DocDate ' + CHAR(13) + CHAR(10) +
	'  FROM ' + @UniqIDTableName + ' a ' + CHAR(13) + CHAR(10) +
	'  INNER JOIN ' + @AccTableName + ' b ON a.itemnum = b.itemnum ' + CHAR(13) + CHAR(10) +
	'  INNER JOIN ' + @SSNTableName + 'c ON a.itemnum = c.itemnum ' + CHAR(13) + CHAR(10) +
    '  INNER JOIN OnBase.hsi.itemdata d ON a.itemnum = d.itemnum ' + CHAR(13) + CHAR(10) +
	'  INNER JOIN ' + @DateTableName + ' e ON a.itemnum = e.itemnum ' + CHAR(13) + CHAR(10) +
    '  WHERE a.keyvaluechar IN (SELECT id FROM @id_list) AND ' + CHAR(13) + CHAR(10) +
	'        e.keyvaluedate >= @StartDate ' + CHAR(13) + CHAR(10) +
	'  ORDER BY SpStr3; ' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10) +
	
    '  SELECT 	@SysError = @@ERROR, @SysRowCount = @@ROWCOUNT; ' + CHAR(13) + CHAR(10) +
	'  IF @SysError <> 0 ' + CHAR(13) + CHAR(10) +
	'    BEGIN ' + CHAR(13) + CHAR(10) +
	'      SET @ReturnResult = 0; SET @ReturnRowCounts = 0; RETURN; ' + CHAR(13) + CHAR(10) +
	'    END ' + CHAR(13) + CHAR(10) +
	'  ELSE ' + CHAR(13) + CHAR(10) +
	'    BEGIN ' + CHAR(13) + CHAR(10) +
	'      SET @ReturnRowCounts = @SysRowCount; SET @ReturnResult = 1 ' + CHAR(13) + CHAR(10) +
	'    END ' + CHAR(13) + CHAR(10) +
    'END;';

EXEC(@sqlstmt);
