USE [OnBaseHelper]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- We select records for daily processing based on ScanDate, but compare dates during processing using DocDate
CREATE TABLE [dbo].[MemdocRecords](
	[SpStr3] [varchar](20) NOT NULL,
	[DocDate] [datetime] NULL,
	[Account] [varchar](20) NULL,
	[SSN] [varchar](11) NULL,
	[ScanDate] [datetime] NULL
) ON [PRIMARY]
GO
