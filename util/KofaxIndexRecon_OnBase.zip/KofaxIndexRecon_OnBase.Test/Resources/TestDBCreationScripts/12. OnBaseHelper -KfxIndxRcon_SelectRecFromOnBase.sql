USE [OnBaseHelper]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [KfxIndxRconOB_SelectRecFromOnBase]
(		
	@id_list  	list_varchar READONLY,
	@StartDate       datetime,
	@ReturnRowCounts INT OUT,
	@ReturnResult	 BIT OUT
) 
AS
BEGIN
    DECLARE @SysError       INT; 
    DECLARE @SysRowCount INT;
    SET @SysError = 0;

    SELECT SpStr3, DocDate, Account,	SSN
	FROM MemdocRecords
	WHERE SpStr3 IN (SELECT id FROM @id_list) AND
	      ScanDate >= @StartDate
    ORDER BY SpStr3;

	SELECT 	@SysError = @@ERROR, 
                @SysRowCount = @@ROWCOUNT;

	IF @SysError <> 0
	    BEGIN			
	        SET @ReturnResult = 0;
                        SET @ReturnRowCounts = 0;				
	        RETURN
	    END
	ELSE
	    BEGIN				
	        SET @ReturnRowCounts = @SysRowCount;
	        SET @ReturnResult = 1;						
	    END
END; 