USE [Kofax_FormInfoKIR]
GO

-- Permissions for database Tables
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.FormInfo TO [DEVNCSECU\svc-dkfx-process];
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.ExecutionHistory TO [DEVNCSECU\svc-dkfx-process];
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.FormIDs_To_Process TO [DEVNCSECU\svc-dkfx-process];
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.OnBase_MemdocRecords TO [DEVNCSECU\svc-dkfx-process];

-- Permissions for database stored procedures
GRANT EXECUTE ON KfxIndxRconOB_SelectRecFromKofaxInfo TO [DEVNCSECU\svc-dkfx-process];
GRANT EXECUTE ON KfxIndxRconOB_UpdtRecScannedButMissingInOnBase TO [DEVNCSECU\svc-dkfx-process];
GRANT EXECUTE ON KfxIndxRconOB_UpdateFormInfoTable TO [DEVNCSECU\svc-dkfx-process];
GRANT EXECUTE ON KfxIndxRcon_UpdtRecNotScanned TO [DEVNCSECU\svc-dkfx-process];
GRANT EXECUTE ON KfxIndxRconOB_TruncateTables TO [DEVNCSECU\svc-dkfx-process];

GO


