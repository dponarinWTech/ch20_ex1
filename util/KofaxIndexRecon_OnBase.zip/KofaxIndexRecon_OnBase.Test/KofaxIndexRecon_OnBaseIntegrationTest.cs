﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Assert = NUnit.Framework.Assert;

namespace KofaxIndexRecon_OnBase.Test
{
    /* **************************************************************************************************************************
     * 
     * This class performs tests against toy databases Kofax_FormInfoKIR and OnBaseHelper on the local SQL Server (see connection 
     * strings in the settings KofaxConnectionString and OBHelperConnectionString). 
     * 
     * To create these databases run all scripts in the folder \KofaxIndexRecon.Test\Resources\TestDBCreationScripts in order
     *  
     * **************************************************************************************************************************/
    [TestFixture]
    class KofaxIndexRecon_OnBaseIntegrationTest
    {
        private Recon recon;

        private SqlConnection sqlConnectionKofax;
        private SqlConnection sqlConnectionOnBase;

        List<string> uniqueIds;  // unique Ids from 'FormIDs_To_Process'

        DateTime lastSuccessfulRun;

        /// <summary>
        /// Total number of records inserted to 'FormInfo' table. 
        /// Incremented in InsertOneRecordKofax() only.
        /// </summary>
        private int numRecordsInFormInfo = 0;

        /// <summary>
        /// Total number of records inserted to table 'MemdocRcords' in OnBaseHelper. 
        /// Incremented in InsertOneRecordOnBase() only.
        /// </summary>
        private int numRecordsInOnBase = 0;

        /// <summary>
        /// Running counter of records inserted to 'FormIDs_To_Process' table (in Kofax)
        /// </summary>
        int numRecordsInFormInfoToProcess = 0;

        /// <summary>
        /// Running counter of records inserted to 'OnBase_MemdocRecords' table (in Kofax)
        /// </summary>
        private int numRecordsInOBMemdocRecords = 0;

        /// <summary>
        /// Variable to hold Id of record to be updated by SP 'KfxIndxRcon_UpdtRecNotScanned' (ScanDate is null AND Status is null);
        /// expected Status = MISSING, Reason ='ScanDate Empty'
        /// </summary>
        private int idScanDateEmpty = 0;

        /// <summary>
        /// Variable to keep UID of record to be updated by SP 'KfxIndxRconOB_UpdtRecScannedButMissingInTower' 
        /// (ScanDate is null AND  Status is null AND there is no matching rec. in OnBase). 
        /// Expected Status = MISSING, Reason = 'Kofax Index Database has the document but it is Missing in OnBase'.
        /// </summary>
        private string uidScannedNotUpdated = "";

        [OneTimeSetUp]
        public void SetupOnce()
        {
            recon = new Recon(null);  // we will not use logger

            uniqueIds = new List<string>();
            using (new Impersonator(Properties.Settings.Default.ServiceAccountID, 
                                    Properties.Settings.Default.ServiceAccountDomain, 
                                    Properties.Settings.Default.ServiceAccountPassword))
            {
                sqlConnectionKofax = Recon.OpenConnection(Properties.Settings.Default.KofaxConnectionString);
                sqlConnectionOnBase = Recon.OpenConnection(Properties.Settings.Default.OBHelperConnectionString);
            }
            TruncateFormInfo(sqlConnectionKofax);
            TruncateOB(sqlConnectionOnBase);
            TruncateCurrentTables(sqlConnectionKofax);

            string lastRunDate = recon.GetLastSuccessfulRunFromConfig();
            lastSuccessfulRun = DateTime.ParseExact(lastRunDate, "MM-dd-yyyy", 
                                                    System.Globalization.CultureInfo.InvariantCulture);

            PopulateFormInfo(sqlConnectionKofax, sqlConnectionOnBase);
        }

        [SetUp]
        public void Setup()
        {
            if (sqlConnectionKofax != null && sqlConnectionKofax.State != System.Data.ConnectionState.Open) { sqlConnectionKofax.Open(); }
            if (sqlConnectionOnBase != null && sqlConnectionOnBase.State != System.Data.ConnectionState.Open) { sqlConnectionOnBase.Open(); }
            TruncateCurrentTables(sqlConnectionKofax);
        }

        [TearDown]
        public void TearDown()
        {
            if (sqlConnectionKofax != null && sqlConnectionKofax.State == System.Data.ConnectionState.Open) { sqlConnectionKofax.Close(); }
            if (sqlConnectionOnBase != null && sqlConnectionOnBase.State == System.Data.ConnectionState.Open) { sqlConnectionOnBase.Close(); }
        }

        [OneTimeTearDown]
        public void TearDownOnce()
        {
            recon = null;
        }


        #region // put desired records to tables FormInfo (Kofax) and  MemdocRecords (OnBaseHelper)
        private void PopulateFormInfo(SqlConnection sqlConnKofax, SqlConnection sqlConnTower)
        {
            // We select records for daily processing based on ScanDate, but compare dates during processing using DocDate
            string dateAfter = lastSuccessfulRun.AddDays(2).ToString("yyyy-MM-dd");
            string dateBefore = lastSuccessfulRun.AddDays(-2).ToString("yyyy-MM-dd");

            // Id = 1, Status = null, DocDate date is before LastSuccessfulRun, ScanDate is after LastSuccessfulRun.
            // Matching record in OnBase.
            // expected final Status = FOUND
            string xml = GetXml(new string[] { "111111111" }, new string[] { "0001" });
            int countTmp = InsertOneRecordKofax(sqlConnKofax, xml, null, null, dateBefore);
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0001", "111111111", dateBefore, dateAfter);
            numRecordsInFormInfoToProcess++;
            numRecordsInOBMemdocRecords++;
            uniqueIds.Add("TST" + countTmp.ToString("D8"));

            // Id = 2, Status = 'Not Found', ScanDate is before LastSuccessfulRun, Reason is not null. 
            // No matching record in OnBase.
            // expected final Status = 'Not Found', Reason = null
            xml = GetXml(new string[] { "222222222" }, new string[] { "0002" });
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, "Not Found", "Some Reason", dateBefore);
            numRecordsInFormInfoToProcess++;
            uniqueIds.Add("TST" + countTmp.ToString("D8"));

            // Id = 3, Status = PARTIAL, ScanDate is not null and more than 1 day before LastSuccessfulRun, Reason is not null.
            // Matching record in OnBase.
            // expected final Status = FOUND
            xml = GetXml(new string[] { "333333333" }, new string[] { "0003" });
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, "PARTIAL", "zzz", dateBefore, "ONBASE");
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0003", "333333333", dateBefore, dateAfter);
            numRecordsInFormInfoToProcess++;
            numRecordsInOBMemdocRecords++;
            uniqueIds.Add("TST" + countTmp.ToString("D8"));

            // Id = 4, Status = 'Not Found', ScanDate is before LastSuccessfulRun;
            // Matching record in OnBase
            // expected final Status = FOUND
            xml = GetXml(new string[] { "444444444" }, new string[] { "0004" });
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, "Not Found", "zzz", dateBefore);
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0004", "444444444", dateBefore, dateAfter);
            numRecordsInFormInfoToProcess++;
            numRecordsInOBMemdocRecords++;
            uniqueIds.Add("TST" + countTmp.ToString("D8"));

            // Id = 5, Status is null, ScanDate is null;
            // Matching record in OnBase
            // expected final Status = MISSING, Rason = 'ScanDate Empty'
            xml = GetXml(new string[] { "555555555" }, new string[] { "0005" });
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml);
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0005", "555555555", scanDate: dateAfter);
            // it shouldn't get into 'FormIDs_To_Process' so we don't increment numRecordsInFormInfoToProcess
            // it shouldn't get into 'OnBase_MemdocRecords' because its UID is not in the list, so we don't incement numRecordsInOBMemdocRecords
            idScanDateEmpty = countTmp;

            // Id = 6, Status = null, ScanDate is before LastSuccessfulRun;
            // no matching records in OnBase
            // expected final Status = MISSING, Reason = 'Kofax Index Database has the document but it is Missing in OnBase'
            xml = GetXml(new string[] { "666666666" }, new string[] { "0006" });
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, null, null, dateBefore);
            numRecordsInFormInfoToProcess++;   // should get into 'FormIDs_To_Process'
            uniqueIds.Add("TST" + countTmp.ToString("D8"));
            uidScannedNotUpdated = "TST" + countTmp.ToString("D8");

            // 4 records in Kofax with Id = 7, Status = null, Reason is not null, ScanDate is before LastSuccessfulRun;
            // not all matching records there are in OnBase
            // expected final Status = PARTIAL, Reason = 'Missing or mismatching SSN, Account number or CreateDate'
            xml = GetXml(new string[] { "711111111", "722222222" }, new string[] { "0071", "0072" });
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, null, "some reason", dateBefore);
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0071", "711111111", dateBefore, dateAfter);
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0072", "711111111", dateBefore, dateAfter);
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0072", "722222222", dateBefore, dateAfter);
            uniqueIds.Add("TST" + countTmp.ToString("D8"));
            numRecordsInFormInfoToProcess += 4;
            numRecordsInOBMemdocRecords += 3;

            // 4 records in Kofax with Id = 8, Status = null, Reason is not null, ScanDate is before LastSuccessfulRun;
            // all matching records there are in OnBase
            // expected final Status = FOUND, Reason = null
            xml = GetXml(new string[] { "811111111", "822222222" }, new string[] { "0081", "0082" });
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, null, "some reason", dateBefore);
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0081", "811111111", dateBefore, dateAfter);
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0082", "811111111", dateBefore, dateAfter);
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0081", "822222222", dateBefore, dateAfter);
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0082", "822222222", dateBefore, dateAfter);
            uniqueIds.Add("TST" + countTmp.ToString("D8"));
            numRecordsInFormInfoToProcess += 4;
            numRecordsInOBMemdocRecords += 4;

            // 1 record with Id = 9, status = Partial, Reason is not null, ScanDate is before LastSuccessfulRun, UpdateBy = ONBASE;
            // No matching record in OnBase
            // expected final Status = Partial, Reason - unchanged
            xml = GetXml(new string[] { "999999999" }, new string[] { "0009" });
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, "PARTIAL", "ZZZ", dateBefore, "ONBASE");
            uniqueIds.Add("TST" + countTmp.ToString("D8"));
            numRecordsInFormInfoToProcess++;   // should get into 'FormIDs_To_Process', though Status shouldn't be updated

            // 1 record with Id = 10, status = Partial, Reason is not null, ScanDate is before LastSuccessfulRun, UpdateBy = SYSTEM;
            // Matching record in OnBase
            // expected final Status = Partial, Reason - unchanged (shouldn't be selected for processing because UpdateBy = SYSTEM)
            xml = GetXml(new string[] { "101010101" }, new string[] { "0010" });
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, "PARTIAL", "ZZZZ", dateBefore, "SYSTEM");
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0010", "101010101", dateBefore, dateAfter);
            // shouldn't get into 'FormIDs_to_Process'
            // shouldn't get into 'OnBase_MemdocRecords' because its UID is not in the list

            // 1 record with Id = 11, status = Missing, Reason is null, ScanDate is before LastSuccessfulRun, UpdateBy = ONBASE;
            // Record in OnBase matching but with ScanDate before LastSuccessfulRun
            // expected final Status = Missing, Reason = 'Missing record'  (OnBase record shouldn't be selected because ScanDate before LastSuccessfulRun)
            xml = GetXml(new string[] { "110000000" }, new string[] { "0011" });
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, "MISSING", null, dateBefore, "ONBASE");
            InsertOneRecordOnBase(sqlConnectionOnBase, countTmp, "0011", "110000000", dateBefore, dateBefore);
            uniqueIds.Add("TST" + countTmp.ToString("D8"));
            numRecordsInFormInfoToProcess++;
            // shouldn't get into 'OnBase_MemdocRecords' because ScanDate before LastSuccessfulRun
        }

        // SqlConnection is assumed to be open
        private int InsertOneRecordKofax(SqlConnection sqlConnection, string xml, string status = null, 
                                         string reason = null, string date = null, string updateBy = null)
        {
            ++numRecordsInFormInfo;

            string sql1 = "INSERT INTO [dbo].[FormInfo]([Id], [FormType], [InfoXml]";
            string sql2 = "VALUES(@count, 'TST', @xml";
            if (status != null)
            {
                sql1 += ", [Status]";
                sql2 += ", @status";
            }
            if (reason != null)
            {
                sql1 += ", [Reason]";
                sql2 += ", @reason";
            }
            if (date != null)
            {
                sql1 += ", [ScanDate], [CreateDate]";
                sql2 += ", @scanDate, @createDate";
            }
            if (updateBy != null)
            {
                sql1 += ", [UpdateBy]";
                sql2 += ", @updateBy";
            }
            string sql = sql1 + ")" + sql2 + ")";

            using (SqlCommand command = new SqlCommand(sql, sqlConnection))
            {
                command.CommandType = CommandType.Text;
                command.CommandText = sql;
                command.Parameters.AddWithValue("@count", numRecordsInFormInfo);
                command.Parameters.AddWithValue("@xml", xml);
                if (status != null)
                {
                    command.Parameters.AddWithValue("@status", status);
                }
                if (reason != null)
                {
                    command.Parameters.AddWithValue("@reason", reason);
                }
                if (date != null)
                {
                    command.Parameters.AddWithValue("@scanDate", date);
                    command.Parameters.AddWithValue("@createDate", date);
                }
                if (updateBy != null)
                {
                    command.Parameters.AddWithValue("@updateBy", updateBy);
                }

                command.ExecuteNonQuery();
            }
            return numRecordsInFormInfo;
        }

        // Sqlconnection is assumed to be open
        // We select records for daily processing based on ScanDate, but compare dates during processing using DocDate
        private void InsertOneRecordOnBase(SqlConnection sqlConnection, int id, string acc = null, string ssn = null, string docDate = null, string scanDate = null)
        {
            string uid = "TST" + id.ToString("D8");
            string sql1 = "INSERT INTO [dbo].[MemdocRecords]([spstr3]";
            string sql2 = "VALUES (@uid";
            if (acc != null)
            {
                sql1 += ", [account]";
                sql2 += ", @acc";
            }
            if (ssn != null)
            {
                sql1 += ", [ssn]";
                sql2 += ", @ssn";
            }
            if (docDate != null)
            {
                sql1 += ", [DocDate]";
                sql2 += ", @docDate";
            }
            if (scanDate != null)
            {
                sql1 += ", [ScanDate]";
                sql2 += ", @scanDate";
            }
            string sql = sql1 + ")" + sql2 + ")";

            using (SqlCommand command = new SqlCommand(sql, sqlConnection))
            {
                command.CommandType = CommandType.Text;
                command.CommandText = sql;
                command.Parameters.AddWithValue("@uid", uid);
                if (acc != null) { command.Parameters.AddWithValue("@acc", acc); }
                if (ssn != null) { command.Parameters.AddWithValue("@ssn", ssn); }
                if (docDate != null) { command.Parameters.AddWithValue("@docDate", docDate); }
                if (scanDate != null) { command.Parameters.AddWithValue("@scanDate", scanDate); }

                command.ExecuteNonQuery();
            }

            numRecordsInOnBase++;
        }
        #endregion // put desired records to tables FormInfo (Kofax) and  MemdocRecords (OnBaseHelper)


        [Test]
        public void OpenConnectionsTest()
        {
            using (new Impersonator(Properties.Settings.Default.ServiceAccountID,
                        Properties.Settings.Default.ServiceAccountDomain,
                        Properties.Settings.Default.ServiceAccountPassword))
            {
                Assert.AreEqual(System.Data.ConnectionState.Open, sqlConnectionKofax.State, "Kofax connection is not open");
                Assert.AreEqual(System.Data.ConnectionState.Open, sqlConnectionOnBase.State, "OnBase connection is not open");
                string currentUser = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
                Assert.AreEqual(Properties.Settings.Default.ServiceAccountDomain + "\\" + Properties.Settings.Default.ServiceAccountID, 
                                currentUser, "Wrong current user");
            }
        }

        [Test]
        public void TruncateTablesTest()
        {
            using (new Impersonator(Properties.Settings.Default.ServiceAccountID,
            Properties.Settings.Default.ServiceAccountDomain,
            Properties.Settings.Default.ServiceAccountPassword))
            {
                var returnValue = recon.TruncateTables();
                Assert.AreEqual(true, returnValue, "TruncateTables() returned False");

                int count = (int)RunScalarQuery(sqlConnectionKofax, "SELECT COUNT(*) FROM [dbo].[FormIDs_To_Process];");
                Assert.AreEqual(0, count, "Table [FormIDs_To_Process] was not truncated");

                count = (int)RunScalarQuery(sqlConnectionKofax, "SELECT COUNT(*) FROM [dbo].[OnBase_MemdocRecords];");
                Assert.AreEqual(0, count, "Table [OnBase_MemdocRecords] was not truncated");
            }
        }

        [Test]
        public void WholeTest()
        {
            bool returnValue;

            using (new Impersonator(Properties.Settings.Default.ServiceAccountID,
                                    Properties.Settings.Default.ServiceAccountDomain,
                                    Properties.Settings.Default.ServiceAccountPassword))
            {
                returnValue = recon.Populate_FormIDs_To_Process(Properties.Settings.Default.SP_PopulateFormIdsToProcess);
                Assert.IsTrue(returnValue, "Populate_FormIDs_To_Process() has failed");

                returnValue = recon.ExecSP(Properties.Settings.Default.SP_UpdateRecNotScanned, "FormInfo");
                Assert.IsTrue(returnValue, $"SP [{Properties.Settings.Default.SP_UpdateRecNotScanned}] has failed");

                string kofaxSqlQuery = "SELECT DISTINCT	UIDNumber FROM dbo.FormIDs_To_Process WITH(NOLOCK) ORDER BY UIDNumber";
                List<String> uidList = recon.GetUniqueIDList(sqlConnectionKofax, kofaxSqlQuery);
                Assert.IsNotNull(uidList, "uidList is null");

                DataSet ds;
                OnBaseCommunicator obCommunicator = new OnBaseCommunicator(null);
                ds = obCommunicator.FetchOnBaseData(uidList);
                Assert.IsNotNull(ds, "DataSet is null after FetchOnBaseData()");

                returnValue = recon.BulkCopyDataToKofaxTable(ds.Tables[Properties.Settings.Default.TableName_MemdocRecords], sqlConnectionKofax);
                Assert.IsTrue(returnValue, "BulkCopyDataToKofaxTable() has failed");

                returnValue = recon.ExecSP(Properties.Settings.Default.SP_UpdtRecScannedButMissingInCMS, Properties.Settings.Default.TableName_KofaxRecords);
                Assert.IsTrue(returnValue, $"SP [{Properties.Settings.Default.SP_UpdtRecScannedButMissingInCMS}] has failed");

                ds = recon.AddSecondTableToDataSet(ds, Properties.Settings.Default.TableName_KofaxRecords);
                Assert.IsNotNull(ds, "DataSet is null after AddSecondTableToDataSet()");

                returnValue = recon.AssignStatuses(ds, uidList);
                Assert.IsTrue(returnValue, "AssignStatuses() has failed");

                returnValue = recon.UpdateKofaxTableFromDataSet(ds, Properties.Settings.Default.TableName_KofaxRecords);
                Assert.IsTrue(returnValue, "UpdateKofaxTableFromDataSet() has failed");

                returnValue = recon.ExecSP(Properties.Settings.Default.SP_UpdateFormInfoTable, "FormInfo");
                Assert.IsTrue(returnValue, $"SP [{Properties.Settings.Default.SP_UpdateFormInfoTable}] has failed");

                // test records in FormInfo table
                var status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 1");
                var reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 1");
                Assert.AreEqual("FOUND", (status as string)?.ToUpper(), "Wrong Status in record with Id = 1");
                Assert.IsTrue(DBNull.Value.Equals(reason), "Wrong Reason in record with Id = 1");

                status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 2");
                reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 2");
                Assert.AreEqual("NOT FOUND", (status as string)?.ToUpper(), "Wrong Status in record with Id = 2");
                Assert.IsTrue(DBNull.Value.Equals(reason), "Wrong Reason in record with Id = 2");

                status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 3");
                reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 3");
                Assert.AreEqual("FOUND", (status as string)?.ToUpper(), "Wrong Status in record with Id = 3");
                Assert.IsTrue(DBNull.Value.Equals(reason), "Wrong Reason in record with Id = 3");

                status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 4");
                reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 4");
                Assert.AreEqual("FOUND", (status as string)?.ToUpper(), "Wrong Status in record with Id = 4");
                Assert.IsTrue(DBNull.Value.Equals(reason), "Wrong Reason in record with Id = 4");

                status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 5");
                reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 5");
                Assert.AreEqual("MISSING", (status as string)?.ToUpper(), "Wrong Status in record with Id = 5");
                Assert.AreEqual("ScanDate Empty".ToUpper(), (reason as string)?.ToUpper(), "Wrong Reason in record with Id = 5");

                status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 6");
                reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 6");
                Assert.AreEqual("MISSING", (status as string)?.ToUpper(), "Wrong Status in record with Id = 6");
                Assert.AreEqual("Kofax Index Database has the document but it is Missing in OnBase".ToUpper(), 
                                (status as string)?.ToUpper(), "Wrong Reason in record with Id = 6");

                status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 7");
                reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 7");
                Assert.AreEqual("PARTIAL", (status as string)?.ToUpper(), "Wrong Status in record with Id = 7");
                Assert.AreEqual("Missing or mismatching SSN, Account number or CreateDate".ToUpper(),
                                (status as string)?.ToUpper(), "Wrong Reason in record with Id = 7");

                status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 8");
                reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 8");
                Assert.AreEqual("FOUND", (status as string)?.ToUpper(), "Wrong Status in record with Id = 8");
                Assert.IsTrue(DBNull.Value.Equals(reason), "Wrong Reason in record with Id = 8");

                status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 9");
                reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 9");
                Assert.AreEqual("PARTIAL", (status as string)?.ToUpper(), "Wrong Status in record with Id = 9");
                Assert.AreEqual("ZZZ", (status as string)?.ToUpper(), "Wrong Reason in record with Id = 9");

                status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 10");
                reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 10");
                Assert.AreEqual("PARTIAL", (status as string)?.ToUpper(), "Wrong Status in record with Id = 10");
                Assert.AreEqual("ZZZZ", (status as string)?.ToUpper(), "Wrong Reason in record with Id = 10");

                status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 11");
                reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 11");
                Assert.AreEqual("MISSING", (status as string)?.ToUpper(), "Wrong Status in record with Id = 11");
                Assert.AreEqual("MISSING RECORD", (status as string)?.ToUpper(), "Wrong Reason in record with Id = 11");
            }
        }




        #region // Helper methods
        private void TruncateFormInfo(SqlConnection sqlConnKofax)
        {
            if (sqlConnKofax != null && sqlConnKofax.State != ConnectionState.Open) { sqlConnKofax.Open(); }
            using (SqlCommand command = new SqlCommand($"TRUNCATE TABLE [dbo].[FormInfo]", sqlConnKofax))
            {
                command.ExecuteNonQuery();
            }
        }

        private void TruncateOB(SqlConnection sqlConnOB)
        {
            if (sqlConnOB != null && sqlConnOB.State != ConnectionState.Open) { sqlConnOB.Open(); }
            using (SqlCommand command = new SqlCommand("TRUNCATE TABLE [dbo].[MemdocRecords]", sqlConnOB))
            {
                command.ExecuteNonQuery();
            }
        }

        private void TruncateCurrentTables(SqlConnection sqlConnKofax)
        {
            if (sqlConnKofax != null && sqlConnKofax.State != System.Data.ConnectionState.Open) { sqlConnKofax.Open(); }
            List<string> tables = new List<string>() { "[dbo].[FormIDs_To_Process]", "[dbo].[OnBase_MemdocRecords]" };
            foreach (string tbl in tables)
            {
                using (SqlCommand command = new SqlCommand($"TRUNCATE TABLE {tbl}", sqlConnKofax))
                {
                    command.ExecuteNonQuery();
                }
            }
        }
        
        private object RunScalarQuery(SqlConnection sqlConnection, string query)
        {
            object result = null;
            SqlCommand command = new SqlCommand(query, sqlConnection);

            if (sqlConnection != null && sqlConnection.State != System.Data.ConnectionState.Open) { sqlConnection.Open(); }
            result = command.ExecuteScalar();
            return result;
        }

        private string GetXml(string[] SSNs, string[] Accounts)
        {
            string result = @"<form index=""0""><formtype>TST</formtype><ssnlist>";
            if (SSNs != null)
            {
                foreach (string ssn in SSNs)
                {
                    result += @"<ssn>" + ssn?.Trim() + @"</ssn>";
                }
            }
            result += @"</ssnlist><accountlist>";
            if (Accounts != null)
            {
                foreach (string acc in Accounts)
                {
                    result += @"<account accttype = ""002"">" + acc?.Trim() + @"</account>";
                }
            }
            result += @"</accountlist>  
                             <npages>00000</npages>  
                             <empid>S19788D</empid>  
                             <workstationid>WWSN0227</workstationid>  
                             <instnum>001</instnum>  
                             <branchnum>00021</branchnum>
                             </form>";
            return result;
        }
        #endregion // Helper method
    }
}
