﻿using System;
using System.Data.SqlClient;

namespace SqlUpdater
{
    public class SqlHelper
    {
        private string log;

        public SqlHelper(ref string logger)
        {
            log = logger;
        }

        public void SqlInfoMessage(object sender, SqlInfoMessageEventArgs ea)
        {
            WriteSqlMsgs(ea.Errors);
        }

        public void WriteSqlMsgs(SqlErrorCollection msgs)
        {
            string message = "";
            foreach (SqlError e in msgs)
            {

                message += $"Message: '{e.Message}', Error Number: {e.Number}, Severity: {e.Class}, State: {e.State}, Procedure: {e.Procedure}, Line no: {e.LineNumber}" + Environment.NewLine;
                message += e.Message + Environment.NewLine;
            }

            log += "SQL Error: " + Environment.NewLine + message + Environment.NewLine;
        }

        /// <summary>
        /// Returns opened SqlConnection which writes user SQL errors into caller application log
        /// </summary>
        /// <param name="connectionString"></param>
        /// <returns></returns>
        public SqlConnection SetupConnection(string connectionString)
        {
            SqlConnection cn;
            cn = new SqlConnection(connectionString);

            // Handle user errors with callbacks, rather than exception.
            cn.InfoMessage += SqlInfoMessage;
            cn.FireInfoMessageEventOnUserErrors = true;

            cn.Open();
            return cn;
        }

        public string GetDbInfo(string connectionString)
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(connectionString);
            string server = builder.DataSource;
            string db = builder.InitialCatalog;

            return $"database [{db}] on server [{server}]";
        }

        /// <summary>
        /// Returns current user from DB query using specified Sql connection
        /// </summary>
        /// <param name="conn">Sql connection</param>
        /// <returns></returns>
        public static string GetDBUser(SqlConnection conn, ref string log)
        {
            try
            {
                string result = String.Empty;
                using (SqlCommand selectCommand = conn.CreateCommand())
                {
                    selectCommand.CommandText = "SELECT SYSTEM_USER";

                    SqlDataReader myReader;
                    myReader = selectCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        result += myReader[0].ToString() + "  ";
                    }
                    myReader.Close();
                }

                return result;
            }
            catch (SqlException s)
            {
                log += "GetDBUser - SQL Exception: " + s.ToString() + Environment.NewLine;
                return null;
            }
            catch (TimeoutException t)
            {
                log += "GetDBUser - Timeout Exception: " + t.ToString() + Environment.NewLine;
                return null;
            }
            catch (Exception e)
            {
                log += "GetDBUser - Exception: " + e.ToString() + Environment.NewLine;
                return null;
            }
        }

    }
}
