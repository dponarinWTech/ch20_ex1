USE [OnBaseHelper]
GO

DECLARE @DKFX_Login varchar(40);
DECLARE @DKFX_ServiceAccount varchar(40);
DECLARE @sqlstmt varchar(200);

-- NOTE: Update @DKFX_Login  AND  @DKFX_ServiceAccount for target environment
SET @DKFX_Login = 'DEVNCSECU\svc-dkfx-process';
SET @DKFX_ServiceAccount = 'DEVNCSECU\svc-dkfx-process';


SET @sqlstmt =
    ' GRANT EXECUTE ON TYPE::dbo.list_varchar TO [' + @DKFX_ServiceAccount + ']; ' + 
	' GRANT EXECUTE ON KfxIndxRconOB_SelectRecFromOnBase TO [' + @DKFX_ServiceAccount + ']; ' 
PRINT @sqlstmt;
EXEC(@sqlstmt);
	
GO