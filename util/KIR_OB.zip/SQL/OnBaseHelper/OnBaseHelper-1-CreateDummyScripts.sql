USE [OnBaseHelper]
GO

CREATE TYPE [dbo].[list_varchar] AS TABLE (id varchar(20) NOT NULL PRIMARY KEY);
GO

CREATE PROCEDURE dbo.KfxIndxRconOB_SelectRecFromOnBase  AS RETURN
GO
