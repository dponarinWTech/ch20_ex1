USE [OnBaseHelper]
GO

DECLARE @DKFX_Login varchar(40);
DECLARE @DKFX_ServiceAccount varchar(40);
DECLARE @sqlstmt varchar(200);

-- NOTE: Update @DKFX_Login  AND  @DKFX_ServiceAccount for target environment
SET @DKFX_Login = 'DEVNCSECU\svc-dkfx-process';
SET @DKFX_ServiceAccount = 'DEVNCSECU\svc-dkfx-process';

IF  NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = @DKFX_Login)
BEGIN
    SET @sqlstmt = 'CREATE LOGIN [' + @DKFX_Login + '] FROM WINDOWS WITH DEFAULT_DATABASE=[OnBaseHelper], DEFAULT_LANGUAGE=[us_english]';
	PRINT @sqlstmt;
	EXEC(@sqlstmt);
END
GO

IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE NAME = @DKFX_ServiceAccount)
BEGIN
	SET @sqlstmt = 'CREATE USER [' + @DKFX_ServiceAccount + ']  FOR LOGIN [' + @DKFX_Login + '] WITH DEFAULT_SCHEMA=[dbo]';
	PRINT @sqlstmt;
	EXEC(@sqlstmt);
END
GO
