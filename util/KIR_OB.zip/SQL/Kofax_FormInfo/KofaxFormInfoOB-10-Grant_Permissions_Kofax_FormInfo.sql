USE [Kofax_FormInfo]
GO

-- NOTE: Update "Domain"  AND  "UserID" for target environment
-- These changes are valid for following applications - 
--	1 - Kofax Index Recon - Nightly and weekly process
--  2 - Kofax Index Recon OnBase [future]
--  2 - Kofax Margo Branch Scan Report [future]
-- 	3 - Kofax Index Recon User Interface (UI)
--  4 - Kofax UID Batch class

DECLARE @DKFX_Login varchar(40);
DECLARE @DKFX_ServiceAccount varchar(40);

SET @DKFX_Login = 'DEVNCSECU\svc-dkfx-process';

SET @DKFX_ServiceAccount = 'DEVNCSECU\svc-dkfx-process';

DECLARE @sqlstmt varchar(200);


IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE NAME = @DKFX_ServiceAccount)
BEGIN
	SET @sqlstmt = 'CREATE USER [' + @DKFX_ServiceAccount + ']  FOR LOGIN [' + @DKFX_Login + '] WITH DEFAULT_SCHEMA=[dbo]';
	PRINT @sqlstmt;
	EXEC(@sqlstmt);
END
GO

-- Permissions for database Tables
SET @sqlstmt =
    ' GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.FormInfo TO [' + @DKFX_ServiceAccount + '];' +
    ' GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.ExecutionHistory TO [' + @DKFX_ServiceAccount + '];' +
    ' GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.FormIDs_To_Process TO [' + @DKFX_ServiceAccount + '];' +
    ' GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.Tower_MemdocRecords TO [' + @DKFX_ServiceAccount + '];' ;
PRINT @sqlstmt;
EXEC(@sqlstmt);

-- Permissions for database stored procedures
SET @sqlstmt =
    ' GRANT EXECUTE ON GetFormInfo TO [' + @DKFX_ServiceAccount + '];' +
    ' GRANT EXECUTE ON InsertXmlIntoFormInfo TO [' + @DKFX_ServiceAccount + '];' +
    ' GRANT EXECUTE ON KfxIndxRconOB_SelectRecFromKofaxInfo TO [' + @DKFX_ServiceAccount + '];' +
    ' GRANT EXECUTE ON KfxIndxRconOB_UpdtRecScannedButMissingInOnBase TO [' + @DKFX_ServiceAccount + '];' +
    ' GRANT EXECUTE ON KfxIndxRconOB_UpdateFormInfoTable TO [' + @DKFX_ServiceAccount + '];' +
    ' GRANT EXECUTE ON KfxIndxRcon_UpdtRecNotScanned TO [' + @DKFX_ServiceAccount + '];' +
    ' GRANT EXECUTE ON KfxIndxRconOB_TruncateTables TO [' + @DKFX_ServiceAccount + '];' ;    
PRINT @sqlstmt;
EXEC(@sqlstmt);

GO


