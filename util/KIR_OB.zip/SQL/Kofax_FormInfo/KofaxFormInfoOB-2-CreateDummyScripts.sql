USE [Kofax_FormInfo]
GO

-- ========================================================================================================================
-- Description: Create dummy script for initial set up
--				It will create dummy scripts for Stored procedures 
--				Later actual scripts will replace this dummy procedures with correct procedures 
--				Benefit - Developers can create scripts as "ALTER" instead of "CREATE". 
--							AS "ALTER" set up does NOT deletes existing procedures, this arrangement will help 
--							DBAs to maintain granted permissions to all database stored procedures
-- -------------------------------------------------------------------------------------------------
-- Special Instructions: Run ONLY ONCE in each environment during initial set up in target database	      
-- ========================================================================================================================

CREATE PROCEDURE dbo.KfxIndxRconOB_SelectRecFromKofaxInfo AS RETURN
GO

CREATE PROCEDURE dbo.KfxIndxRconOB_TruncateTables AS RETURN
GO

CREATE PROCEDURE dbo.KfxIndxRcon_UpdtRecNotScanned AS RETURN
GO

CREATE PROCEDURE dbo.KfxIndxRconOB_UpdtRecScannedButMissingInOnBase AS RETURN
GO

CREATE PROCEDURE dbo.KfxIndxRconOB_UpdateFormInfoTable AS RETURN
GO 
