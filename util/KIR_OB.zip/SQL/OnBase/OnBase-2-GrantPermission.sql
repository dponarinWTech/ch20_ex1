USE [OnBase]
GO

DECLARE @DKFX_ServiceAccount varchar(40);
DECLARE @sqlstmt varchar(200);

-- NOTE: Update @DKFX_Login  AND  @DKFX_ServiceAccount for target environment
SET @DKFX_ServiceAccount = 'DEVNCSECU\svc-dkfx-process';

SET @sqlstmt = 'EXEC sp_addrolemember ''db_datareader'', [' + @DKFX_ServiceAccount + '] ;';
PRINT @sqlstmt;
EXEC(@sqlstmt);
GO
