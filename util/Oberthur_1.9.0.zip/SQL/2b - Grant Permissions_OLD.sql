USE MEMBERID
GO

-- NOTE: Select @ENVIRONMENT value for target environment
DECLARE @ENVIRONMENT char(4)
SET @ENVIRONMENT = 'DEV'  
-- SET @ENVIRONMENT = 'TEST'
-- SET @ENVIRONMENT = 'PROD'

DECLARE @DOMAIN varchar(20)
DECLARE @Oberthur_ServiceAccount varchar(20)
DECLARE @Oberthur_Login varchar(40)

IF @ENVIRONMENT = 'DEV'
BEGIN
    SET @DOMAIN = 'DEVNCSECU\'
	SET @Oberthur_ServiceAccount = 'dmemid_oberthur'
END
IF @ENVIRONMENT = 'TEST'
BEGIN
	SET @DOMAIN = 'NCSECU\'
	SET @Oberthur_ServiceAccount = 'tmemid_oberthur'
END
IF @ENVIRONMENT = 'PROD'
BEGIN
    SET @DOMAIN = 'NCSECU\'
	SET @Oberthur_ServiceAccount = 'pmemid_oberthur'
END

SET @Oberthur_Login = @DOMAIN + @Oberthur_ServiceAccount;

-- Create Oberthur Role
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'Role_Oberthur' AND type = 'R')
	CREATE ROLE Role_Oberthur AUTHORIZATION dbo
GRANT EXECUTE ON OBERTHUR_SELECT_TVP TO Role_Oberthur;
GRANT EXEC ON TYPE::[dbo].[list_varchar] TO Role_Oberthur;

-- Create user/login and assign them their roles 
DECLARE @sqlstmt varchar(200)

IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = @Oberthur_Login)
BEGIN
	SET @sqlstmt = 'DROP LOGIN [' + @Oberthur_Login + ']'
	PRINT @sqlstmt
	EXEC(@sqlstmt)
END
SET @sqlstmt = 'CREATE LOGIN [' + @Oberthur_Login + '] FROM WINDOWS WITH DEFAULT_DATABASE=[MEMBERID], DEFAULT_LANGUAGE=[us_english]'
PRINT @sqlstmt
EXEC(@sqlstmt)
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = @Oberthur_ServiceAccount)
BEGIN
	SET @sqlstmt = 'DROP USER [' + @Oberthur_ServiceAccount + ']'
	PRINT @sqlstmt
	EXEC(@sqlstmt)
END
SET @sqlstmt = 'CREATE USER [' + @Oberthur_ServiceAccount + '] FOR LOGIN [' + @Oberthur_Login + '] WITH DEFAULT_SCHEMA=[dbo]'
PRINT @sqlstmt
EXEC(@sqlstmt)

EXEC sp_addrolemember 'Role_Oberthur', @Oberthur_ServiceAccount

GO

