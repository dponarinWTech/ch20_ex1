﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using System.Xml;

namespace OberthurPhotoExtract
{
    [RunInstaller(true)]
    public partial class OberthurPhotoExtract_Installer : System.Configuration.Install.Installer
    {
        public OberthurPhotoExtract_Installer()
        {
            InitializeComponent();
        }

        [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Demand)]
        public override void Install(IDictionary stateSaver)
        {
            base.Install(stateSaver);
        }


        protected override void OnBeforeInstall(IDictionary savedState)
        {
            base.OnBeforeInstall(savedState);

            AllowUserInstallations();

            EventLog log = null;
            // make sure EventLog exists and Source is registered with it
            try
            {
                if (!EventLog.Exists(Properties.Settings.Default.EventLogName))
                {
                    if (EventLog.SourceExists(Properties.Settings.Default.EventSourceName))
                    {
                        EventLog.DeleteEventSource(Properties.Settings.Default.EventSourceName);
                    }

                    log = new EventLog();
                    log.Log = Properties.Settings.Default.EventLogName;


                    EventLog.CreateEventSource(Properties.Settings.Default.EventSourceName, Properties.Settings.Default.EventLogName);
                    log.Source = Properties.Settings.Default.EventSourceName;

                    // configure EventLog Overflow properties
                    log.MaximumKilobytes = 4096; // Max log size in KB
                    //log.ModifyOverflowPolicy(OverflowAction.OverwriteAsNeeded, 0);
                    log.ModifyOverflowPolicy(OverflowAction.OverwriteOlder, 10); // records in the log will be retained for 10 days
                }
                // configure existing EventLog
                else
                {
                    log = Logger.GetEventLogByName(Properties.Settings.Default.EventLogName);
                    log.Log = Properties.Settings.Default.EventLogName;

                    // if desired source is not already registered with our Log, delete and recreate the source
                    if (EventLog.SourceExists(Properties.Settings.Default.EventSourceName))
                    {
                        string logFromSource = EventLog.LogNameFromSourceName(Properties.Settings.Default.EventSourceName, ".");
                        if (Properties.Settings.Default.EventLogName != logFromSource)
                        {
                            EventLog.DeleteEventSource(Properties.Settings.Default.EventSourceName);
                            EventLog.CreateEventSource(Properties.Settings.Default.EventSourceName, Properties.Settings.Default.EventLogName);
                        }
                    }

                    log.Source = Properties.Settings.Default.EventSourceName;

                    // configure EventLog Overflow properties
                    log.MaximumKilobytes = 4096; // Max log size in KB
                    //log.ModifyOverflowPolicy(OverflowAction.OverwriteAsNeeded, 0);
                    log.ModifyOverflowPolicy(OverflowAction.OverwriteOlder, 10);  // records in the log will be retained for 10 days
                }
            }
            catch (Exception)
            {
                string msg = $"Failed to create EventLog '{Properties.Settings.Default.EventLogName}' and register source ";
                msg += $"'{Properties.Settings.Default.EventSourceName}' with it. " + Environment.NewLine;
                msg += $"Installation events will not be logged to Event Log.";
                MessageBox.Show(msg, "Event Log Not Created", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }


        protected override void OnAfterInstall(IDictionary savedState)
        {
            base.OnAfterInstall(savedState);

            string appConfigPath = Context.Parameters["assemblypath"] + ".config"; // fully qualifies name of config file
            if (!File.Exists(appConfigPath))
            {
                MessageBox.Show(String.Format("Config file {0} does not exists. Installation failed.", appConfigPath), "Installation failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Rollback(savedState);
                return;
            }

            // Display OberthurPhotoExtract_InstallerForm to let user update config settings
            string logFolder = "";
            string outputBaseFolder = "";
            string inputFolder = "";
            string failedFolder = "";
            using (OberthurPhotoExtract_InstallerForm installForm = new OberthurPhotoExtract_InstallerForm(appConfigPath))
            {
                DialogResult result = installForm.ShowDialog();

                if (result != DialogResult.OK && result != DialogResult.Yes)
                {
                    Rollback(savedState);
                    return;
                }

                logFolder = installForm.LogFolder;
                inputFolder = installForm.InputFolder;
                outputBaseFolder = installForm.OutputBaseFolder;
                failedFolder = installForm.FailedFolder;
            }

            // Verify that all folders exist and give them CreateFiles and Modify permissions for all users
            if (!VerifyDirectory(logFolder))
            {
                MessageBox.Show(String.Format(Properties.Resources.Error_FolderDoesNotExist, logFolder));
            }

            if (!VerifyDirectory(inputFolder))
            {
                MessageBox.Show(String.Format(Properties.Resources.Error_FolderDoesNotExist, inputFolder));
            }

            List<string> inpParams = GetJobList(appConfigPath);
            if(inpParams == null)
            {
                MessageBox.Show(Properties.Resources.Error_FailedReadJobList);
                Rollback(savedState);
                return;
            }
            foreach(string entry in inpParams)
            {
                string newFolder = Path.Combine(outputBaseFolder, "Oberthur_" + entry);
                if (!VerifyDirectory(newFolder))
                {
                    MessageBox.Show(String.Format(Properties.Resources.Error_FolderDoesNotExist, newFolder));
                }
            }

            if (!VerifyDirectory(failedFolder))
            {
                MessageBox.Show(String.Format(Properties.Resources.Error_FolderDoesNotExist, failedFolder));
            }


            UpdateVersion(Path.Combine(Path.GetDirectoryName(appConfigPath), "Log4net.config"));

            if (!EncryptAppConfig(Context.Parameters["assemblypath"]))
            {
                MessageBox.Show(Properties.Resources.Error_CannotEncrypt, "Encryption failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            string ver = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
            Logger.WriteEventLog($"OberthurPhotoExtract ver.{ver} installed successfully.", EventLogEntryType.Information);
        }

        /// <summary>
        /// Checks that given directory exists, and tries to create it if it does not exist.
        /// </summary>
        /// <param name="folderName">Fully qualified name of the folder</param>
        /// <returns>True if the folder exists at the end of method execution, false otherwise.</returns>
        private bool VerifyDirectory(string folderName)
        {
            try
            {
                if (!Directory.Exists(folderName))
                {
                    Directory.CreateDirectory(folderName);
                }

                return Directory.Exists(folderName);
            }
            catch(Exception ex)
            {
                Logger.WriteEventLog("Exception thrown while trying to create folder " + folderName + Environment.NewLine + ex, System.Diagnostics.EventLogEntryType.Error);
                return false;
            }
        }

        /// <summary>
        /// Encrypts connectionStrings section in App.config using Data Protection API (DPAPI).
        /// Helper method for  OnAfterInstall().
        /// </summary>
        /// <param name="appName">Fully qualified path to application .exe file</param>
        /// <returns></returns>
        private bool EncryptAppConfig(string appName)
        {
            try
            {
                Configuration config = ConfigurationManager.OpenExeConfiguration(appName);
                ConnectionStringsSection section = config.GetSection("connectionStrings") as ConnectionStringsSection;
                if (!section.SectionInformation.IsProtected)
                {
                    section.SectionInformation.ProtectSection("DataProtectionConfigurationProvider");
                    section.SectionInformation.ForceSave = true;
                }
                config.Save();

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Changes Registry key that sometimes disallows user installations. Since it's optional (it may be needed only when installation failed on the first try),
        /// if this registry edit fails we continue installation.
        /// </summary>
        public void AllowUserInstallations()
        {
            try
            {
                using (Microsoft.Win32.RegistryKey key = Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Policies\Microsoft\Windows\Installer", true))
                {
                    if (key != null)
                    {
                        key.SetValue("DisableUserInstalls", "0", Microsoft.Win32.RegistryValueKind.DWord);
                        key.Close();
                    }
                }
            }
            catch (System.Security.SecurityException)
            {
                MessageBox.Show(String.Format(Properties.Resources.Warn_NoPermissionToChangeRegistry, @"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\Installer", "DisableUserInstalls"),
                    "Cannot Update Registry Key", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch
            {
                Logger.WriteEventLog(Properties.Resources.Warn_FailedUpdateReg, EventLogEntryType.Warning);
            }
        }


        private static string UpdateVersion(string log4netConfigFile)
        {
            string result = "Oberthur Photo Extract ver." + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString();
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.PreserveWhitespace = true;  // preserve formatting of XML document
                doc.Load(log4netConfigFile);

                // get root element of XML file 
                XmlElement root = doc.DocumentElement;

                // XPath to <param> element which contains Header for RollingFileAppender;
                // if structure of Log4Net.config changes this string may need to be changed as well.
                string xpath = "descendant::appender[@name='RollingFileAppender']/layout/param[@name='Header']";

                XmlNodeList lst = root.SelectNodes(xpath);
                if (lst == null)
                {
                    return null;
                }

                // write new Header
                lst[0].Attributes["value"].Value = lst[0].Attributes["value"].Value.Replace("Oberthur Photo Extract", result);
                doc.Save(log4netConfigFile);
            }
            catch (Exception)
            {
                return null;
            }
            return result;
        }

        /// <summary>
        /// Reads list of job names from list InputParameterList in config file.
        /// It reads from config file as XML file because ConfigurationManager does not work in the installer project.
        /// </summary>
        /// <param name="configFileName">fully qualified name of application's config file</param>
        /// <returns>List of job names of reading is successful, null otherwise</returns>
        private List<String> GetJobList(String configFileName)
        {
            List<String> inpParams = new List<String>();
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(configFileName);

                // get root element of XML file 
                XmlElement root = doc.DocumentElement;

                string xpath = "descendant::InputGroup/InputParameterList/add";
                XmlNodeList lst = root.SelectNodes(xpath);

                for (int i = 0; i < lst.Count; i++)
                {
                    string val = lst[i].Attributes["value"].Value;
                    if (String.IsNullOrEmpty(val))
                    {
                        MessageBox.Show("One of output folders was not created. Please complete this step manually.");
                        continue;
                    }
                    else
                    {
                        inpParams.Add(val);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception in GetJobList(): " + ex.ToString(), "OberthurPhotoExtract_Installer Error", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }

            return inpParams;
        }


    }
}
