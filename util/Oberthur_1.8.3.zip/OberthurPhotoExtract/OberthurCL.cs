﻿using System; 
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using System.Configuration;
using System.Collections.Specialized;


namespace OberthurPhotoExtract
{
    /// <summary>
    /// Retrieve photoFileName and signature images matching the requested Oberthur cards and prepare them to be transmitted.
    /// </summary>
    class OberthurCL
    {

        #region // const
        // error codes for abnormal end of application
        const int INVALID_COMMAND_LINE_ARG = 81;
        const int FAILED_UPDATE_LOG4NET_CONFIG = 82;
        const int EXCEPTION_IN_EXTRACT_PHOTOS = 83;
        const int SOURCE_FOLDER_DOES_NOT_EXIST = 84;
        const int DESTINATION_FOLDER_DOES_NOT_EXIST = 85;
        const int FAILED_WRITING_HEADER_FILE = 86;
        const int FAILED_WRITING_TRAILER_FILE = 87;
        const int IMAGE_RETRIEVAL_FAILED = 88;
        const int FAILED_RESIZE_PHOTO_JPG = 89;
        const int FAILED_CREATING_ZIP_FILE = 90;
        const int FAILED_CREATING_BLANK_ZIP_FILE = 91;
        const int INVALID_SSNS_ONLY_IN_INPUT_FILE = 92;
        const int TOP_LEVEL_ERROR = 93;
        #endregion

        // suffix (based on JCL name) to be added to output file name and log file name (to avoid collisions)
        internal static string suffix = string.Empty;

        // Directory where output file(s) will be dropped for pickup by PDM. All output files will be dropped to the same folder.
        private static string targerDirectory = string.Empty;

        private string _failedSubFolder = string.Empty;

        public static Logger log;
        private readonly string className;
        private int numPhotos;
        public static String log4netConfig; // full path to Log4Net config file 

        private ConvertAndResizeCL convertResize;

        // Lists that accumulate information for summary
        private List<string> found;                   // successfully found photos
        private List<string> invalidInputLines;       // invalid lines in the input file
        private List<string> failedToRead;            // failed to retrieve record from DB
        private List<string> noPhoto;                 // no Photo in DB record
        private List<string> badPathPhoto;            // failed to retrieve Photo file specified in DB
        private List<string> failedToCopy;            // photos failed to copy from filer to destination folder
        private List<string> failedToResize;          // photos failed to resize (potentially corrupt)

        // List of input file lines with images that failed to copy from filer to destination or on which resizing failed;
        // these lines will be re-processed from scratch on the second pass.
        private List<string> toReProcess;

        public OberthurCL()
        {
            className = GetType().Name;
            numPhotos = 0;

            found = new List<string>();
            invalidInputLines = new List<string>();
            failedToRead = new List<string>();
            noPhoto = new List<string>();
            badPathPhoto = new List<string>();
            failedToCopy = new List<string>();
            failedToResize = new List<string>();

            toReProcess = new List<string>();

            convertResize = new ConvertAndResizeCL(log);
        }

        static int Main(string[] args)
        {
            try
            {
                int inputParam = -1;
                if (args.Length > 0 && int.TryParse(args[0], out inputParam))
                {
                    mapArgs(inputParam);
                    targerDirectory = Path.Combine(Properties.Settings.Default.baseOutputDirectory, "Oberthur" + suffix);
                }
                else
                {
                    Logger.WriteEventLog($"Invalid command line parameter: {args[0]}.", EventLogEntryType.Error);
                    LogGeneralError($"Invalid command line parameter: '{args[0]}'.");
                    Environment.Exit(INVALID_COMMAND_LINE_ARG);
                }

                if (String.IsNullOrEmpty(suffix))  // received invalid command line parameter
                {
                    Logger.WriteEventLog($"Invalid command line parameter: {args[0]}", EventLogEntryType.Error);
                    LogGeneralError($"Invalid command line parameter: '{args[0]}'.");
                    Environment.Exit(INVALID_COMMAND_LINE_ARG);
                }


                log = new Logger(MethodBase.GetCurrentMethod().DeclaringType.FullName);

                log.LogInfo("Current thread is running under credentials: " + System.Security.Principal.WindowsIdentity.GetCurrent().Name);
                log.LogInfo($"Command line parameter: {inputParam}, suffix = {suffix}");

                OberthurCL oberthurInstance = new OberthurCL();
                oberthurInstance.ExtractPhotos();

                return 0;
            }
            catch (Exception ex)
            {
                Logger.WriteEventLog("Exception in Main(): " + ex, EventLogEntryType.Error);
                return TOP_LEVEL_ERROR;
            }
        }

        #region //static methods
        /// <summary>
        /// Assigns values suffix based on command line argument.
        /// </summary>
        /// <param name="input">Command line argument</param>
        private static void mapArgs(int input)
        {
            Dictionary<int, String> inpParams = GetDictionary(@"InputGroup/InputParameterList");
            if (inpParams == null)
            {
                suffix = String.Empty;
                return;
            }

            if (inpParams.Keys.Contains(input))
            {
                suffix = "_" + inpParams[input];
            }
            else { suffix = String.Empty; }

            // initialize log4netConfig
            string log4NetConfigFolder = Path.GetDirectoryName(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile);
            log4netConfig = Path.Combine(log4NetConfigFolder, "Log4net.config");
        }

        internal static Dictionary<int, string>  GetDictionary(String configSectionName)
        {
            Dictionary<int, String> inpParams = new Dictionary<int, String>();
            NameValueCollection inpParameters = ConfigurationManager.GetSection(configSectionName) as NameValueCollection;
            if (inpParameters == null)
            {
                log.LogFatal(Properties.Resources.Error_FailedReadInputParameterList);
                return null;
            }

            foreach (var key in inpParameters.AllKeys)
            {
                int tmp = Int32.MinValue;
                if (!int.TryParse(key, out tmp))
                {
                    log.LogFatal(String.Format(Properties.Resources.Error_InvalidKeyInDictionary, key));
                    return null;
                }

                string val = inpParameters[key];
                if (String.IsNullOrEmpty(val))
                {
                    log.LogFatal(String.Format(Properties.Resources.Error_InvalidValueInDictionary, key));
                    return null;
                }

                try
                {
                    inpParams.Add(tmp, val.Trim());
                }
                catch (ArgumentException)
                {
                    log.LogFatal(String.Format(Properties.Resources.Error_DuplicateKeyInDictionary, key));
                    return null;
                }
                catch (Exception exc)
                {
                    log.LogError("Exception in GetJobList(): " + exc.ToString());
                    return null;
                }
            }

            return inpParams;
        }

        private static void LogGeneralError(string errorMsg)
        {
            try
            {
                String logFile = Path.Combine(Properties.Settings.Default.logFolder, "OberthurPhotoExtract_LogInvalid.log");

                // since Log4net does not manage this Log file, we'll take care that its size does not exceed preset limit
                if (File.Exists(logFile))
                {
                    long fileLength = new System.IO.FileInfo(logFile).Length;
                    String line1 = File.ReadLines(logFile).First().TrimStart(); // first line

                    // remove first lines one by one until line starting with '*' encountered
                    while (fileLength >= Properties.Settings.Default.MaxLogInvalidSizeBytes)
                    {
                        do
                        {
                            string[] lines = File.ReadAllLines(logFile);
                            File.WriteAllLines(logFile, lines.Skip(1).ToArray());

                            line1 = File.ReadLines(logFile).First().TrimStart();
                        } while (!line1.StartsWith("*"));

                        fileLength = new System.IO.FileInfo(logFile).Length;
                    }
                }

                String text = "****************Oberthur Photo Extract ver." + Assembly.GetExecutingAssembly().GetName().Version.ToString()
                    + "****************" + Environment.NewLine + Environment.NewLine;
                text += DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "   ERROR OberthurPhotoExtract.Main   - " + errorMsg
                    + Environment.NewLine + Environment.NewLine + Environment.NewLine;
                File.AppendAllText(logFile, text);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception in OberthurCL.LogGeneralError() " + ex.ToString());
                Logger.WriteEventLog("Exception in OberthurCL.LogGeneralError() " + ex.ToString(), EventLogEntryType.Error);
            }
        } 

        /// <summary>
        /// Replaces all characters in the string except for last N (configurable value, usually 4) with 'x'.
        /// If string is null, blank or shorter than N chars - returns unchanged string.
        /// </summary>
        /// <param name="inputStr"></param>
        /// <returns></returns>
        public static string MaskString(string inputStr)
        {
            if (string.IsNullOrWhiteSpace(inputStr)) { return inputStr; }

            string inputTrimmed = inputStr.Trim();
            int len = inputTrimmed.Length;
            if (len <= Properties.Settings.Default.NumberOfUnmaskedChars) { return inputStr; }

            return new string('x', len - Properties.Settings.Default.NumberOfUnmaskedChars) +
                   inputTrimmed.Substring(len - Properties.Settings.Default.NumberOfUnmaskedChars);
        }
        #endregion //static methods


        /// <summary>
        /// Returns name of subfolder for storing photos that failed to resize; the name is based on current the timestamp.
        /// This subfolder is created once per program run, at the time of first call to this method.
        /// </summary>
        /// <returns>Fully qualified subfolder name, or empty string if subfolder creation fails</returns>
        public string GetFailedFolder()
        {
            if (!string.IsNullOrWhiteSpace(_failedSubFolder) && Directory.Exists(_failedSubFolder))
            {
                return _failedSubFolder;
            }

            // subfolder does not exist - create it and return its name
            string subfolder = Path.Combine( Properties.Settings.Default.failedFolder, DateTime.Now.ToString("yyyyMMdd_HH_mm_ss"));
            try
            {
                Directory.CreateDirectory(subfolder);
                _failedSubFolder = subfolder;
            }
            catch (Exception ex)
            {
                log.LogError($"Failed to create subfolder '{subfolder}' for storing photos that failed to resize. Exception: " + ex.Message);
                _failedSubFolder = string.Empty;
            }
            
            return _failedSubFolder;
        }

        protected void ExtractPhotos()
        {
            log.LogDebug("Method ExtractPhotos: Begin");
            try
            {
                log.LogInfo("Oberthur Photo Extract Process" + Environment.NewLine);
                log.LogInfo("Photos Processed for " + DateTime.Today.ToShortDateString() + Environment.NewLine);

                if (!Directory.Exists(Properties.Settings.Default.sourceDirectory))
                {
                    log.LogFatal( String.Format(Properties.Resources.Error_SourceDirectoryNotExists, Properties.Settings.Default.sourceDirectory));
                    Environment.Exit(SOURCE_FOLDER_DOES_NOT_EXIST);
                }

                if (!Directory.Exists(targerDirectory))
                {
                    log.LogFatal(String.Format(Properties.Resources.Error_TargetDirectoryNotExists, targerDirectory));
                    Environment.Exit(DESTINATION_FOLDER_DOES_NOT_EXIST);
                }

                // input files for all JCLs are located in the same directory; input file name has suffix matching JCL name
                string ssnExtractName = Path.Combine(Properties.Settings.Default.sourceDirectory, String.Format(Properties.Settings.Default.ssnExtractName, suffix));
                string holdExtractName = Path.Combine(Properties.Settings.Default.sourceDirectory, String.Format(Properties.Settings.Default.holdExtractName, suffix));

                string headerFileName = Path.Combine( targerDirectory, Properties.Settings.Default.headerFileName );
                string trailerFileName = Path.Combine( targerDirectory, Properties.Settings.Default.trailerFileName );

                //clear out destination directory
                foreach (string aFile in Directory.GetFiles(targerDirectory))
                {
                    File.Delete(aFile);
                }

                if (!WriteHeaderFile(headerFileName))
                {
                    Environment.Exit(FAILED_WRITING_HEADER_FILE);
                }

                if( !File.Exists(ssnExtractName))
                {
                    log.LogError($"SSN Extract file '{ssnExtractName}' does not exist.");
                    return;
                }

                int returnCode = GetImages(targerDirectory, ssnExtractName, holdExtractName); 
                switch (returnCode)
                {
                    case -2:
                        log.LogWarn("There are no valid SSNs in the input file");
                        if (!CreateEmptyZip(targerDirectory))
                        {
                            log.LogError("Failed to create blank zip file");
                            Environment.Exit(FAILED_CREATING_BLANK_ZIP_FILE);
                        }
                        Environment.Exit(INVALID_SSNS_ONLY_IN_INPUT_FILE);
                        break; // execution never gets here - added to make compiler happy
                    case -1:
                        log.LogWarn("Input file is empty");
                        if (!CreateEmptyZip(targerDirectory))
                        {
                            log.LogError("Failed to create blank zip file");
                            Environment.Exit(FAILED_CREATING_BLANK_ZIP_FILE);
                        }
                        return;
                    case 1:
                        log.LogError("Image retrieval failed.");
                        Environment.Exit(IMAGE_RETRIEVAL_FAILED);
                        break; 
                }

                if (!WriteTrailerFile(trailerFileName))
                {
                    Environment.Exit(FAILED_WRITING_TRAILER_FILE);
                }

                log.LogDebug("Preparing to create zip file.");
                if (!convertResize.CreateZip(targerDirectory))
                {
                    log.LogError("Unable to create zip file.");
                    Environment.Exit(FAILED_CREATING_ZIP_FILE);
                }
                else
                {
                    log.LogDebug("Successfully created zip file.");
                }
            }
            catch (Exception ex)
            {
                log.LogFatal(ex.ToString());
                Environment.Exit(EXCEPTION_IN_EXTRACT_PHOTOS);
            }
            finally
            {
                log.LogDebug("Method ExtractPhotos: End");
            }
        }

        /// <summary>
        /// Output the header file to be sent to Oberthur containing the date and our company name.
        /// </summary>
        /// <param name="headerFileName">header file name</param>
        /// <returns>True if the file was created successfully, false otherwise</returns>
        private bool WriteHeaderFile(string headerFileName)
        {
            log.LogInfo("Method WriteHeaderFile: Begin");
            try
            {
                string header = string.Format(Properties.Resources.FileHeaderString, DateTime.Today.ToShortDateString());
                File.WriteAllText(headerFileName, header);
                log.LogInfo("Completed writing text to header file");

                return true;
            }
            catch (Exception e)
            {
                log.LogFatal(Properties.Resources.Error_UnableToWriteHeaderFile);
                log.LogError(e);
                return false;
            }
            finally
            {
                log.LogDebug("Method WriteHeaderFile: End");
            }
        }

        /// <summary>
        /// Output the trailer file to be sent to Oberthur containing the total number of 
        /// photoFileName/signature pairs and the number of photos being sent without a signature.
        /// </summary>
        /// <param name="trailerFileName">trailer file name</param>
        /// <returns>True if the file created successfully, false otherwise.</returns>
        private bool WriteTrailerFile(string trailerFileName)
        {
            log.LogInfo("Method WriteTrailerFile: Begin");
            try
            {
                String trailerFileContents = string.Format(Properties.Settings.Default.TrailerFileNumPhotos, numPhotos);
                File.WriteAllText(trailerFileName, trailerFileContents);
                log.LogInfo("Completed writing trailer file");
                return true;
            }
            catch (Exception e)
            {
                log.LogFatal(Properties.Resources.Error_UnableToWriteTrailerFile);
                log.LogError(e);
                return false;
            }
            finally
            {
                log.LogDebug("Method WriteTrailerFile: End");
            }
        }


        /// <summary>
        /// Forms list of SSNs from input files, retrieves from DB photo file names for these SSNs and copy photo files
        /// to the destination folder '<paramref name="destDirectory"/>'. 
        /// Also writes info about successfully processed photos to 'holdextract' file if current JCL creates such file.
        /// </summary>
        /// 
        /// <param name="destDirectory">Folder to store extracted images</param>
        /// <param name="ssnExtractFileName">Input file name</param>
        /// <param name="holdFileName">Output 'holdextract' file name (will be placed in the input folder)</param>
        /// <returns> 0 indicates successful completion, 
        ///           negative number indicates there are no SSNs to process (-1 = empty input file, -2 = no SSNs found),
        ///           1 indicates failure.
        /// </returns>
        private int GetImages(string destDirectory, string ssnExtractFileName, string holdFileName)
        {
            log.LogInfo($"{className}.{GetCallerName()}: Begin");
            log.LogDebug($"    {className}.{GetCallerName()} - Destination folder: " + destDirectory);
            log.LogDebug($"    {className}.{GetCallerName()} - SSN Extract Filename: " + ssnExtractFileName);

            // get array of lines from input file; include only non-blank lines
            string[] lines = File.ReadAllLines(ssnExtractFileName).Where(s => !string.IsNullOrWhiteSpace(s)).Select(s => s.Trim('\r', '\n', ' ')).ToArray();
            if (lines.Length == 0) { return -1; }

            log.LogDebug($"    {className}.{GetCallerName()}: Preparing list of SSNs");
            List<String> ssns = GetSsnList(lines, "    ");
            if (ssns == null) { return 1; }
            else if (ssns.Count == 0) { return -2; }
            log.LogDebug($"    {className}.{GetCallerName()}: List of {ssns.Count} SSNs successfully prepared");

            // Retrieve from DB pairs (SSN, Photo) for SSNs in the list; store result in DataSet
            DataSet dSet = ReadPhotoFileNamesFromDb(ssns, "    ");
            if (dSet == null)
            {
                return 1;
            }

            if (!CopyPhotoFiles(lines, dSet, holdFileName, destDirectory, "    "))
            {
                return 1;
            }

            if (toReProcess.Count == 0)  
            {
                LogSummarySuccessful();
            }
            else  // second pass
            {
                log.LogWarn($"    After first pass there are {toReProcess.Count} records that failed to copy from filer or failed to resize.");  

                if (!CopyPhotoFilesSecondPass(toReProcess, dSet, holdFileName, destDirectory, "    "))
                {
                    return 1;
                }

                if (toReProcess.Count == 0)
                {
                    LogSummarySuccessful();
                }
                else
                {
                    LogSummaryFail();
                    log.LogInfo($"{className}.{GetCallerName()}: End");
                    return 1;
                }
            }

            log.LogInfo($"{className}.{GetCallerName()}: End");
            return 0;
        }


        /// <summary>
        /// Forms appropriate file names for photo files, and copies photo files under these names from origin specified in DataSet to destination folder.
        /// Also writes info about successfully processed photos to 'holdextract' file if current JCL creates such file.
        /// </summary>
        /// <param name="lines">Array of lines from input file</param>
        /// <param name="dSet">DataSet with photo file names in file storage</param>
        /// <param name="holdFileName">File name for 'holdextract' file</param>
        /// <param name="destDirectory">Destination folder for photo files</param>
        /// <param name="indent">Indentation in log file</param>
        /// <returns>False only if exception was thrown</returns>
        public bool CopyPhotoFiles(string[] lines, DataSet dSet, string holdFileName, string destDirectory, string indent)
        {
            try
            {
                log.LogInfo(indent + $"{className}.{GetCallerName()}:  Begin");

                // prepare to write lines with successfully processed photos to "holdextract" file
                // NOTE: "holdextract" file is not created by JCLs  MIDPM140 and MIDPR840.
                File.WriteAllText(holdFileName, ""); // clear file
                StreamWriter matchesFileStream = File.AppendText(holdFileName);

                using (new Impersonator(Properties.Settings.Default.UserID, Properties.Settings.Default.Domain,
                    Properties.Settings.Default.Password, log))
                {
                    log.LogInfo(indent + $"    {className}.{GetCallerName()}: Credentials used to communicate with file storage: " +
                        System.Security.Principal.WindowsIdentity.GetCurrent().Name);

                    foreach (string line in lines)
                    {
                        string[] lineParts = line.TrimEnd('\r', '\n', ' ').Split(' ');
                        String currentSSN = lineParts[0].Trim();
                        String cardNumber = lineParts[1].Trim();

                        // skip invalid lines - they may cause exception when looking for them in DataSet
                        if (!long.TryParse(lineParts[0], out long dummy) || 
                            lineParts.Length < Properties.Settings.Default.MinNumberOfTokensInInputFileRow)
                        {
                            continue;
                        }

                        var currentRow = dSet.Tables["MemberPhotos"].Select("SSN=" + currentSSN).FirstOrDefault();
                        if (currentRow == null)
                        {
                            failedToRead.Add(MakeListEntry(lineParts));
                            continue;
                        }

                        string photoFileName = currentRow.Field<string>("Photo");
                        if (string.IsNullOrEmpty(photoFileName))
                        {
                            noPhoto.Add(MakeListEntry(lineParts));
                            continue;
                        }

                        String destFileName = cardNumber;
                        if (IsCredit(lines[0]))
                        {
                            destFileName += lineParts[2] + lineParts[3];
                        }

                        if (File.Exists(photoFileName))
                        {
                            string destinationImage = Path.Combine(destDirectory, destFileName + ".jpg");
                            File.Copy(photoFileName, destinationImage);

                            if ( !File.Exists(destinationImage) )
                            {
                                toReProcess.Add(line);
                                log.LogWarn(indent + $"Photo with SSN {MaskString(currentSSN)} and Card# {MaskString(cardNumber)} failed to copy from filer");
                                continue;
                            }

                            if (!convertResize.ResizeSinglePhoto(destinationImage))  
                            {
                                toReProcess.Add(line);
                                SaveFailedFile(photoFileName, destinationImage, MaskString(currentSSN), MaskString(cardNumber));
                                log.LogWarn(indent + $"Photo with SSN {MaskString(currentSSN)} and Card# {MaskString(cardNumber)} failed to resize");
                                continue;
                            }

                            numPhotos++;
                            found.Add(MakeListEntry(lineParts));

                            // write to "holdextract" file (if this file is created by the current mainframe job)
                            if (suffix != "_MIDPM140" && suffix != "_MIDPR840")
                            {
                                matchesFileStream.WriteLine(line);
                            }
                        }
                        else
                        {
                            badPathPhoto.Add(MakeListEntry(lineParts) + $", photo file name: {photoFileName}");
                        }
                    }
                }
                matchesFileStream.Flush();
                matchesFileStream.Close();

                return true;
            }
            catch (Exception ex)
            {
                log.LogError(indent + $"Exception in {className}.{GetCallerName()}: " + ex.ToString());
                return false;
            }
            finally
            {
                log.LogInfo(indent + $"{className}.{GetCallerName()}:  End");
            }
        }

        public bool CopyPhotoFilesSecondPass(List<string> lines, DataSet dSet, string holdFileName, string destDirectory, string indent)
        {
            try
            {
                log.LogInfo(indent + $"{className}.{GetCallerName()}:  Begin");

                // will write lines with successfully processed photos to "holdextract" file
                StreamWriter matchesFileStream = File.AppendText(holdFileName);

                // make copy of input list - will use this copy to iterate (from original list we'll remove lines)
                List<string> copyLines = new List<string>();
                foreach (string str in lines) { copyLines.Add(str); }


                using (new Impersonator(Properties.Settings.Default.UserID, 
                                        Properties.Settings.Default.Domain, 
                                        Properties.Settings.Default.Password, log))
                {
                    log.LogInfo(indent + $"    {className}.{GetCallerName()}: Credentials used to communicate with file storage: " +
                                System.Security.Principal.WindowsIdentity.GetCurrent().Name);

                    foreach (string line in copyLines)
                    {
                        string[] lineParts = line.TrimEnd('\r', '\n', ' ').Split(' ');
                        String currentSSN = lineParts[0].Trim();
                        String cardNumber = lineParts[1].Trim();

                        // skip invalid lines - they may cause exception when looking for them in DataSet
                        if (!long.TryParse(lineParts[0], out long dummy) ||
                            lineParts.Length < Properties.Settings.Default.MinNumberOfTokensInInputFileRow)
                        { continue; }


                        var currentRow = dSet.Tables["MemberPhotos"].Select("SSN=" + currentSSN).FirstOrDefault(); // we know it wouldn't fail because it succeeded in the first pass
                        string photoFileName = currentRow.Field<string>("Photo"); // we know it is not null - from 1st pass

                        String destFileName = cardNumber;
                        if (IsCredit(lines[0]))
                        {
                            destFileName += lineParts[2] + lineParts[3];
                        }
                        string destinationImage = Path.Combine(destDirectory, destFileName + ".jpg");

                        // delete photo file potentially left after 1st pass as it can be corrupted
                        if (File.Exists(destinationImage))
                        {
                            File.Delete(destinationImage);
                        }

                        // we know from 1st pass that file photoFileName exists
                        File.Copy(photoFileName, destinationImage);

                        if (!File.Exists(destinationImage))
                        {
                            failedToCopy.Add(MakeListEntry(lineParts) + $", photo file name: '{photoFileName}'");
                            continue;
                        }
                        if (!convertResize.ResizeSinglePhoto(destinationImage))  
                        {
                            SaveFailedFile(photoFileName, destinationImage, MaskString(currentSSN), MaskString(cardNumber));
                            failedToResize.Add(MakeListEntry(lineParts) + $", file name: '{photoFileName}'");
                            continue;
                        }

                        // successfully processed photo 
                        numPhotos++;
                        found.Add(MakeListEntry(lineParts));
                        // write to "holdextract" file if necessary
                        if (suffix != "_MIDPM140" && suffix != "_MIDPR840") { matchesFileStream.WriteLine(line); }
                        
                        // remove successfully processed line from ReProcess list
                        toReProcess.Remove(line);
                    }
                }
                matchesFileStream.Flush();
                matchesFileStream.Close();

                return true;
            }
            catch (Exception ex)
            {
                log.LogError(indent + $"Exception in {className}.{GetCallerName()}: " + ex.ToString());
                return false;
            }
            finally
            {
                log.LogInfo(indent + $"{className}.{GetCallerName()}:  End");
            }
        }

        public void SaveFailedFile(string fileNameInFiler, string fileNameOnServer, string ssn, string cardNumber)
        {
            // sanity check
            if (!File.Exists(fileNameOnServer))
            {
                log.LogError($"{className}.{ GetCallerName()}: file '{fileNameOnServer}' does not exist.");
                return;
            }

            try
            {
                // check (and possibly trim) size of FAILED folder only once per application run, when subfolder for this run is created
                if (string.IsNullOrWhiteSpace(_failedSubFolder))
                {
                    CheckFailedFolderSize(Properties.Settings.Default.failedFolder);
                }

                string folder = GetFailedFolder();
                if (string.IsNullOrWhiteSpace(folder)) { return; } // folder for storing failed images cannot be created

                string fileName = Path.GetFileName(fileNameOnServer);
                if (string.IsNullOrEmpty(fileName))
                {
                    log.LogError($"{className}.{GetCallerName()}: failed to extract file name from path '{fileNameOnServer}'");
                    return;
                }

                string failedFile = "";
                if (!File.Exists(Path.Combine(folder, fileName)))
                {
                    failedFile = Path.Combine(folder, fileName);
                }
                else
                {
                    failedFile = Path.Combine(folder, Path.GetFileNameWithoutExtension(fileName) + "_2" + Path.GetExtension(fileName));
                }
                File.Copy(fileNameOnServer, Path.Combine(folder, failedFile));

                // write information about failed photo to local log file
                string info = $"{(DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"))},  ";
                info += $"JCL: {suffix.TrimStart('_')},  File name: '{failedFile}',  ";
                info += $"SSN: {ssn}, Card#: {cardNumber},  File name in filer: '{fileNameInFiler}'" + Environment.NewLine;

                string logFile = Path.Combine(folder, "log.txt"); // local log file
                File.AppendAllText(logFile, info);
            }
            catch(Exception e)
            {
                log.LogError($"{className}.{GetCallerName()} - Exception: " + e.ToString());
            }
        }

        /// <summary>
        /// Checks folder size and if it exceeds limit (configurable value) deletes oldest subfolders until the size gets under the limit.
        /// </summary>
        /// <param name="folderName">Fully qualified name of the folder to be checked / trimmed</param>
        public void CheckFailedFolderSize(string folderName)
        {
            log.LogInfo("CheckFailedFolderSize: Begin");
            if (!Directory.Exists(folderName))
            {
                log.LogWarn($"Folder '{folderName}' does not exist.");
                return;
            }

            // list of all subfolders ordered by last write time, oldest first
            var subfolderList = Directory.GetDirectories(folderName).OrderBy(x => Directory.GetLastWriteTime(x)).ToList();
            while (GetFolderSize(folderName) >= Properties.Settings.Default.MaxFailedFolderSize_MB * 1048576)
            {
                if (subfolderList.Count < 1) break;

                string oldestSubFolder = subfolderList[0];
                Directory.Delete(oldestSubFolder, true); // delete oldest subfolder (and its subfolders and files, recursively) 
                log.LogDebug($"    Deleted folder '{oldestSubFolder}'");
                subfolderList.RemoveAt(0);
            }

            log.LogInfo($"After cleaning size of folder '{folderName}' is {GetFolderSize(folderName):n0} bytes");
            log.LogInfo("CheckFailedFolderSize: end");
        }

        /// <summary>
        /// Returns size, in bytes, of specified folder including all subfolders recursively.
        /// </summary>
        /// <param name="folder"></param>
        /// <returns></returns>
        public long GetFolderSize(string folder)
        {
            string[] allEntries = Directory.GetFiles(folder, "*.*", SearchOption.AllDirectories);
            long result = 0;
            foreach (string entry in allEntries)
            {
                FileInfo info = new FileInfo(entry);
                result += info.Length;
            }

            return result;
        }

        public string MakeListEntry(string[] lineParts)
        {
            String result = $"  SSN: {MaskString(lineParts[0])}, Card#: {MaskString(lineParts[1])}";
            for (int i = 2; i < lineParts.Length; i++)
            {
                result += ", " + lineParts[i];
            }
            return result;
        }

        public string ListToSummaryString(List<string> lines)
        {
            if (lines == null || lines.Count == 0)
            {
                return "None";
            }

            string result = "";
            foreach (string line in lines)
            {
                result += Environment.NewLine + "  " + line;
            }
            return result;
        }

        public void LogSummarySuccessful()
        {
            string summaryLogMessage = Environment.NewLine +
                                       "Total Photos: " + numPhotos + Environment.NewLine +
                                       "Records Found: " + ListToSummaryString(found) + Environment.NewLine;
            if (invalidInputLines.Count > 0)
            {
                summaryLogMessage += "Invalid Lines in Input File: " + ListToSummaryString(invalidInputLines) + Environment.NewLine;
            }

            if (failedToRead.Count > 0)
            {
                summaryLogMessage += "Failed To Find Record in the DB: " + ListToSummaryString(failedToRead) + Environment.NewLine;
            }

            if (noPhoto.Count > 0)
            {
                summaryLogMessage += "No Photo in DB Record: " + ListToSummaryString(noPhoto) + Environment.NewLine;
            }

            if (badPathPhoto.Count > 0)
            {
                summaryLogMessage += "Photo Files Not Found in the Filer: " + ListToSummaryString(badPathPhoto) + Environment.NewLine;
            }

            log.LogInfo(summaryLogMessage);
        }

        public void LogSummaryFail()
        {
            string summaryLogMessage = "Application failed because following images failed to processes after 2 attempts: " + Environment.NewLine;
            if (failedToCopy.Count > 0)
            {
                summaryLogMessage += "Photos failed to copy from filer to destination folder: " + ListToSummaryString(failedToCopy) + Environment.NewLine;
            }

            if (failedToResize.Count > 0)
            {
                summaryLogMessage += "Photos failed to resize: " + ListToSummaryString(failedToResize) + Environment.NewLine;
            }

            log.LogError(summaryLogMessage);
        }

        /// <summary>
        /// Examines specified line from input file and determines if we're dealing with Credit Card input file.
        /// </summary>
        /// <remarks>We only need to check one line as it will be consistent for all the lines in the file.</remarks>
        /// <param name="line"></param>
        /// <returns>True if Credit Card input file</returns>
        protected bool IsCredit(string line)
        {
            string[] lineParts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            // If the 3rd and 4th parts of the line are numbers, this is a credit card file and those parts are part of the file name.
            string tmpCCFileName = lineParts[2] + lineParts[3];

            return int.TryParse(tmpCCFileName, out int dummy) && tmpCCFileName.Length == 7;
        }

        /// <summary>
        /// Returns list of SSNs extracted from the specified array of lines read from the input file.
        /// </summary>
        /// <param name="lines">Array of input file lines</param>
        /// <param name="indent">Initial indentation in the log file</param>
        /// <returns>SSN list</returns>
        protected List<string> GetSsnList(string[] lines, string indent)
        {
            try
            {
                log.LogInfo(indent + $"{className}.{GetCallerName()}:  Begin");
                List<String> ssns = new List<String>();
                for (int i = 0; i < lines.Length; ++i)
                {
                    string[] lineParts = lines[i].Split(new char[] {' '}, StringSplitOptions.RemoveEmptyEntries);

                    if (lineParts.Length < Properties.Settings.Default.MinNumberOfTokensInInputFileRow)
                    {
                        string msg =
                            $"Invalid line in the input file (number of tokens in the line is less than {Properties.Settings.Default.MinNumberOfTokensInInputFileRow}). ";
                        msg += $"Line number: {i + 1}, SSN = {MaskString(lineParts[0])}";
                        log.LogWarn(indent + $"{className}.{GetCallerName()}: " + msg);
                        invalidInputLines.Add(MakeListEntry(lineParts));
                        continue;
                    }

                    lineParts[0] = lineParts[0].Trim(); // ssn
                    if (!long.TryParse(lineParts[0], out long dummy))
                    {
                        log.LogWarn(indent + $"{className}.{GetCallerName()}: Invalid SSN {MaskString(lineParts[0])} in the input file, line {i + 1}");
                        invalidInputLines.Add(MakeListEntry(lineParts));
                        continue;
                    }

                    if (!ssns.Contains(lineParts[0]))
                    {
                        ssns.Add(lineParts[0]);
                    }
                }

                return ssns;
            }
            catch (Exception ex)
            {
                log.LogError(indent + $"Exception in {className}.{GetCallerName()}: " + ex.ToString());
                return null;
            }
            finally
            {
                log.LogInfo(indent + $"{className}.{GetCallerName()}:  End");
            }
        }

        /// <summary>
        /// Retrieve from DB Photo file names for SSNs in the specified list. Returns DataSet with one table "MemberPhotos"
        /// which has two columns: SSN and corresponding Photo file name (if any).
        /// </summary>
        ///
        /// <remarks>
        /// Uses closed DB connection architecture: DB connection is established, stored procedure is executed, and then connection is closed.
        /// </remarks>
        /// 
        /// <param name="ssns">List of SSN strings</param>
        /// /// <param name="indent">Indentation in the log file</param>
        /// <returns>
        /// DataSet with one table "MemberPhotos" which has two columns: SSN and corresponding Photo file name (if any).
        /// On failure returns null.
        /// </returns>
        protected DataSet ReadPhotoFileNamesFromDb(List<string> ssns, string indent)
        {
            SqlConnection oberthurConn = null;
            try
            {
                log.LogInfo(indent + $"{className}.{GetCallerName()}:  Begin");
                DataSet dSet = new DataSet();
                SqlHelper sqlHelper = new SqlHelper(log);
                oberthurConn = sqlHelper.SetupConnection(); // connection established with impersonation as a service account

                using (SqlCommand selectCommand = new SqlCommand(Properties.Settings.Default.SP_SELECT_TVP, oberthurConn))
                {
                    selectCommand.CommandType = CommandType.StoredProcedure;
                    selectCommand.CommandTimeout = 90; // set timeout 90 sec (by default 30 sec)

                    SqlParameter parameter = selectCommand.Parameters.AddWithValue("@ssn_list", CreateDataTable(ssns));
                    parameter.Direction = ParameterDirection.Input;
                    parameter.SqlDbType = SqlDbType.Structured;
                    parameter.TypeName = "dbo.list_varchar";

                    SqlParameter retVal = selectCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    // create and run DataAdapter with this SelectCommand
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    adapter.SelectCommand = selectCommand;

                    adapter.Fill(dSet, "MemberPhotos");

                    if (!(bool)retVal.Value)
                    {
                        log.LogError(indent + $"{className}.{GetCallerName()}: Failed to populate DataSet with records from MEMBERID database");
                        return null;
                    }
                    else
                    {
                        log.LogDebug(indent + $"    {className}.{GetCallerName()}: Added to DataSet table 'MemberPhotos' with {dSet.Tables["MemberPhotos"].Rows.Count} rows");
                    }
                }
                if (oberthurConn?.State == ConnectionState.Open) { oberthurConn.Close(); }

                return dSet;
            }
            catch (Exception ex)
            {
                log.LogError(indent + $"Exception in {className}.{GetCallerName()}: " + ex.ToString());
                return null;
            }
            finally
            {
                if (oberthurConn?.State == ConnectionState.Open) { oberthurConn.Close(); }
                log.LogInfo(indent + $"{className}.{GetCallerName()}:  End");
            }
        }

        /// <summary>
        /// Turns List<string> into single-column DataTable (column name is "ssn")</string>
        /// </summary>
        /// <param name="ssnList"></param>
        /// <returns></returns>
        protected DataTable CreateDataTable(IEnumerable<string> ssnList)
        {
            DataTable table = new DataTable();
            table.Columns.Add("ssn", typeof(string));
            foreach (string ssn in ssnList)
            {
                table.Rows.Add(ssn);
            }
            return table;
        }

        private bool CreateEmptyZip(string outDirectory)
        {
            string zipFileName = Path.Combine(outDirectory, Properties.Settings.Default.ZipFileName);
            try
            {
                if (File.Exists(zipFileName))
                {
                    File.Delete(zipFileName);
                }

                // create empty zip file
                File.Create(zipFileName).Dispose(); // File.Create leaves file open, so we call Dispose 

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public string GetCallerName()
        {
            try
            {
                // get call stack
                System.Diagnostics.StackTrace stackTrace = new System.Diagnostics.StackTrace();

                // get calling method name
                return stackTrace.GetFrame(1).GetMethod().Name;
            }
            catch (Exception e)
            {
                log.LogError($"{className}.GetCallerName failed: " + e.ToString());
                return null;
            }
        }

    }

}
