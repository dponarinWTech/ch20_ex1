﻿using System;
using System.Data.SqlClient;

namespace OberthurPhotoExtract
{
    /// <summary>
    /// Call method SetupConnection() to get SqlConnection object which logs SQL user errors to the main application's log
    /// Helper class for OberthurCL.
    /// </summary>
    class SqlHelper
    {
        private readonly Logger log;
        private readonly string connstr;
        private readonly string className;

        public SqlHelper(Logger logger)
        {
            connstr = Properties.Settings.Default.dbConnection;
            log = logger;
            className = this.GetType().Name;
        }
        public void WriteSqlMsgs(SqlErrorCollection msgs)
        {
            string message = "";
            foreach (SqlError e in msgs)
            {
                message += $"Msg {e.Number}, Severity {e.Class}, State: {e.State}, Procedure {e.Procedure}, Line no: {e.LineNumber}" + Environment.NewLine;
                message += e.Message + Environment.NewLine;
            }

            log.LogError($"{className}.{GetCallerName()} - SQL Error: " + Environment.NewLine + message);
        }

        public void SqlInfoMessage(object sender, SqlInfoMessageEventArgs ea)
        {
            WriteSqlMsgs(ea.Errors);
        }

        /// <summary>
        /// Returns open SqlConnection
        /// </summary>
        /// <returns></returns>
        public  SqlConnection SetupConnection()
        {
            SqlConnection cn;
            using (new Impersonator(Properties.Settings.Default.UserID, Properties.Settings.Default.Domain, Properties.Settings.Default.Password, log))
            {
                cn = new SqlConnection(connstr);

                // Handle user errors with callbacks, rather than exception.
                cn.InfoMessage += SqlInfoMessage;
                cn.FireInfoMessageEventOnUserErrors = true;

                cn.Open();

                log.LogInfo($"{className}.{GetCallerName()}: DB connection opened with credentials " + GetDBUser(cn));
            }

            return cn;
        }

        public string GetDBUser(SqlConnection conn)
        {
            string methodName = GetCallerName();
            try
            {
                string result = String.Empty;
                using (SqlCommand selectCommand = conn.CreateCommand())
                {
                    selectCommand.CommandText = "SELECT SYSTEM_USER";

                    SqlDataReader myReader = selectCommand.ExecuteReader();
                    while (myReader.Read())
                    {
                        result += myReader[0].ToString() + "  ";
                    }
                    myReader.Close();
                }
                return result;
            }
            catch (SqlException s)
            {
                log.LogError($"{className}.{methodName} - SQL Exception: " + s.ToString());
                return null;
            }
            catch (TimeoutException t)
            {
                log.LogError($"{className}.{methodName} - Timeout Exception: " + t.ToString());
                return null;
            }
            catch (Exception e)
            {
                log.LogError($"{className}.{methodName} - Exception: " + e.ToString());
                return null;
            }
        }

        public string GetCallerName()
        {
            try
            {
                // get call stack
                System.Diagnostics.StackTrace stackTrace = new System.Diagnostics.StackTrace();

                // get calling method name
                return stackTrace.GetFrame(1).GetMethod().Name;
            }
            catch (Exception e)
            {
                log.LogError($"{className}.GetCallerName failed: " + e.ToString());
                return null;
            }
        }

    }
}
