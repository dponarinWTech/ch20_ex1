﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace OberthurPhotoExtract
{
    public partial class OberthurPhotoExtract_InstallerForm : Form
    {
        
        private string configFile;  // fully qualified path to .config file
        private string appName; // name of the application; it's needed because it appears in the setting names
        XDocument doc = new XDocument();

        #region // properties to pass config settings to the caller of this form
        public string LogFolder
        {
            get;
            private set;
        }

        public string InputFolder
        {
            get;
            private set;
        }

        public string OutputBaseFolder
        {
            get;
            private set;
        }

        public string FailedFolder
        {
            get;
            private set;
        }
        #endregion

        public OberthurPhotoExtract_InstallerForm(string appConfig)
        {
            InitializeComponent();
            configFile = appConfig;

            //appName = Process.GetCurrentProcess().ProcessName;
            appName = Path.GetFileName(configFile);
            var tokens = appName.Split('.');
            if(tokens.Length > 0) { appName = tokens[0];  }
            else { appName = "OberthurPhotoExtract"; }
        }

        /// <summary>
        /// Event handler for form loading event.
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OberthurPhotoExtract_InstallerForm_Load(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(txtBaseOutputFolder, Properties.Resources.txtBaseOutFolderToolTip);
            toolTip1.SetToolTip(txtInputFolder, Properties.Resources.txtInputFolderToolTip);
            toolTip1.SetToolTip(txtFailedFolder, Properties.Resources.txtFailedFolderToolTip);

            PopulateFrom(configFile);
        }

        /// <summary>
        /// Event handler for button Cancel click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want cancel configuration settings?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                this.DialogResult = DialogResult.Cancel;
                Close();                
            }
        }


        /// <summary>
        /// Event handler for button OK click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (!VerifyValue(txtDBServer, "Database Server") ||
                !VerifyValue(txtDomain, "Domain") ||
                !VerifyValue(txtUsername, "Username") ||
                !VerifyValue(txtPassword, "Password") ||
                !VerifyValue(txtInputFolder, "Input Folder") ||
                !VerifyValue(txtBaseOutputFolder, "Output Base Folder") ||
                !VerifyValue(txtLogFolder, "Log Folder") ||
                !VerifyValue(txtFailedFolder, "Folder to Store Failed Photos") ||
                !VerifyValue(txtEmailFrom, "Email From") ||
                !VerifyValue(txtEmailRecipients, "Email Recipients") )
            { return; }

            this.DialogResult = SaveConfig(configFile) ? DialogResult.OK : DialogResult.Cancel;

            Close();
        }

        /// <summary>
        /// Populates the form with values from .config file
        /// </summary>
        /// <param name="configFileName">Fully qualified file name of .config file</param>
        private void PopulateFrom(string configFileName)
        {
            try
            {
                XDocument doc = XDocument.Load(configFileName);
                XElement root = doc.Element("configuration");

                // read applicationSettings
                XElement appSet = root.Element("applicationSettings");
                XElement settingsSection = appSet.Element(appName + ".Properties.Settings");
                IEnumerable<XElement> settings = settingsSection.Elements("setting");
                foreach(var elt in settings)
                {
                    if (elt == null) continue;
                    string name = (string)elt.Attribute("name");
                    if (String.IsNullOrEmpty(name)) continue;
                    XElement val = elt.Element("value");
                    if (val == null) continue;

                    switch (name)
                    {
                        case "logFolder":
                            txtLogFolder.Text = val.Value; 
                            break;
                        case "baseOutputDirectory":
                            txtBaseOutputFolder.Text = val.Value;
                            break;
                        case "sourceDirectory":
                            txtInputFolder.Text = val.Value;
                            break;
                        case "failedFolder":
                            txtFailedFolder.Text = val.Value;
                            break;
                        case "EmailFrom":
                            txtEmailFrom.Text = val.Value;
                            break;
                        case "EmailRecipients":
                            txtEmailRecipients.Text = val.Value;
                            break;
                        default:
                            break;
                    }
                }

                // read connectionStrings
                XElement section = root.Element("connectionStrings");
                var conStrings = section.Elements("add");
                foreach (XElement conStr in conStrings)
                {
                    if (conStr == null) continue;
                    XAttribute attrName = conStr.Attribute("name");
                    if (attrName == null) continue;
                    string strName = attrName.Value;
                    // remove from element name part 'OberthurPhotoExtract.Properties.Settings.'
                    strName = strName.Substring(strName.LastIndexOf('.') + 1);
                    XAttribute attrVal = conStr.Attribute("connectionString");
                    if (attrVal == null) continue;

                    switch (strName)
                    {
                        case "UserID":
                            txtUsername.Text = attrVal.Value;
                            break;
                        case "Password":
                            txtPassword.Text = attrVal.Value;
                            break;
                        case "Domain":
                            txtDomain.Text = attrVal.Value;
                            break;
                        case "dbConnection":
                            // get server name from connection string
                            string[] tokens = attrVal.Value.Split(';');
                            foreach(string str in tokens)
                            {
                                if (String.IsNullOrEmpty(str)) continue;
                                string[] s = str.Split('=');
                                if(s[0].Contains("Data Source") && s.Length > 1)
                                {
                                    txtDBServer.Text = s[1];
                                    break;
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
            }
            catch(Exception ex)
            {
                Logger.WriteEventLog("Exception in OberthurPhotoExtract_InstallerForm.PopulateFrom(): " + ex.ToString(), EventLogEntryType.Error);
                MessageBox.Show("Exception in OberthurPhotoExtract_InstallerForm.PopulateFrom(): " + ex.ToString(), "Exception", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }


        private bool SaveConfig(string configFileName)
        {
            try
            {
                XDocument doc = XDocument.Load(configFileName);
                XElement root = doc.Element("configuration");

                // update applicationSettings
                XElement appSet = root.Element("applicationSettings");
                XElement settingsSection = appSet.Element(appName + ".Properties.Settings");
                IEnumerable<XElement> settings = settingsSection.Elements("setting");
                foreach (var elt in settings)
                {
                    if (elt == null) continue;
                    string name = (string)elt.Attribute("name");
                    if (String.IsNullOrEmpty(name)) continue;
                    XElement val = elt.Element("value");
                    if (val == null) continue;

                    switch (name)
                    {
                        case "logFolder":
                            val.Value = txtLogFolder.Text.Trim();
                            LogFolder = txtLogFolder.Text.Trim();
                            break;
                        case "baseOutputDirectory":
                            val.Value = txtBaseOutputFolder.Text.Trim();
                            OutputBaseFolder = txtBaseOutputFolder.Text.Trim();
                            break;
                        case "sourceDirectory":
                            val.Value = txtInputFolder.Text.Trim();
                            InputFolder = txtInputFolder.Text.Trim();
                            break;
                        case "failedFolder":
                            val.Value = txtFailedFolder.Text.Trim();
                            FailedFolder = txtFailedFolder.Text.Trim();
                            break;
                        case "EmailFrom":
                            val.Value = txtEmailFrom.Text.Trim();
                            break;
                        case "EmailRecipients":
                            val.Value = txtEmailRecipients.Text.Trim();
                            break;
                        default:
                            break;
                    }
                }

                // update connectionStrings
                XElement section = root.Element("connectionStrings");
                var conStrings = section.Elements("add");
                foreach (XElement conStr in conStrings)
                {
                    if (conStr == null) continue;
                    XAttribute attrName = conStr.Attribute("name");
                    if (attrName == null) continue;
                    string strName = attrName.Value;
                    // remove from element name part 'OberthurPhotoExtract.Properties.Settings.'
                    strName = strName.Substring(strName.LastIndexOf('.') + 1);
                    XAttribute attrVal = conStr.Attribute("connectionString");
                    if (attrVal == null) continue;
                    switch (strName)
                    {
                        case "UserID":
                            attrVal.Value = txtUsername.Text.Trim();
                            break;
                        case "Password":
                            attrVal.Value = txtPassword.Text.Trim();
                            break;
                        case "Domain":
                            attrVal.Value = txtDomain.Text.Trim();
                            break;
                        case "dbConnection":
                            //verify input value
                            string server = txtDBServer.Text.Trim();
                            if( String.IsNullOrWhiteSpace(server) )
                            {
                                MessageBox.Show("OberthurPhotoExtract_InstallerForm: blank or null string passed as a value 'Database Server'. Installation aborted.", "Invalid value", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return false;
                            }

                            //compose updated connection string
                            string dbConnectionString = ""; // updated connection string
                            string[] tokens = Properties.Settings.Default.dbConnection.Split(';');
                            foreach (string str in tokens)
                            {
                                if(String.IsNullOrEmpty(str)) continue;
                                if(str.Contains("Data Source"))
                                {
                                    dbConnectionString += "Data Source=" + server + ";" ;
                                }
                                else
                                {
                                    dbConnectionString += str + ";" ;
                                }
                            }
                            //remove last semicolon
                            dbConnectionString.TrimEnd(';');

                            attrVal.Value = dbConnectionString;
                            break;
                        default:
                            break;
                    }
                }

                // save changes
                doc.Save(configFileName);

                return true;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Exception in OberthurPhotoExtract_InstallerForm.SaveConfig(): " + ex.ToString(), "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

        }

        /// <summary>
        /// Verifies that specified TextBox is not blank and all characters in it are valid XML characters.
        /// </summary>
        /// <param name="input">String to be verified.</param>
        /// <param name="fieldName">Name of TextBox (as it appears on the Label)</param>
        /// <param name="tb">TextBox under test</param>
        /// <returns></returns>
        private bool VerifyValue(TextBox tb, string fieldName)
        {
            string input = tb.Text;
            if (String.IsNullOrWhiteSpace(input))
            {
                MessageBox.Show($"Field '{fieldName}' cannot be blank.", "Invalid Value",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb.Focus();
                return false;
            }
            string result = null;
            try
            {
                result = XmlConvert.VerifyXmlChars(input);
            }
            catch (XmlException)
            {
                MessageBox.Show($"Invalid XML character in the string '{input}' passed to fielld '{fieldName}'.",
                    "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb.Focus();
                return false;
            }
            catch (Exception e)
            {
                MessageBox.Show($"Exception thrown while verifying input '{input}' passed to fielld '{fieldName}'.",
                    "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error);
                tb.Focus();
                Logger.WriteEventLog("Exception in OberthurCleaner_InstallerForm.VerifyValue: " + e.ToString(), EventLogEntryType.Error);
                return false;
            }
            return true;
        }

    }
}
