﻿using System;
using log4net;
using System.Diagnostics;


namespace OberthurPhotoExtract
{
    public class Logger
    {
        private readonly ILog _mLog;

        public enum MessageType
        {
            Fatal,
            Error,
            Warning,
            Info,
            Debug
        }

        /// <summary>
        ///  Constructor for the logger
        /// </summary>
        /// <param name="callingType">The declaring class</param>
        public Logger(string callingType)
        {
            try
            {
                if (LogManager.GetRepository().Configured)
                {
                    _mLog = LogManager.GetLogger(callingType);
                }
                else
                {
                    // Dynamically set log file name in log4net.config before calling XmlConfigurator.Configure(). See for more details:
                    // https://stackoverflow.com/questions/571876/best-way-to-dynamically-set-an-appender-file-path
                    // http://www.beefycode.com/post/log4net-tutorial-pt-6-log-event-context.aspx
                    // Note: for this approach to work it is critical that <param name="File" > in RollingFileAppender has attribute type="log4net.Util.PatternString"

                    GlobalContext.Properties["logFileName"] = System.IO.Path.Combine(Properties.Settings.Default.logFolder, "OberthurPhotoExtract" + OberthurCL.suffix + ".log");
                    log4net.Config.XmlConfigurator.Configure(new System.IO.FileInfo(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile));

                    _mLog = LogManager.GetLogger(callingType);
                }
            }
            catch (Exception ex)
            {
                WriteEventLog(ex.ToString(), EventLogEntryType.Error);
            }
        }


        public void LogDebug(object message)
        {
            if (_mLog == null)
            {
                WriteEventLog("Log object is null.", EventLogEntryType.Information);
                return;
            }
            _mLog.Debug(message);
        }

        public void LogInfo(object message)
        {
            if (_mLog == null)
            {
                WriteEventLog("Log object is null.", EventLogEntryType.Information);
                return;
            }
            _mLog.Info(message);
        }

        public void LogWarn(object message)
        {
            if (_mLog == null)
            {
                WriteEventLog("Log object is null.", EventLogEntryType.Warning);
                return;
            }
            _mLog.Warn(message);
        }

        public void LogError(object message)
        {
            if (_mLog == null)
            {
                WriteEventLog("Log object is null.", EventLogEntryType.Error);
                return;
            }
            _mLog.Error(message);
        }

        public void LogFatal(object message)
        {
            if (_mLog == null)
            {
                WriteEventLog("Log object is null.", EventLogEntryType.Error);
                return;
            }
            _mLog.Fatal(message);
        }


        /// <summary>
        /// This method writes to EventLog without requiring elevated permissions.
        /// It assumes that EventLog exists, while the Source may not exist. 
        /// </summary>
        /// <remarks>If this method fails, it only writes message to console.</remarks>
        /// <param name="message"></param>
        /// <param name="entryType"></param>
        public static void WriteEventLog(string message, EventLogEntryType entryType)
        {
            try
            {
                using (EventLog log = new EventLog())
                {
                    log.Log = Properties.Settings.Default.EventLogName;
                    log.Source = Properties.Settings.Default.EventSourceName;
                    log.WriteEntry(message, entryType);
                }
            }
            catch (Exception ex)
            {
                string msg = "Failed to write to EventLog message: " + message + Environment.NewLine;
                msg += "Exception:  " + ex;
                Console.Error.WriteLine(msg);
            }
        }

        public static EventLog GetEventLogByName(string name)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(name))
                {
                    return null;
                }

                EventLog[] eventLogs = EventLog.GetEventLogs();
                foreach (EventLog eLog in eventLogs)
                {
                    if (eLog.Log.ToLower() == name.ToLower())
                    {
                        return eLog;
                    }
                }

                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

    }
}
