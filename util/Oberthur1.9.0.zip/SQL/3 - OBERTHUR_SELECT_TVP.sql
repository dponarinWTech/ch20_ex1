USE [MEMBERID]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- ===============================================================================================
-- Author:        Dmitri Ponarin
-- Last modified: 05/04/2020
-- Description:	  Returns SSNs and photo file paths from table MemberInformation for all SSNs in
--                the input table-valued parameter @ssn_list.
-- Execution:	  Will be called by application Oberthur 
-- ===============================================================================================

ALTER PROCEDURE [dbo].[OBERTHUR_SELECT_TVP]
(		
	@ssn_list  		list_varchar READONLY,
	@ReturnResult	BIT OUT
) 
AS
BEGIN	
	DECLARE @ErrorStatus			BIT;
	DECLARE @SysError				INT;
	
	SET @ErrorStatus			= 0;
	SET @SysError				= 0;
-- -----------------------------------------------------------------------------
	BEGIN TRANSACTION SelectDesiredRecords
	    SELECT mi.SSN as SSN, mi.PHOTO as PHOTO
		FROM MemberInformation mi 
		WHERE SSN IN (SELECT ssn FROM @ssn_list);
		-- -----------------------------------------
		
		-- Capture values as it will be reset to zero in next step
		SELECT 	@SysError 	 = @@ERROR
		
		IF @SysError <> 0
			BEGIN
				ROLLBACK TRANSACTION SelectDesiredRecords
				
				SET @ReturnResult 		= 0		-- "BAD" result			
				
				RETURN							-- End further processing
			END
		ELSE
			BEGIN
				COMMIT TRANSACTION SelectDesiredRecords
				
				SET @ReturnResult = 1		-- "GOOD" result						
			END
	;		--	END TRANSACTION SelectDesiredRecords
-- -------------------------------------------------------------------------------
END;  -- End stored procedure "OBERTHUR_SELECT_TVP"