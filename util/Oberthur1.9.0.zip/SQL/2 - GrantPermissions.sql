USE MEMBERID
GO

DECLARE @DOMAIN varchar(20)
DECLARE @ServiceAccount varchar(40)
DECLARE @UserLogin varchar(40)

-- ==============================================================================================================
-- Author:        Dmitri Ponarin
-- Last modified: 04/27/2020
-- Description:	  Grant needed permissions to Oberthur application related database store procedures and tables
--
-- NOTE: Update @DOMAIN  and  @ServiceAccount for target environment.
-- Contact S_Team to determine correct service account for the target environment for application Oberthur
-- ==============================================================================================================

SET @DOMAIN = 'DEVNCSECU\'			-- <== Dev Domain - Modify for target domain
SET @ServiceAccount = 'svc-dimg-memidProces'	-- <== Dev ServiceAccount - Modify for target ServiceAccount
SET @UserLogin = @DOMAIN + @ServiceAccount

-- Create user/login 
DECLARE @sqlstmt varchar(200)

IF NOT EXISTS (SELECT * FROM sys.server_principals WHERE name = @UserLogin)
BEGIN
	SET @sqlstmt = 'CREATE LOGIN [' + @UserLogin + '] FROM WINDOWS WITH DEFAULT_DATABASE=[MEMBERID], DEFAULT_LANGUAGE=[us_english]'
	PRINT @sqlstmt
	EXEC(@sqlstmt)
END

IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = @UserLogin)
BEGIN
	SET @sqlstmt = 'CREATE USER [' + @UserLogin + '] FOR LOGIN [' + @UserLogin + '] WITH DEFAULT_SCHEMA=[dbo]'
	PRINT @sqlstmt
	EXEC(@sqlstmt)
END

-- NOTE: One service account is used for applications:
--       Profile Sync (aka MemberProfileExport) 
--       HR Sync
--       Oberthur [starting ver. 1.8.3]
-- Check SQL scripts in other applications for inconsistencies with this script.

-- Grant permissions for Oberthur application
SET @sqlstmt = 'GRANT SELECT ON MemberInformation to [' + @UserLogin +']'
PRINT @sqlstmt
EXEC(@sqlstmt)

SET @sqlstmt = 'GRANT EXECUTE ON TYPE::dbo.list_varchar to [' + @UserLogin +']'
PRINT @sqlstmt
EXEC(@sqlstmt)

SET @sqlstmt = 'GRANT EXECUTE ON OBERTHUR_SELECT_TVP to [' + @UserLogin +']'
PRINT @sqlstmt
EXEC(@sqlstmt)

GO
