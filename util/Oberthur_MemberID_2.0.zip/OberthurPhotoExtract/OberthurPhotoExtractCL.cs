using System;
using System.Collections.Specialized;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Text.RegularExpressions;
using OberthurPhotoExtract.Properties;
using SECU.Lib;

namespace OberthurPhotoExtract
{
    //*********************************************************************
    //Class:        OberthurPhotoExtractCL
    //Purpose:      Retrieve photo and signature images matching the requested
    //              Oberthur debit cards and prepare them to be transmitted.
    //Changes:      7/16/08 - Begin modifications to switch from uploading an
    //                        accompanying results file with images NOT found to
    //                        uploading a results file listing images that ARE found.
    //*********************************************************************
    public class OberthurPhotoExtractCL
    {
        public static Logger MLog;
        private int numPairs;
        private int numPhotos;

        //*********************************************************************
        //Function:     Main
        //Behavior:     Write log file, call OberthurPhotoExtractCl to write 
        //              header, trailer, and pull images, then call the processing
        //              class to resize and convert the images then put them in
        //              the result zip file.
        //Parameters:   Integer corresponding to index of files/directories in config file to use.
        //              Lists are comma-delimited, e.g. C:\ssn_extract_out,C:\ssn_extract_out\OberthurCC\
        //*********************************************************************
        public static void Main(string[] args)
        {
            StringCollection logConfigs = Settings.Default.loggerConfig;

            int configIdx;
            if ((args.Length == 0) || !int.TryParse(args[0], out configIdx))
            {
                configIdx = 1;
            }

            Logger.Initialize(logConfigs[configIdx-1]);
            MLog = new Logger();
            MLog.Info("Logger Initialized");

            OberthurPhotoExtractCL oberthurPhotoExtractCL = new OberthurPhotoExtractCL();

            //MLog.Debug("OberthurPhotoExtractCL: " + oberthurPhotoExtractCL);

            oberthurPhotoExtractCL.ExtractPhotos(args);
        }

        protected void ExtractPhotos (string[] args)
        {
            MLog.Info("Entering ExtractPhotos()");
            MLog.Debug("Args: " + args);

            //default to first element of files/directories lists
            if (args.Length == 0)
            {
                Console.Error.WriteLine(Settings.Default.Error_NoArgumentSupplied);
                MLog.Error(Settings.Default.Error_NoArgumentSupplied);
                args = new string[1];
                args[0] = "1";
            }

            StringCollection sourceDirectories = Settings.Default.sourceDirectory;
            StringCollection destinationDirectories = Settings.Default.destinationDirectory;
            StringCollection logConfigs = Settings.Default.loggerConfig;
            StringCollection headerFileNames = Settings.Default.headerFileName;
            StringCollection trailerFileNames = Settings.Default.trailerFileName;
            StringCollection ssnExtractNames = Settings.Default.ssnExtractName;
            StringCollection holdExtractNames = Settings.Default.holdExtractName;

            // Compare length of all these counts
            if (!Array.TrueForAll(new[]
                {
                    destinationDirectories.Count,
                    logConfigs.Count,
                    headerFileNames.Count,
                    trailerFileNames.Count,
                    ssnExtractNames.Count,
                    holdExtractNames.Count
                }, val => (destinationDirectories.Count == val)))
            {
                MLog.Error(Settings.Default.FileDirectoryEntriesNotEqualLength);
                Environment.Exit(1);
            }

            try
            {
                int configIdx = System.Convert.ToInt32(args[0]) - 1;

                MLog.Info("Oberthur Photo Extract Process" + Environment.NewLine + Environment.NewLine);
                MLog.Info("Photos Processed for " + DateTime.Today.Month + "/" + DateTime.Today.Day + "/" + DateTime.Today.Year + Environment.NewLine + Environment.NewLine);

                string sourceDirectory = destinationDirectories[configIdx];
                if (!Directory.Exists(sourceDirectory))
                {
                    MLog.Error(string.Format(Settings.Default.Error_SourceDirectoryNotExists, sourceDirectories[configIdx]));
                    Environment.Exit(1);
                }
                string destinationDirectory = destinationDirectories[configIdx];
                if (!Directory.Exists(destinationDirectory))
                {
                    MLog.Error(string.Format(Settings.Default.Error_DestinationDirectoryNotExists, destinationDirectory));
                    Environment.Exit(1);
                }

                //clear out destination directory
                string[] outFiles = Directory.GetFiles(destinationDirectory);
                foreach (string aFile in outFiles)
                {
                    File.Delete(aFile);
                }

                if (!WriteHeaderFile(headerFileNames[configIdx]))
                {
                    Environment.Exit(1);
                }

                if (!GetImages(destinationDirectory, ssnExtractNames[configIdx], holdExtractNames[configIdx]))
                {
                    Environment.Exit(1);
                }

                if (!WriteTrailerFile(trailerFileNames[configIdx]))
                {
                    Environment.Exit(1);
                }

                ConvertandResizeCL convertResize = new ConvertandResizeCL();
                bool resizedJPG = convertResize.ResizeJpGs(destinationDirectories[configIdx]);
                if (!resizedJPG)
                {
                    MLog.Error("Unable to resize JPG images. " + convertResize.GetErrorMessage());
                    Environment.Exit(1);
                }
                bool convertedSigs = convertResize.ConvertSigs(destinationDirectories[configIdx]);
                if (!convertedSigs)
                {
                    MLog.Error("Unable to convert WMF images. " + convertResize.GetErrorMessage());
                    Environment.Exit(1);
                }
                MLog.Debug("Preparing to create zip file.");
                bool createdZip = convertResize.CreateZip(destinationDirectories[configIdx]);
                if (!createdZip)
                {
                    MLog.Error("Unable to create zip file. " + convertResize.GetErrorMessage());
                    Environment.Exit(1);
                }
            }
            catch (Exception e)
            {
                MLog.Error(e);
                Environment.Exit(1);
            }
            finally
            {
                MLog.Debug("Exiting ExtractPhotos()");
            }
        }

        //*********************************************************************
        //Class:        OberthurPhotoExtractCL
        //Function:     writeHeaderFile
        //Behavior:     Output the header file to be sent to Oberthur containing 
        //              the date and our company name.
        //*********************************************************************
        private bool WriteHeaderFile(string headerFileName)
        {
            MLog.Info("Entering writeHeaderFile()");
            try
            {
                MLog.Info("Writing text to file");
                string header = string.Format(Settings.Default.FileHeaderString,
                    DateTime.Today.ToShortDateString());
                File.WriteAllText(headerFileName, header);
                MLog.Info("Completed writing text to file");

                return true;
            }
            catch (Exception e)
            {
                MLog.Error(Settings.Default.Error_UnableToWriteHeaderFile);
                MLog.Error(e);
                return false;
            }
            finally
            {
                MLog.Debug("Exiting writeHeaderFile()");
            }
        }

        //*********************************************************************
        //Class:        OberthurPhotoExtractCL
        //Function:     writeTrailerFile
        //Behavior:     Output the trailer file to be sent to Oberthur containing 
        //              the total number of photo/signature pairs and the number of
        //              photos being sent without a signature.
        //*********************************************************************
        private bool WriteTrailerFile(string trailerFileName)
        {
            MLog.Info("Entering WriteTrailerFile()");
            try
            {
                MLog.Info("writing trailer file");
                string[] trailerFileContents = new string[2];
                trailerFileContents[0] = numPairs + " TOTAL Photo/Signature pairs in Transmission";
                trailerFileContents[1] = numPhotos + " TOTAL Photo files without a signature sent";
                File.WriteAllLines(trailerFileName, trailerFileContents);
                MLog.Info("Completed writing trailer file");
                return true;
            }
            catch (Exception e)
            {
                MLog.Error(Settings.Default.Error_UnableToWriteTrailerFile);
                MLog.Error(e);
                return false;
            }
            finally
            {
                MLog.Debug("Exiting WriteTrailerFile()");
            }
        }

        //*********************************************************************
        //Class:        OberthurPhotoExtractCL
        //Function:     getImages
        //Behavior:     Loops through all the entries in the ssnextract file for
        //              cardholders that have requested pulling photos, and the 
        //              previous day's hold file to check and see if the problem
        //              has been corrected.  The hold file is repopulated with
        //              any ssn values that are not found in the carddata table.
        //*********************************************************************
        private bool GetImages(string destDirectory, string ssnExtractFileName, string holdFileName)
        {
            try
            {
                MLog.Info("Entering GetImages(ref string found,ref string noRecord, ref string noPhoto, ref string badPath,ref string destDirectory, ref string ssnExtractFileName, ref string holdFileName)");

                MLog.Debug("Destination Directory: " + destDirectory);
                
                MLog.Debug("SSN Extract Filename: " + ssnExtractFileName);
                string[] ssnExtractLines;
                if (File.Exists(ssnExtractFileName))
                {
                    MLog.Debug("Reading lines from SSN extract file");
                    ssnExtractLines = File.ReadAllLines(ssnExtractFileName);
                    MLog.Debug("Destination Directory: " + destDirectory);
                }
                else
                {
                    MLog.Error("SSN Extract file did not exist.");
                    return true;  // technically not a failure
                }
                int numExtractLines = ssnExtractLines.Length;

                File.WriteAllText(holdFileName, "");
                StreamWriter matchesFileStream = File.AppendText(holdFileName);

                string failedToRead = "";
                string noPhoto = "";
                string badPathPhoto = "";
                string badPathSignature = "";
                string found = "";

                using (new Impersonator(Settings.Default.UserID,
                                        Settings.Default.Domain,
                                        Settings.Default.Password))
                {
                    string connectionString = Settings.Default.dbConnection;
                    SqlConnection oberthurConn = new SqlConnection(connectionString);
                    oberthurConn.Open();

                    bool creditCardFile = false;


                    //loop through the input lines, querying the carddata table for each ssn
                    for (int i = 0; i < numExtractLines; i++)
                    {
                        string aLine = ssnExtractLines[i];
                        aLine = aLine.TrimEnd('\r', '\n', ' ');
                        string[] lineParts = aLine.Split(' ');

                        if (lineParts.Length < 4)
                        {
                            MLog.Error("Invalid Line in File!  Info cannot be read for line: " + i);
                            continue;
                        }

                        // If the 3rd and 4th parts of the line are numbers, this is a credit card file and
                        // those parts are part of the file name.
                        if (i==0)
                        {
                            string creditCardFileName = lineParts[2] + lineParts[3];
                            //Are we dealing with a credit card file?
                            int tempNum;
                            if (int.TryParse(creditCardFileName, out tempNum) && (creditCardFileName.Length == 7))
                            {
                                creditCardFile = true;
                            }
                        }

                        string ssn = lineParts[0];
                        string cardNumber = lineParts[1];
                        string destFileName = cardNumber;
                        if (creditCardFile)
                        {
                            destFileName += lineParts[2] + lineParts[3];
                        }

                        MLog.Info("Extracting info for SSN: " + ssn);
                        MLog.Debug("Destination File Name: " + destFileName);
                        MLog.Debug("Credit Card File: " + creditCardFile);

                        // Call the sp Custom_OBERTHUR_SELECT
                        string spName = Settings.Default.SP_SELECT;
                        SqlCommand sqlCommand = new SqlCommand(spName, oberthurConn)
                        {
                            CommandType = CommandType.StoredProcedure
                        };
                        sqlCommand.Parameters.AddWithValue("@SSN", ssn);

                        SqlDataReader sqlResults = sqlCommand.ExecuteReader();

                        if (!sqlResults.Read())
                        {
                            MLog.Info("Unable to read from database: SSN: " + ssn);
                            MLog.Debug("Card Number: " + cardNumber);
                            failedToRead = GenerateLogMessage(failedToRead, lineParts);
                            sqlResults.Close();
                            continue;
                        }
                        
                        string photoFileName = sqlResults.GetValue(0).ToString();
                        string signatureFileName = sqlResults.GetValue(1).ToString();
                        sqlResults.Close();

                        if (String.IsNullOrEmpty(photoFileName))
                        {
                            MLog.Info("No Photo File Name: SSN: " + ssn);
                            MLog.Debug("Card Number: " + cardNumber);
                            noPhoto = GenerateLogMessage(noPhoto, lineParts);
                            sqlResults.Close();
                            continue;
                        }

                        photoFileName = Regex.Replace(photoFileName, @"[a-zA-Z]:\\", Settings.Default.webServer);
                        if (!String.IsNullOrEmpty(signatureFileName))
                        {
                            signatureFileName = Regex.Replace(signatureFileName, @"[a-zA-Z]:\\", Settings.Default.webServer);
                            if (File.Exists(photoFileName))
                            {
                                if (File.Exists(signatureFileName))
                                {
                                    numPairs++;
                                    File.Copy(photoFileName, destDirectory + "\\" + destFileName + ".jpg");
                                    File.Copy(signatureFileName, destDirectory + "\\" + destFileName + ".wmf");
                                    found = GenerateLogMessage(found, lineParts);
                                    matchesFileStream.WriteLine(aLine);
                                }
                                else
                                {
                                    //from when logged held instead of matches
                                    badPathSignature = GenerateLogMessage(badPathSignature, lineParts, signatureFileName);
                                }
                            }
                            else
                            {
                                //from when logged held instead of matches
                                badPathPhoto = GenerateLogMessage(badPathPhoto, lineParts, photoFileName);
                            }
                        }
                        else
                        {
                            if (File.Exists(photoFileName))
                            {
                                numPhotos++;
                                File.Copy(photoFileName, destDirectory + "\\" + destFileName + ".jpg");
                                found = GenerateLogMessage(found + Settings.Default.LogMessageNoSignature, lineParts);
                                matchesFileStream.WriteLine(aLine);
                            }
                            else
                            {
                                //from when logged held instead of matches
                                badPathPhoto = GenerateLogMessage(badPathPhoto, lineParts, photoFileName);
                            }
                        }

                        sqlResults.Close();

                    }
                    oberthurConn.Close();
                    matchesFileStream.Flush();
                    matchesFileStream.Close();
                }

                //log info
                string summaryLogMessage = Environment.NewLine + 
                    "Total:" + (numPairs + numPhotos) + Environment.NewLine + 
                    "Total Pairs (photo and signature): " + numPairs + Environment.NewLine +
                    "Total Photo only: " + numPhotos + Environment.NewLine +
                    "Records Found:" + found + Environment.NewLine +
                    "Failed To Read Record:" + failedToRead + Environment.NewLine +
                    "No Photo in Record:" + noPhoto + Environment.NewLine +
                    "Bad Path to Photo:" + badPathPhoto + Environment.NewLine +
                    "Bad Path to Signature:" + badPathSignature;

                MLog.Debug(summaryLogMessage);

                return true;
            }
            catch (Exception e)
            {
                MLog.Error(Settings.Default.Error_UnableToExtractImages);
                MLog.Error(e);
                return false;
            }
            finally
            {
                MLog.Debug("Exiting GetImages(ref string found,ref string noRecord, ref string noPhoto, ref string badPath,ref string destDirectory, ref string ssnExtractFileName, ref string holdFileName)");
            }
        }

        //*********************************************************************
        //Class:        OberthurPhotoExtractCL
        //Function:     GenerateLogMessage
        //Behavior:     Generate the error string for the log file.
        //*********************************************************************
        private string GenerateLogMessage(string message, string[] lineParts)
        {
            return GenerateLogMessage(message, lineParts, null);
        }

        private string GenerateLogMessage(string message, string[] lineParts, string errorMessage)
        {
            string messageStr = string.Format(Settings.Default.LogMessage, lineParts[0], lineParts[1]);

            for (int i = 2; i < lineParts.Length; i++)
            {
                messageStr += ", " + lineParts[i];
            }

            message += Environment.NewLine;
            message += messageStr;

            if (!string.IsNullOrEmpty(errorMessage))
            {
                message += ", ERROR: ";
                message += errorMessage;
            }

            return message;
        }

    }
}
