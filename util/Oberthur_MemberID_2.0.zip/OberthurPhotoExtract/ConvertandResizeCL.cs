using System;
using System.IO.Compression;
using System.IO;
using System.Linq;

namespace OberthurPhotoExtract
{
    public class ConvertandResizeCL
    {
        private static readonly string IrfanViewPath = Properties.Settings.Default.IrfanViewPath;
        private string errorMessage = "";

        //*********************************************************************
        //Class:        ConvertandResizeCL
        //Function:     GetErrorMessage
        //Behavior:     Return the most recent error message recorded.
        //*********************************************************************
        public string GetErrorMessage()
        {
            return errorMessage;
        }

        //*********************************************************************
        //Class:        ConvertandResizeCL
        //Function:     ResizeJpGs
        //Behavior:     Resize the jpg images using Irfanview to the size required
        //              by FDR, 194x218 pixels.
        //*********************************************************************
        public bool ResizeJpGs(string outDirectory)
        {
            try
            {
                bool returnCode = true;
                string[] jpgFiles = Directory.GetFiles(outDirectory, "*.jpg");
                if (jpgFiles.Length > 0)
                {
                    System.Diagnostics.Process resizeProc = new System.Diagnostics.Process
                    {
                        StartInfo =
                        {
                            FileName = IrfanViewPath,
                            Arguments =
                                "\"" + outDirectory + "*.jpg\" /resize=(240,240) /convert=\"" + outDirectory + "*.jpg\"",
                            UseShellExecute = true
                        }
                    };
                    resizeProc.Start();
                    resizeProc.WaitForExit();
                    int exitCode = resizeProc.ExitCode;
                    if (exitCode != 0)
                    {
                        returnCode = false;
                    }
                }
                return returnCode;
            }
            catch (Exception e)
            {
                errorMessage = e.ToString();
                return false;
            }
        }

        //*********************************************************************
        //Class:        ConvertandResizeCL
        //Function:     ConvertSigs
        //Behavior:     Convert the signature images from wmf to 1 bit pcx and
        //              resize them to the dimensions required by FDR 246x96 pixels.
        //*********************************************************************
        public bool ConvertSigs(string outDirectory)
        {
            try
            {
                bool returnCode = true;
                string[] wmfFiles = Directory.GetFiles(outDirectory, "*.wmf");
                if (wmfFiles.Length > 0)
                {
                    System.Diagnostics.Process resizeProc = new System.Diagnostics.Process
                    {
                        StartInfo =
                        {
                            FileName = IrfanViewPath,
                            Arguments =
                                "\"" + outDirectory + "*.wmf\" /bpp=1 /resize=(276,62) /convert=\"" + outDirectory +
                                "*.pcx\"",
                            UseShellExecute = true
                        }
                    };
                    resizeProc.Start();
                    resizeProc.WaitForExit();
                    int exitCode = resizeProc.ExitCode;
                    if (exitCode != 0)
                    {
                        returnCode = false;
                    }
                }
                return returnCode;
            }
            catch (Exception e)
            {
                errorMessage = e.ToString();
                return false;
            }
        }

        //*********************************************************************
        //Class:        ConvertandResizeCL
        //Function:     CreateZip
        //Behavior:     Remove the old zip if it exists, then create a new zip
        //              file with all the files with no extension and the data
        //              file.
        //*********************************************************************
        public bool CreateZip(string outDirectory)
        {
            string zipFileName = outDirectory + "\\" + Properties.Settings.Default.ZipFileName;
            try
            {
                if (File.Exists(zipFileName))
                {
                    File.Delete(zipFileName);
                }
                using (ZipArchive newFile = ZipFile.Open(zipFileName, ZipArchiveMode.Create))
                {
                    var filteredFiles = Directory
                        .EnumerateFiles(outDirectory)
                        .Where(file => file.ToLower().EndsWith("txt") ||
                                        file.ToLower().EndsWith("jpg") ||
                                        file.ToLower().EndsWith("pcx")).ToList();
                    foreach (string fileName in filteredFiles)
                    {
                        newFile.CreateEntryFromFile(fileName, Path.GetFileName(fileName));
                    }

                }
                return true;
            }
            catch (Exception e)
            {
                errorMessage = e.ToString();
                return false;
            }
        }


    }
}
