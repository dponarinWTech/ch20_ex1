using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Xml;
using System.Configuration;

namespace OberthurPhotoExtract
{
    public partial class OberthurPhotoExtract_InstallerForm : Form
    {
        string configFile;
        string connectionString;
        XmlDocument doc = new XmlDocument();

        public OberthurPhotoExtract_InstallerForm(string appConfig)
        {
            InitializeComponent();
            configFile = appConfig;
            connectionString = "";
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            SaveConfig();
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want cancel configuration settings?", "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void SaveConfig()
        {
            try
            {
                XmlNodeList list = doc.DocumentElement.GetElementsByTagName("add");
                foreach (XmlNode node in list)
                {

                    if (node.Attributes["name"] != null)
                    {
                        if (node.Attributes["name"].Value == "OberthurPhotoExtract.Properties.Settings.dbConnection")
                        {
                            string[] tokens = connectionString.Split(';');
                            tokens[0] = "Data Source=" + txtDBServer.Text;
                            StringBuilder connStringBuilder = new StringBuilder();
                            foreach (string aToken in tokens)
                            {
                                string currToken = aToken;
                                connStringBuilder.Append(currToken);
                                connStringBuilder.Append(";");
                            }
                            connectionString = connStringBuilder.ToString();

                            node.Attributes["connectionString"].Value = connectionString;
                        }
                        else if (node.Attributes["name"].Value == "OberthurPhotoExtract.Properties.Settings.Domain")
                        {
                            node.Attributes["connectionString"].Value = txtDomain.Text;
                        }
                        else if (node.Attributes["name"].Value == "OberthurPhotoExtract.Properties.Settings.UserID")
                        {
                            node.Attributes["connectionString"].Value = txtUsername.Text;
                        }
                        else if (node.Attributes["name"].Value == "OberthurPhotoExtract.Properties.Settings.Password")
                        {
                            node.Attributes["connectionString"].Value = txtPassword.Text;
                        }
                    }
                }
                list = doc.DocumentElement.GetElementsByTagName("setting");
                foreach (XmlNode node in list)
                {
                    if (node.Attributes["name"] != null)
                    {
                        switch (node.Attributes["name"].Value)
                        {
                            case "webServer":
                                node.FirstChild.InnerText = txtWebServer.Text;
                                break;
                            case "IrfanViewPath":
                                node.FirstChild.InnerText = txtIrfanView.Text;
                                break;
                        }
                    }
                }
                doc.Save(configFile);

            }
            catch (Exception exc)
            {
                MessageBox.Show("Exception caught while saving configuration.  Exception: " + exc.ToString());
            }
        }

        private void OberthurPhotoExtract_InstallerForm_Load(object sender, EventArgs e)
        {
            try
            {
                doc.Load(configFile);
                XmlNodeList list = doc.DocumentElement.GetElementsByTagName("add");
                foreach (XmlNode node in list)
                {
                    if (node.Attributes["name"] != null)
                    {
                        if (node.Attributes["name"].Value == "OberthurPhotoExtract.Properties.Settings.dbConnection")
                        {
                            connectionString = node.Attributes["connectionString"].Value;
                            string[] tokens = node.Attributes["connectionString"].Value.Split(';');
                            foreach (string str in tokens)
                            {
                                string[] s = str.Split('=');
                                switch (s[0])
                                {
                                    case "Data Source":
                                        txtDBServer.Text = s[1];
                                        break;
                                }
                            }
                        }
                        else if (node.Attributes["name"].Value == "OberthurPhotoExtract.Properties.Settings.Domain")
                        {
                            txtDomain.Text = node.Attributes["connectionString"].Value;
                        }
                        else if (node.Attributes["name"].Value == "OberthurPhotoExtract.Properties.Settings.UserID")
                        {
                            txtUsername.Text = node.Attributes["connectionString"].Value;
                        }
                    }
                }
                list = doc.DocumentElement.GetElementsByTagName("setting");
                foreach (XmlNode node in list)
                {
                    if (node.Attributes["name"] != null)
                    {
                        switch (node.Attributes["name"].Value)
                        {
                            case "webServer":
                                txtWebServer.Text = node.FirstChild.InnerText;
                                break;
                            case "IrfanViewPath":
                                txtIrfanView.Text = node.FirstChild.InnerText;
                                break;
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show("Exception caught while loading form.  Exception: " + exc.ToString());
            }
        }
    }
}