using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;

namespace OberthurPhotoExtract
{
    [RunInstaller(true)]
    public partial class OberthurPhotoExtract_Installer : Installer
    {
        public OberthurPhotoExtract_Installer()
        {
            InitializeComponent();
        }

        private void OberthurPhotoExtract_AfterInstall(object sender, InstallEventArgs e)
        {
            string assemblypath = Context.Parameters["assemblypath"];
            string appConfigPath = assemblypath + ".config";

            OberthurPhotoExtract_InstallerForm installForm = new OberthurPhotoExtract_InstallerForm(appConfigPath);
            installForm.ShowDialog();
        }
    }
}