01/08/2016

For the Member ID 2.0 upgrade, much of the code for creating user roles, permissions, users, etc. has been centralized.  If you are looking for a particular sql script, please reference the files in:

svn/ImageTeam/MemberID/MemberIDInterfaceWS/trunk/MemberIDInterfaceWS/SQL/sql
