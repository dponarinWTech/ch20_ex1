USE MEMBERID
GO

IF EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND name = 'Custom_OBERTHUR_SELECT')
DROP PROCEDURE Custom_OBERTHUR_SELECT
GO

CREATE PROCEDURE [dbo].Custom_OBERTHUR_SELECT
(
	@SSN char(9)
)
AS
BEGIN

	SELECT 
		mi.PHOTO,
		mi.SIGNATURE
	FROM MemberInformation mi
		where mi.SSN = @SSN

END
go
/* END Custom_OBERTHUR_SELECT */
