using System;
using System.Configuration;
using log4net;
using System.Security.Principal;

namespace SECU
{
    /// <summary>
    /// Logs the application using log4net
    /// </summary>
    public class Logger
    {
        private readonly ILog _mLog;

        /// <summary>
        /// Constructor for the logger
        /// </summary>
        /// <param name="callingType">The declaring class</param>
        public Logger(String callingType)
        {
            try
            {
                if (log4net.LogManager.GetRepository().Configured)
                {
                    _mLog = LogManager.GetLogger(callingType);
                }
                else
                {
                    String key = ConfigurationManager.AppSettings["typeOfSystem"] as String;
                    System.IO.FileInfo configFileInfo = new System.IO.FileInfo(ConfigurationManager.AppSettings["Log4net_Config_File"]);

                    if ((!String.IsNullOrEmpty(key)) && (key.Equals("Web", StringComparison.OrdinalIgnoreCase)))
                    {
                        configFileInfo = new System.IO.FileInfo(System.Web.HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["Log4net_Config_File"]));
                    }

                    if (configFileInfo.Exists)
                    {
                        if (!log4net.LogManager.GetRepository().Configured)
                        {
                            log4net.Config.XmlConfigurator.Configure(new System.IO.FileInfo(configFileInfo.FullName));
                        }
                    }
                    else
                    {
                        LogToEventLog("Application could not find log 4 net config file", System.Diagnostics.EventLogEntryType.Error);
                    }
                    _mLog = LogManager.GetLogger(callingType);
                }
            }
            catch (NullReferenceException e)
            {
                LogToEventLog(e.ToString(), System.Diagnostics.EventLogEntryType.Error);
            }
            catch (Exception ex)
            {
                LogToEventLog(ex.ToString(), System.Diagnostics.EventLogEntryType.Error);
            }
        }
        /// <summary>
        /// Logs messages to system event log if it cannot create its own system log
        /// </summary>
        /// <param name="message">Message to log in the system.</param>
        public static void LogToEventLog(String message, System.Diagnostics.EventLogEntryType type)
        {
            if (new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))
            {
                if (!System.Diagnostics.EventLog.SourceExists("SECU_Word_Capture_Solution"))
                {
                    System.Diagnostics.EventLog.CreateEventSource(new System.Diagnostics.EventSourceCreationData("SECU_Word_Capture_Solution", "WordCaptureAddin"));
                }
            }
            try
            {
                System.Diagnostics.EventLog.WriteEntry("SECU_Word_Capture_Solution", message, type);
            }
            catch (Exception)
            {

            }
        }
        /// <summary>
        /// Logs the message based on the itsAllGood type
        /// Eliminates the need to check if the logger is enabled or not
        /// </summary>
        /// <param name="message">Message to be logged</param>
        /// <param name="errortype">Type of message being logged:
        /// I = info, D = Debug, E = Error, F = Fatal, W = Warn.
        /// </param>
        public void LogMessage(object message, String errortype)
        {
            if (_mLog == null)
            {
                LogToEventLog("Log is null. Make sure log is not null before logging", System.Diagnostics.EventLogEntryType.Information);
                return;
            }
            switch (errortype)
            {
                case "I":
                    if (_mLog.IsInfoEnabled)
                    {
                        _mLog.Info(message);
                    }
                    break;
                case "D":
                    if (_mLog.IsDebugEnabled)
                    {
                        _mLog.Debug(message);
                    }
                    break;
                case "E":
                    if (_mLog.IsErrorEnabled)
                    {
                        _mLog.Error(message);
                    }
                    break;
                case "F":
                    if (_mLog.IsFatalEnabled)
                    {
                        _mLog.Fatal(message);
                    }
                    break;
                case "W":
                    if (_mLog.IsWarnEnabled)
                    {
                        _mLog.Warn(message);
                    }
                    break;
            }

        }
        /// <summary>
        /// Logs the message based on the itsAllGood type
        /// Eliminates the need to check if the logger is enabled or not
        /// </summary>
        /// <param Name="message">Message to be logged</param>
        /// <param Name="errortype">Type of message being logged:
        /// I = info, D = Debug, E = Error, F = Fatal, W = Warn.
        /// </param>
        public void Log_message(object message, MessageType messagetype)
        {
            if (_mLog == null)
            {
                LogToEventLog("Log is null. Make sure log is not null before logging", System.Diagnostics.EventLogEntryType.Error);
                return;
            }
            switch (messagetype)
            {
                case MessageType.Informational:
                    if (_mLog.IsInfoEnabled)
                    {
                        _mLog.Info(message);
                    }
                    break;
                case MessageType.Debug:
                    if (_mLog.IsDebugEnabled)
                    {
                        _mLog.Debug(message);
                    }
                    break;
                case MessageType.Error:
                    if (_mLog.IsErrorEnabled)
                    {
                        _mLog.Error(message);
                    }
                    break;
                case MessageType.Fatal:
                    if (_mLog.IsFatalEnabled)
                    {
                        _mLog.Fatal(message);
                    }
                    break;
                case MessageType.Warning:
                case MessageType.Notice:
                    if (_mLog.IsWarnEnabled)
                    {
                        _mLog.Warn(message);
                    }

                    break;
            }
        }
        public enum MessageType
        {
            Emergency,
            Alert,
            Critical,
            Error,
            Warning,
            Notice,
            Informational,
            Debug,
            Fatal
        }
        /// <summary>
        /// Logs the message based on the itsAllGood type
        /// Eliminates the need to check if the logger is enabled or not
        /// </summary>
        /// <param Name="message">Message to be logged</param>
        /// <param Name="errortype">Type of message being logged:
        /// I = info, D = Debug, E = Error, F = Fatal, W = Warn.
        /// </param>
        public void Log_message(object message, Exception e)
        {
            if (_mLog == null)
            {
                LogToEventLog("Log is null. Make sure log is not null before logging", System.Diagnostics.EventLogEntryType.Error);
                return;
            }
            if (_mLog.IsErrorEnabled)
            {
                _mLog.Error(message, e);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        public log4net.ILog Log
        {
            get { return _mLog; }
        }
    }
}