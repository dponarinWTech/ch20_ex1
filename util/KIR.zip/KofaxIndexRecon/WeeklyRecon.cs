﻿using System;
using System.Linq;
using System.Text;
using log4net;
using log4net.Config;
using System.Reflection;
using System.Data.SqlClient;
using System.Data;
using System.IO;

namespace KofaxIndexRecon
{
    public class WeeklyRecon
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(WeeklyRecon));
        private SqlConnection kofaxConnection;

        static void LoggerSetup()
        {
            // Configures the Logger to use the App.config file entry for Log4NET logger
            XmlConfigurator.Configure();
        }

        /// <summary>
        /// Public function that runs weekly reconciliation process
        /// </summary>
        public void StartRecon()
        {
            LoggerSetup();

            if (!InitialSetup()) return; 

            if (!BranchScanReport())
            {
                if (kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
                log.Error("\t BranchScanReport(): - Failed to execute 'KfxIndxRcon_WklyBranchScan' stored procedure.");
                NightlyRecon.SendEmailMessage("BranchScanReport(): Error - Failed to call and execute 'KfxIndxRcon_WklyBranchScan'" +
                    " stored procedure which updates BranchScanReport table during weekly process.");
                return;
            }

            if (!MargoFormErrorReport())
            {
                if (kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
                log.Error("\t Failed to process MargoFormErrorReport().");
                NightlyRecon.SendEmailMessage("MargoFormErrorReport(): Error - Failed to execute 'KfxIndxRcon_WklyRpt_MargoFormError' " +
                    "stored procedure which updates MargoFormErrorReport table during weekly process.");
                return;
            }

            log.Info("\t Starting to Create reports for 'FOUND','MISSING' and 'PARTIAL' records");

            DataSet fetchedTables = LoadDBTablesToDataSet();
            if (fetchedTables == null)
            {
                log.Error("\t Failed to process LoadDBTablesToDataSet() on weekly process.");
                NightlyRecon.SendEmailMessage("The process has failed to fetch data from FormInfo table into the" +
                    " dataset or there is no data in FormInfo table to process during weekly processing.");
                return;
            }

            if (!CreateReports(fetchedTables))
            {
                log.Error("\t Failed to process CreateReports() on weekly process.");
                NightlyRecon.SendEmailMessage("An error has occurred: The process has failed to create reports during weekly processing.");
                return;
            }

            if (!DeleteOldCompleteRecords())
            {
                log.Error("\t Failed to delete old records with status COMPLETE from table 'FormInfo'.");
                NightlyRecon.SendEmailMessage("Error in WeeklyRecon: Failed to delete old records with status COMPLETE from table 'FormInfo'.");
                return;
            }

            if (!UpdateFoundRows())
            {
                if (kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
                log.Error("\t Failure in UpdateFoundRows() - Changing status from 'FOUND' to 'COMPLETE'");
                NightlyRecon.SendEmailMessage("Error in WeeklyRecon: Failed to Update records with status 'FOUND' to 'COMPLETE'.");
                return;
            }

            // Close the Kofax_FormInfo DB Connection
            if (kofaxConnection != null && kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
            log.Debug("\t The connection to the Kofax FormInfo Database has been closed.");

            Console.WriteLine("Weekly Recon Complete...\n");
            log.Info("\t Weekly Reconciliation Completed at: " + DateTime.Now.ToString());
            log.Info("StartRecon(): End");
        }


        /// <summary>
        /// Establishes and opens connection with Kofax DB
        /// </summary>
        /// <returns></returns>
        private bool InitialSetup()
        {
            Console.WriteLine("Starting Weekly Recon...\n");
            log.Info("================================================== Weekly Recon ==================================================");
            log.Info("Current thread is running under credentials: " + System.Security.Principal.WindowsIdentity.GetCurrent().Name);
            log.Info($"Import folder for Branch Scanning Report: '{Properties.Settings.Default.BranchScanningReportFolder}'");
            log.Info($"Import folder for Partial Report: '{Properties.Settings.Default.PartialReportFolder}'");
            log.Info($"Number of lines per page: '{Properties.Settings.Default.NumberOfLinesPerPageInReport}'");
            log.Info("StartRecon(): Start");
            //log.Info("\t Weekly Reconciliation Started at: " + DateTime.Now.ToString());

            if (!OpenKofaxConnection())
            {
                log.Error("\t Kofax Database connection failed to open");
                NightlyRecon.SendEmailMessage("Error - Failed to open Kofax_FormInfo Database connection");
                return false;
            }
            return true;
        }

        /// <summary>
        /// Executes SP 'KfxIndxRcon_WklyBranchScan' that populates DB table 'BranchScanReport' with Found/Missing 
        /// records from table 'FormInfo'.
        /// </summary>
        /// <returns>True if stored procedure completed successfully</returns>
        private bool BranchScanReport()
        {
            try
            {
                log.Info("BranchScanReport(): Start");
                using (SqlCommand sqlCommand = kofaxConnection.CreateCommand())
                {
                    sqlCommand.CommandText = "dbo.KfxIndxRcon_WklyBranchScan";
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;

                    SqlParameter dayDiff = sqlCommand.Parameters.AddWithValue("@DayDifference", Properties.Settings.Default.NumDaysBeforeEmptyStatusScanned);
                    dayDiff.Direction = ParameterDirection.Input;
                    dayDiff.SqlDbType = SqlDbType.Int;

                    SqlParameter retFoundCount = sqlCommand.Parameters.AddWithValue("@ReturnFoundRows", 0);
                    retFoundCount.Direction = ParameterDirection.Output;
                    retFoundCount.SqlDbType = SqlDbType.Int;

                    SqlParameter retMissingCount = sqlCommand.Parameters.AddWithValue("@ReturnMissingRows", 0);
                    retMissingCount.Direction = ParameterDirection.Output;
                    retMissingCount.SqlDbType = SqlDbType.Int;

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;
                    sqlCommand.ExecuteNonQuery();

                    int missingRows = (int)(sqlCommand.Parameters["@ReturnMissingRows"].Value);
                    int foundRows = (int)(sqlCommand.Parameters["@ReturnFoundRows"].Value);

                    if ((bool)retVal.Value)
                    {
                        int affectedRows = (int)retFoundCount.Value;
                        log.Info($"\t Successfully inserted {affectedRows} rows into table BranchScanReport. There are {missingRows} Missing rows and {foundRows} Found rows inserted.");
                        return true;
                    }
                    else
                    {
                        log.Error("Failed to populate table BranchScanReport");
                        return false;
                    }
                }
            }
            catch (SqlException s)
            {
                log.Error("BranchScanReport - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.Error("BranchScanReport - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.Error("BranchScanReport - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log.Info("BranchScanReport(): End");
            }
        }

        /// <summary>
        /// Executes SP 'KfxIndxRcon_WklyRpt_MargoFormError' that populates table 'MargoFormErrorReport' with records
        /// with status PARTIAL from table 'FormInfo'.
        /// </summary>
        /// <returns>True if stored procedure completed successfully</returns>
        private bool MargoFormErrorReport()
        {
            try
            {
                log.Info("MargoFormErrorReport(): Start");
                using (SqlCommand sqlCommand = kofaxConnection.CreateCommand())
                {
                    sqlCommand.CommandText = "dbo.KfxIndxRcon_WklyRpt_MargoFormError";
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;

                    SqlParameter retPartialCount = sqlCommand.Parameters.AddWithValue("@ReturnRowCounts", 0);
                    retPartialCount.Direction = ParameterDirection.Output;
                    retPartialCount.SqlDbType = SqlDbType.Int;

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;
                    sqlCommand.ExecuteNonQuery();

                    int PartialRows = (int)(sqlCommand.Parameters["@ReturnRowCounts"].Value);

                    if ((bool)retVal.Value)
                    {
                        int affectedRows = (int)retPartialCount.Value;
                        log.Info($"\t Successfully inserted {affectedRows} row(s) with status 'PARTIAL' into dbo.[MargoFormErrorReport] table");
                        return true;
                    }
                    else
                    {
                        log.Error("\t Failed to insert records with status 'PARTIAL' into dbo.[MargoFormErrorReport table]");
                        return false;
                    }
                }
            }
            catch (SqlException s)
            {
                log.Error("\t MargoFormErrorReport - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.Error("\t MargoFormErrorReport - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.Error("\t MargoFormErrorReport - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log.Info("MargoFormErrorReport(): End");
            }
        }


        /// <summary>
        /// Loads data from DB tables 'BranchScanReport' (Found/Missing records) and 'MargoFormErrorReport' (Partial 
        /// records) into DataSet.
        /// </summary>
        /// <returns>DataSet with tables 'BranchScanReport' and 'MargoFormErrorReport' if loaded data successfully,
        /// null otherwise.</returns>
        private DataSet LoadDBTablesToDataSet()
        {
            string fetchQuery = "SELECT * FROM [dbo].BranchScanReport; " +
                                "SELECT* FROM [dbo].MargoFormErrorReport";

            log.Info("LoadDBTablesToDataSet: Start");
            log.Info("\t SQL-queries to fetch data from Kofax_FormInfo Database: \n\t\t\t\t\t\t\t\t " + fetchQuery);

            try
            {
                using (SqlDataAdapter Report_Adapter = new SqlDataAdapter(fetchQuery, kofaxConnection))
                {
                    DataSet reportDataSet = new DataSet();

                    Report_Adapter.SelectCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;
                    Report_Adapter.FillSchema(reportDataSet, SchemaType.Source);
                    Report_Adapter.Fill(reportDataSet);

                    reportDataSet.Tables[0].TableName = "BranchScanReport";
                    reportDataSet.Tables[1].TableName = "MargoFormErrorReport";

                    log.Info("\t BranchScanReport datatable has: " + reportDataSet.Tables[0].Rows.Count + " row(s)");
                    log.Info("\t MargoFormErrorReport datatable has: " + reportDataSet.Tables[1].Rows.Count + " row(s)");
                    log.Debug("\t LoadDBTablesToDataSet from [Kofax_FormInfo] has been completed successfully.");

                    return reportDataSet;
                } // End using

            } // End try

            catch (SqlException s)
            {
                log.Error("\t LoadDBTablesToDataSet - SQL Exception: " + s.ToString());
                return null;
            }
            catch (TimeoutException t)
            {
                log.Error("\t LoadDBTablesToDataSet - Timeout Exception: " + t.ToString());
                return null;
            }
            catch (Exception e)
            {
                log.Error("\t LoadDBTablesToDataSet - Exception: " + e.ToString());
                return null;
            }
            finally
            {
                // Close Kofax connection as we wouldn't need it any more
                if (kofaxConnection.State == ConnectionState.Open)
                {
                    kofaxConnection.Close();
                }
                log.Info("LoadDBTablesToDataSet(): End");
            }

        } // End LoadDBTablesToDataSet()

        /// <summary>
        /// Deletes records with status COMPLETE which are more than 93 days old from table 'FormInfo'.
        /// </summary>
        /// <returns></returns>
        private bool DeleteOldCompleteRecords()
        {
            log.Info("DeleteOldCompleteRecords(): Start");
            int rowsDeleted;
            try
            {
                using (SqlCommand sqlCommand = kofaxConnection.CreateCommand())
                {
                    if(kofaxConnection != null && kofaxConnection.State != ConnectionState.Open) { kofaxConnection.Open(); }

                    string SQLQuery = "DELETE FROM  dbo.FormInfo" +
                               " WHERE Status = 'COMPLETE' AND DATEDIFF(DAY, UpdateDate, GETDATE()) > "
                               + Properties.Settings.Default.NumDaysTillPurge;

                    sqlCommand.CommandText = SQLQuery;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;
                    sqlCommand.CommandType = CommandType.Text;
                    rowsDeleted = sqlCommand.ExecuteNonQuery();
                }
                log.Info($"\t DeleteOldCompleteRecords(): Deleted {rowsDeleted} forms with status 'COMPLETE' that are more than " + 
                    Properties.Settings.Default.NumDaysTillPurge + " days old from table 'FormInfo'.");
                return true;
            }
            catch (SqlException s)
            {
                log.Error("\t SQL Exception in DeleteOldCompleteRecords(): " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.Error("\t Timeout Exception in DeleteOldCompleteRecords(): " + t.ToString());
                return false;

            }
            catch (Exception e)
            {
                log.Error("\t Exception in DeleteOldCompleteRecords(): " + e.ToString());
                return false;
            }
            finally
            {
                log.Info("DeleteOldCompleteRecords(): End");
            }
        }

        /// <summary>
        /// Update the status from "FOUND" to "COMPLETE" in table 'FormInfo' after FOUND report is processed
        /// </summary>
        /// <returns></returns>
        private bool UpdateFoundRows()
        {
            log.Info("UpdateFoundRows(): Start");
            int rowsUpdated;

            try
            {
                using (SqlCommand sqlCommand = kofaxConnection.CreateCommand())
                {
                    if (kofaxConnection != null && kofaxConnection.State != ConnectionState.Open) { kofaxConnection.Open(); }

                    string SQLQuery = "UPDATE dbo.FormInfo" +
                               " SET Status = 'COMPLETE', UpdateDate = GETDATE(), UpdateBy = 'SYSTEM-W'"+
                               " WHERE Status = 'FOUND'";
                    sqlCommand.CommandText = SQLQuery;
                    sqlCommand.CommandType = CommandType.Text;
                    rowsUpdated = sqlCommand.ExecuteNonQuery();                    
                }
                log.Info($"\t UpdateFoundRows(): Updated status from FOUND to COMPLETE in {rowsUpdated} forms in the table 'FormInfo'.");
                return true;
            }
            catch (SqlException s)
            {
                log.Error("\t SQL Exception in UpdateFoundRows(): " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.Error("\t Timeout Exception in UpdateFoundRows(): " + t.ToString());
                return false;

            }
            catch (Exception e)
            {
                log.Error("\t Exception in UpdateFoundRows(): " + e.ToString());
                return false;
            }
            finally
            {
                log.Info("UpdateFoundRows(): End");
            }
        }

        /// <summary>
        /// Returns StringBuilderWithLineCount with Found and Missing reports for all branches in the given DataSet (in table 'BranchScanReport').
        /// </summary>
        /// <param name="dataSet"></param>
        /// <returns></returns>
        public StringBuilderWithLineCount CreateFoundMissingReport(DataSet dataSet)
        {
            try
            {
                StringBuilderWithLineCount scanningReport = new StringBuilderWithLineCount();

                var branchList = dataSet.Tables["BranchScanReport"].AsEnumerable()
                    .Select(row => (string)row["BranchNum"]).Distinct().OrderBy(s => s);

                foreach (string branch in branchList)
                {
                    BranchReport branchReport = new BranchReport(dataSet, branch, log);
                    scanningReport.Append(branchReport.GetBranchReport(scanningReport.LineCount == 0));
                }

                // At the end of very last page of report last line should end with [CR][LF][FF], not [FF][CR][LF] like all other last lines on a page (bug 47847)
                scanningReport.ReplaceLastOccurrence( Report.FORM_FEED + Environment.NewLine, Environment.NewLine + Report.FORM_FEED);

                return scanningReport;
            }
            catch (Exception e)
            {
                log.Error($"Exception in {GetCurrentMethodName()}() - " + e.ToString());
                throw;
            }
        }


        /// <summary>
        /// Returns StringBuilderWithLineCount with Partial report with data from the given DataSet (table 'MargoFormErrorReport').
        /// </summary>
        /// <param name="dataSet"></param>
        /// <returns></returns>
        public StringBuilderWithLineCount CreatePartialReport(DataSet dataSet)
        {
            try
            {
                PartialReport partialReport = new PartialReport(dataSet);

                return partialReport.GetPartialReport();

            }
            catch (Exception e)
            {
                throw new Exception($"Exception in {GetCurrentMethodName()}() - " + e.ToString());
            }
        }

        /// <summary>
        /// Writes Found/Missing report (provided in StringBuilderWithLineCount '<paramref name="scanningReport"/>') to file 
        /// with name and location specified in the configuration.
        /// </summary>
        /// <param name="scanningReport"></param>
        private void WriteToFileFoundMissingReport(StringBuilderWithLineCount scanningReport)
        {
            // do not create report file if there is no data
            if (String.IsNullOrWhiteSpace(scanningReport.ToString()))
            {
                log.Warn("Branch Scanning report was not generated because of no data.");
                return;
            }

            string branchReportFileName = Path.Combine(Properties.Settings.Default.BranchScanningReportFolder, 
                Properties.Settings.Default.BranchScanningReportFilename);

            using (TextWriter textWriterScanningReport = new StreamWriter(branchReportFileName))
            {
                textWriterScanningReport.Write( scanningReport.ToString() );
            }
        }

        /// <summary>
        /// Writes Partial report (provided in StringBuilderWithLineCount '<paramref name="partialReport"/>') to file
        /// with name and location specified in the configuration. Returns false if there is no data, true otherwise.
        /// </summary>
        /// <param name="partialReport"></param>
        /// <returns>False if there is no data for Partial report, True otherwise</returns>
        private bool WriteToFilePartialReport(StringBuilderWithLineCount partialReport)
        {
            // do not create report file if there is no data
            if (String.IsNullOrWhiteSpace(partialReport.ToString()))
            {
                log.Warn("  Partial report was not generated because of no data.");
                return false;
            }

            string partialReportFileName = Path.Combine(Properties.Settings.Default.PartialReportFolder, 
                Properties.Settings.Default.PartialReportFilename);

            using (TextWriter textWriterPartialReport = new StreamWriter(partialReportFileName))
            {
                textWriterPartialReport.Write(partialReport.ToString() );
            }

            return true;
        }

        private void LogCumulativeNumberOfRows(DataSet dataSet, ReportType reportType)
        {
            switch (reportType)
            {
                case ReportType.Found:
                    log.Info("\t\t Cumulative number of Found rows = " + dataSet.Tables["BranchScanReport"].Select("Status = 'FOUND'").Length);
                    break;
                case ReportType.Missing:
                    log.Info("\t\t Cumulative number of Missing rows = " + dataSet.Tables["BranchScanReport"].Select("Status = 'MISSING'").Length);
                    break;
                case ReportType.Partial:
                    log.Info("\t\t Cumulative number of Partial rows = " + dataSet.Tables["MargoFormErrorReport"].Select(null, "UniqueID ASC").Length);
                    break;
            }
        }

        private bool VerifyDataSet(DataSet dataSet)
        {
            if (dataSet == null)
            {
                log.Error($"{GetCurrentMethodName()}(): DataSet argument is null.");
                return false;
            }
            else if (dataSet.Tables["BranchScanReport"] == null)
            {
                log.Error($"{GetCurrentMethodName()}(): DataSet argument does not have table 'BranchScanReport'.");
                return false;
            }
            else if(dataSet.Tables["MargoFormErrorReport"] == null)
            {
                log.Error($"{GetCurrentMethodName()}(): DataSet argument does not have table 'MargoFormErrorReport'.");
                return false;
            }
            return true;
        }

        private bool CreateReports(DataSet dataSet)
        {
            log.Info("CreateReports(): Start");

            if (!VerifyDataSet(dataSet)) return false;

            try
            {
                //-------------------- FOUND/MISSING REPORT ------------------------------------// 
                LogCumulativeNumberOfRows(dataSet, ReportType.Found);
                LogCumulativeNumberOfRows(dataSet, ReportType.Missing);
                log.Info("\t=====================================");

                StringBuilderWithLineCount scanningReport = CreateFoundMissingReport(dataSet);
                WriteToFileFoundMissingReport(scanningReport);

                log.Info("\t FOUND/MISSING Reports have been created.");

                //-------------------- PARTIAL REPORT ------------------------------------//
                log.Info("\t=====================================");
                LogCumulativeNumberOfRows(dataSet, ReportType.Partial);

                StringBuilderWithLineCount partialReport = CreatePartialReport(dataSet);
                if (WriteToFilePartialReport(partialReport))
                {
                    log.Info("\t PARTIAL Report has been created.");
                }

                return true;

            }
            catch (Exception e)
            {
                log.Error("CreateReports Error: " + e.ToString());
                return false;
            }
            finally
            {
                log.Info("CreateReports() End.");
            }
        }
  
        private bool OpenKofaxConnection()
        {
            try
            {
                SqlHelper sqlHelper = new SqlHelper(log, NightlyRecon.spacer);
                kofaxConnection = sqlHelper.SetupConnection(DBSelector.Kofax, Properties.Settings.Default.kofaxConnString);

                if (kofaxConnection == null)
                {
                    log.Error("\t Failed to open Kofax_FormInfo Db connection");
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch (SqlException s)
            {
                log.Error("\t OpenConnections - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.Error("\t OpenConnections - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.Error("\t OpenConnections - Exception: " + e.ToString());
                return false;
            }
        }

        /// <summary>
        /// Returns name of the current method
        /// </summary>
        /// <returns></returns>
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        public string GetCurrentMethodName()
        {
            var stackTrace = new System.Diagnostics.StackTrace();
            var stackFrame = stackTrace.GetFrame(1);

            return stackFrame.GetMethod().Name;
        }
    }  // end class WeeklyRecon


    public enum ReportType { Found, Missing, Partial };

}
