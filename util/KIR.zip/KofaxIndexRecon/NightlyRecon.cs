﻿using System;
using System.Collections.Generic;
using System.Linq;
using log4net;
using log4net.Config;
using System.Reflection;
using System.Data;
using System.Data.SqlClient;

namespace KofaxIndexRecon
{
    public enum DBSelector { Tower, Kofax };

    public class NightlyRecon
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(NightlyRecon));
        internal static string spacer;

        internal SqlConnection towerConnection;
        internal SqlConnection kofaxConnection;

        //public ILog GetLogger() { return log; }

        public void StartRecon()
        {
            if (!InitialSetup()) return;

            if (!Populate_FormIDs_To_Process())
            {
                if (kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
                SendEmailMessage("Failed to populate table FormIDs_To_Process");
                return;
            }
            if (!ExecSP("dbo.KfxIndxRcon_UpdtRecNotScanned", "FormInfo"))
            {
                if (kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
                SendEmailMessage("Failed to update not scanned records in the table FormInfo");
                return;
            }

            List<String> uidList = GetUniqueIDList();
            if (uidList == null)
            {
                if (kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
                SendEmailMessage("Failed to retrieve the list of UniqueID");
                return;
            }

            DataSet dSet = FetchFromIDM(uidList);
            if (dSet == null)
            {
                SendEmailMessage("Failed to retrieve records from TowerDB");
                return;
            }
            // Close TowerDB connection as we wouldn't need it any more
            if (towerConnection != null && towerConnection.State == ConnectionState.Open) { towerConnection.Close(); }

            if (!BulkCopyDataSetToKofaxTable(dSet, "Tower_MemdocRecords"))
            {
                if (kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
                SendEmailMessage("Failed to BulkCopy from DataSet to table [Kofax_FormInfo].[dbo].[Tower_MemdocRecords]");
                return;
            }

            if (!ExecSP("dbo.KfxIndxRcon_UpdtRecScannedButMissingInTower", "FormIDs_To_Process"))
            {
                if (kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
                SendEmailMessage("Failed to update status of Kofax records without matching UID in Tower");
                return;
            }

            // Adds table 'FormIDs_To_Process' to existing DataSet
            dSet = AddTableToDataSet(dSet); 
            if (dSet == null)
            {
                SendEmailMessage("Failed to add records from FormIDs_To_Process to DataSet");
                return;
            }

            if( !AssignStatuses(dSet, uidList))
            {
                SendEmailMessage("Failed to update statuses in DataSet");
                return;
            }

            if (!UpdateKofaxTableFromDataSet(dSet, "FormIDs_To_Process"))
            {
                SendEmailMessage("Failed to update DB table FormIDs_To_Process from DataSet");
                return;
            }

            if (!ExecSP("dbo.KfxIndxRcon_UpdateFormInfoTable", "FormInfo"))
            {
                if (kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
                SendEmailMessage("Failed to copy Status and Reason values from temp table 'FormIDs_To_Process' to permanent table 'FormInfo'.");
                return;
            }

            if (kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
            Console.WriteLine("Nightly Recon Completed.\n");
            log.Info("Nightly Recon has completed at: " + DateTime.Now.ToString());
        }

        /// <summary>
        /// Establishes and opens DB connections and truncates tables 'FormIDs_To_Process' and 'Tower_MemdocRecords'
        /// </summary>
        /// <returns></returns>
        protected bool InitialSetup()
        {
            Console.WriteLine("Starting Nightly Recon ...\n");
            log.Info("========================================================================================");
            log.Info("Current thread is running under credentials: " + System.Security.Principal.WindowsIdentity.GetCurrent().Name);
            log.Info("Kofax Index Nightly Recon (version " + Assembly.GetExecutingAssembly().GetName().Version + ")");
            log.Info("Starting Nightly Recon for the following date: " + DateTime.Today.ToShortDateString() + ", at: " + DateTime.Now.ToString());
            spacer = "    ";
            if (!OpenConnections(Properties.Settings.Default.kofaxConnString, Properties.Settings.Default.towerConnString))
            {
                log.Error("Failed to open DB connection");
                SendEmailMessage("Failed to open DB connection");
                return false;
            }
            if (!TruncateTables())
            {
                if (kofaxConnection.State == ConnectionState.Open) { kofaxConnection.Close(); }
                SendEmailMessage("Failed to truncate tables FormIDs_To_Process and Tower_MemdocRecords");
                return false;
            }
            return true;
        }

        // ======================================================================================================
        // Establishes database connections with both databases Kofax_FormInfo and TowerDB.
        // After execution leaves connections open.
        // ======================================================================================================
        protected bool OpenConnections(string kofaxConnString, string towerConnString)
        {
            try
            {
                SqlHelper sqlHelper = new SqlHelper(log, spacer);
                kofaxConnection = sqlHelper.SetupConnection(DBSelector.Kofax, kofaxConnString);
                towerConnection = sqlHelper.SetupConnection(DBSelector.Tower, towerConnString);

                if (kofaxConnection == null || kofaxConnection.State == ConnectionState.Closed ||
                    towerConnection == null || towerConnection.State == ConnectionState.Closed)
                {
                    log.Error("Failed to open Db connection");
                    return false;
                }
                else { return true; }
            }
            catch (SqlException s)
            {
                log.Error("OpenConnections - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.Error("OpenConnections - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.Error("OpenConnections - Exception: " + e.ToString());
                return false;
            }
        }

        // ======================================================================================================
        // Calling and Executing stored procedure 'KfxIndxRcon_TruncateTables'.
        // It truncates tables "FormIDs_To_Process" and "Tower_MemdocRecords"
        // ======================================================================================================
        protected bool TruncateTables()
        {
            try
            {
                log.Info(spacer + "TruncateTables(): Start");
                using (SqlCommand sqlCommand = kofaxConnection.CreateCommand())
                {
                    sqlCommand.CommandText = "dbo.KfxIndxRcon_TruncateTables";
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    sqlCommand.ExecuteNonQuery();

                    if( (bool)retVal.Value)
                    {
                        log.Info(spacer + "    " + "Successfully truncated tables FormIDs_To_Process and Tower_MemdocRecords");
                        return true;   // leave connection kofaxConnection open
                    }
                    else
                    {
                        log.Error("Failed to truncate tables FormIDs_To_Process and Tower_MemdocRecords");
                        return false;
                    }
                }
            }
            catch (SqlException s)
            {
                log.Error("TruncateTables - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.Error("TruncateTables - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.Error("TruncateTables - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log.Info(spacer + "TruncateTables(): End");
            }
        }

        /// <summary>
        /// Populates table 'FormIDs_To_Process' with records from XML in 'FormInfo' (one record for each SSN/Account pair),
        /// selecting record with (ScanDate not null) AND ( (Status is 'MISSING', 'PARTIAL' or 'Not Found') OR
        /// (Status is null AND ScanDate is more than 1 day back) ). 
        /// </summary>
        /// <returns></returns>
        protected bool Populate_FormIDs_To_Process()
        {
            try
            {
                log.Info(spacer + "Populate_FormIDs_To_Process(): Start");
                using (SqlCommand sqlCommand = kofaxConnection.CreateCommand())
                {
                    sqlCommand.CommandText = "dbo.KfxIndxRcon_SelectRecFromKofaxInfo";
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;

                    SqlParameter dayDiff = sqlCommand.Parameters.AddWithValue("@DayDifference", Properties.Settings.Default.NumDaysBeforeEmptyStatusScanned);
                    dayDiff.Direction = ParameterDirection.Input;
                    dayDiff.SqlDbType = SqlDbType.Int;

                    SqlParameter retCount = sqlCommand.Parameters.AddWithValue("@ReturnRowCounts", 0);
                    retCount.Direction = ParameterDirection.Output;
                    retCount.SqlDbType = SqlDbType.Int;

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    sqlCommand.ExecuteNonQuery();

                    if ((bool)retVal.Value)
                    {
                        int affectedRows = (int)retCount.Value;
                        log.Info(spacer + "    " + $"Successfully inserted {affectedRows} rows into table FormIDs_To_Process");
                        return true;
                    }
                    else
                    {
                        log.Error("Failed to populate table FormIDs_To_Process");
                        return false;
                    }
                }
            }
            catch (SqlException s)
            {
                log.Error("Populate_FormIDs_To_Process - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.Error("Populate_FormIDs_To_Process - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.Error("Populate_FormIDs_To_Process - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log.Info(spacer + "Populate_FormIDs_To_Process(): End");
            }
        }

        /// <summary>
        /// Get list of distinct UIDNumber strings from table 'FormIDs_To_Process'
        /// </summary>
        /// <returns></returns>
        protected List<String> GetUniqueIDList()
        {
            log.Debug(spacer + "GetUniqueIDList: Start");
            List<String> result = new List<String>();
            string kofaxSqlQuery = "SELECT DISTINCT	UIDNumber FROM dbo.FormIDs_To_Process WITH(NOLOCK) ORDER BY UIDNumber";

            try
            {
                using (DataSet uidDataSet = new DataSet())
                {
                    using (SqlDataAdapter uidAdapter = new SqlDataAdapter(kofaxSqlQuery, kofaxConnection))
                    {
                        uidAdapter.SelectCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;
                        uidAdapter.FillSchema(uidDataSet, SchemaType.Source, "UniqueID_Table");
                        uidAdapter.Fill(uidDataSet, "UniqueID_Table");
                        //log.Debug(spacer + "    " + "GetUniqueIDList: Select Command for Unique IDs has been run.");
                        log.Debug(spacer + "    " + "GetUniqueIDList: Number of unique IDs fetched: " + uidDataSet.Tables["UniqueID_Table"].Rows.Count);

                        foreach (DataRow row in uidDataSet.Tables["UniqueID_Table"].Rows)
                        {
                            result.Add(row["UIDNumber"].ToString());
                        }

                    }
                }
                return result;
            }
            catch (SqlException s)
            {
                log.Error("GetUniqueIDList - SQL Exception: " + s.ToString());
                return null;
            }
            catch (TimeoutException t)
            {
                log.Error("GetUniqueIDList - Timeout Exception: " + t.ToString());
                return null;
            }
            catch (Exception e)
            {
                log.Error("GetUniqueIDList - Exception: " + e.ToString());
                return null;
            }
            finally
            {
                log.Info(spacer + "GetUniqueIDList(): End");
            }

        }

        #region // Assign statuses and its helper methods
        /// <summary>
        /// Assign statuses as FOUND, MISSING and PARTIAL to records in given DataSet whose UIDs are in the given list. 
        /// </summary>
        /// <param name="ds"></param>
        /// <param name="uidList"></param>
        /// <returns></returns>
        protected bool AssignStatuses(DataSet ds, List<string> uidList)
        {
            log.Info(spacer + "AssignStatuses(): Start");
            try
            {
                // Predicate to be used when we compare for equality RecordTriples - it includes logic that returns True if the 
                // only non-matching field is SSN or Account which is blank in one record and non-blank in other.
                // Added for bug 46040
                RecordTripletEqualityComparer comparer = new RecordTripletEqualityComparer();

                foreach (string uid in uidList)
                {
                    DataTable tblKofax = ds.Tables["FormIDs_To_Process"];
                    DataTable tblTower = ds.Tables["Tower_MemdocRecords"];
                    var rowsKofax = tblKofax.AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uid);
                    var rowsTower = tblTower.AsEnumerable().Where(r => r.Field<String>("SpStr3") == uid);

                    if (IsSatusInList(rowsKofax, "MISSING-PROCESSED-T"))
                    {
                        UpdateRecords(rowsKofax, "MISSING", null, DateTime.Now);
                        continue;
                    }

                    // find Kofax records corresponding to Tower records with blank "docdate" - what SP KfxIndxRcon_UpdtRecCreatDateNotFoundInTower failed to do
                    if (IsDocDateBlank(rowsTower))
                    {
                        UpdateRecords(rowsKofax, "MISSING", "No Creation Date found in Tower", DateTime.Now);
                        continue;
                    }

                    if (!AreScanDatesMatch(rowsKofax, rowsTower))
                    {
                        UpdateRecords(rowsKofax, "MISSING", "Creation Date does not match.", DateTime.Now);
                        continue;
                    }


                    if( String.IsNullOrEmpty(rowsKofax.First().Field<string>("SSN")) && String.IsNullOrEmpty(rowsKofax.First().Field<string>("Account")))
                    {
                        UpdateRecords(rowsKofax, "Not Found", "Both SSN and Account are blank", DateTime.Now);
                        continue;
                    }

                    // if list of all triplets (SSN, Account, CreateDate) from Kofax is a subsets of the corresponding Tower list – set Status to 'FOUND';
                    if(IsFoundAll(rowsKofax, rowsTower, comparer))
                    {
                        UpdateRecords(rowsKofax, "FOUND", String.Empty, DateTime.Now);
                    }
                    // if at least one Kofax triplet is found in the tower list, but not all triplets are found, then set Status to "PARTIAL".
                    else if (IsFoundAny(rowsKofax, rowsTower, comparer))
                    {
                        UpdateRecords(rowsKofax, "PARTIAL", "Missing SSN or Account number, or CreateDate mismatch", DateTime.Now);
                    }
                    else if ( IsSatusInList(rowsKofax, "Not Found") )
                    {
                        UpdateRecords(rowsKofax, "Not Found", String.Empty);
                    }
                    else if (rowsKofax.Any(IsStillUnprocessed))
                    {
                        UpdateRecords(rowsKofax, "MISSING", "Missing record", DateTime.Now);
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                log.Error("AssignStatuses - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log.Info(spacer + "AssignStatuses(): End");
            }
        }

        /// <summary>
        /// Returns TRUE if for any element of collection '<paramref name="rowsKofax"/>' Status is equal to 
        /// one of statuses in '<paramref name="keyStatuses"/>'
        /// </summary>
        /// <param name="rowsKofax"></param>
        /// <param name="keyStatuses"></param>
        /// <returns></returns>
        private bool IsSatusInList(EnumerableRowCollection<DataRow> rowsKofax, params string[] keyStatuses)
        {
            if (keyStatuses == null || keyStatuses.Length == 0 || rowsKofax == null || rowsKofax.Count() == 0)
            {
                return false;
            }

            // before comparison convert all strings in keyStatuses to upper case 
            List<string> statusList = keyStatuses.ToList().ConvertAll(s => s?.ToUpper());

            return rowsKofax.Select(row => row.Field<String>("Status")?.Trim().ToUpper())
                .Any(s => !String.IsNullOrEmpty(s) && statusList.Contains(s));

        }

        /// <summary>
        /// Check if any Tower records corresponding to given uid have blank "DocDate" field
        /// </summary>
        /// <param name="tbl"></param>
        /// <param name="uid"></param>
        /// <returns></returns>
        private bool IsDocDateBlank(EnumerableRowCollection<DataRow> rowsTower)
        {
            if (rowsTower == null)
            {
                throw new ArgumentNullException("Argument of method IsDocDateBlank cannot be null");
            }
            return rowsTower
            .Where(row => DBNull.Value.Equals(row["DocDate"]))
            .Any();
        }

        /// <summary>
        /// Returns TRUE if CreateDate for all records in '<paramref name="rowsKofax"/>' is the same, 
        /// DocDate in all records in '<paramref name="rowsTower"/>' are the same, and these ScanDate and DocDate 
        /// match (based on Date only).
        /// </summary>
        /// <param name="rowsKofax"></param>
        /// <param name="rowsTower"></param>
        /// <returns></returns>
        private bool AreScanDatesMatch(EnumerableRowCollection<DataRow> rowsKofax, EnumerableRowCollection<DataRow> rowsTower)
        {
            if (rowsKofax == null || rowsTower == null)
            {
                throw new ArgumentNullException("No argument of method AreScanDatesMatch can be null");
            }
            return rowsKofax.All(r => rowsTower.All(s => AreDBDateTimesEqual(s, "DocDate", r, "CreateDate")));
        }

        /// <summary>
        /// Returns TRUE if dates in given fields of two given DatRows are the same (compares dates only, time is ignored). 
        /// If both dates are blank returns FALSE.
        /// </summary>
        /// <remarks>
        /// All arguments should not be null, otherwise ArgumentNullException is thrown.
        /// </remarks>
        /// <param name="rowKofax"></param>
        /// <param name="fieldNameKofax"></param>
        /// <param name="rowTower"></param>
        /// <param name="fieldNameTower"></param>
        /// <returns></returns>
        private bool AreDBDateTimesEqual(DataRow rowKofax, string fieldNameKofax, DataRow rowTower, string fieldNameTower)
        {
            if (rowKofax == null || rowTower == null || String.IsNullOrEmpty(fieldNameKofax) || String.IsNullOrEmpty(fieldNameTower))
            {
                throw new ArgumentNullException("No argument of method AreDBDateTimesEqual can be null");
            }

            if (DBNull.Value.Equals(rowKofax[fieldNameKofax.Trim()]) ||
                DBNull.Value.Equals(rowTower[fieldNameTower.Trim()])) { return false; }
            else
            {
                return rowKofax.Field<DateTime>(fieldNameKofax.Trim()).Date == rowTower.Field<DateTime>(fieldNameTower.Trim()).Date;
            }
        }

        /// <summary>
        /// Updates Status, Reason [optional] and UpdateDate [optional] fields in all rows in the given collection.
        /// To leave Reason unupdated skip argument '<paramref name="reason"/>' or give it null; to set Reason to null give it String.Empty.
        /// To leave UpdateDate unupdated skip argument '<paramref name="updateDate"/>' or give it null; 
        /// </summary>
        /// <param name="rowsToUpdate"></param>
        /// <param name="status"></param>
        /// <param name="reason"></param>
        /// <param name="updateDate"></param>
        private void UpdateRecords(EnumerableRowCollection<DataRow> rowsToUpdate, string status, string reason = null, DateTime? updateDate = null)
        {
            if (rowsToUpdate == null) return;

            foreach (var row in rowsToUpdate)
            {
                row.SetField("Status", status);
                if (reason != null) { row.SetField("Reason", String.IsNullOrEmpty(reason) ? null : reason.Trim()); }
                if (updateDate.HasValue) { row.SetField("UpdateDate", updateDate.Value); }
            }
        }


        /// <summary>
        /// Returns TRUE if for all records in Kofax collection '<paramref name="rowsKofax"/>' there are records 
        /// with matching combinations (ssn, account, date) in Tower collection '<paramref name="rowsTower"/>'.
        /// </summary>
        /// 
        /// <remarks>
        /// There may be more combinations (ssn, account, date) in Tower collection than in Kofax collection,
        /// it will still return true.
        /// Dates are compared based on Date only.
        /// </remarks>
        ///
        /// <param name="rowsKofax"></param>
        /// <param name="rowsTower"></param>
        /// <param name="comparer">Custom predicate to be used when we compare for equality RecordTriples</param>
        /// <returns></returns>
        private bool IsFoundAll(EnumerableRowCollection<DataRow> rowsKofax, EnumerableRowCollection<DataRow> rowsTower, RecordTripletEqualityComparer comparer)
        {
            if (rowsKofax == null || rowsTower == null) { return false; }

            var kofaxRecords = rowsKofax
                .Select(row => new RecordTriplet(row.Field<String>("SSN"), row.Field<String>("Account"), row.Field<DateTime?>("CreateDate")) );

            var towerRecords = rowsTower
                .Select(row => new RecordTriplet(row.Field<String>("SSN"), row.Field<String>("Account"), row.Field<DateTime?>("docdate")) );

            return kofaxRecords.All(recordKofax => towerRecords.Contains(recordKofax, comparer));
        }


        /// <summary>
        /// Returns TRUE if for at least one record in kofax collection '<paramref name="rowsKofax"/>' there is
        /// a record with matching combination (ssn, account, date) in Tower collection '<paramref name="rowsTower"/>'.
        /// </summary>
        /// 
        /// <remarks>
        /// Dates are compared based on Date only.
        /// </remarks>
        /// 
        /// <param name="rowsKofax"></param>
        /// <param name="rowsTower"></param>
        /// <param name="comparer">Custom predicate to be used when we compare for equality RecordTriples</param>
        /// <returns></returns>
        private bool IsFoundAny(EnumerableRowCollection<DataRow> rowsKofax, EnumerableRowCollection<DataRow> rowsTower, RecordTripletEqualityComparer comparer)
        {
            if (rowsKofax == null || rowsTower == null) { return false; }
            var kofaxRecords = rowsKofax
                .Select(row => new RecordTriplet(row.Field<String>("SSN"), row.Field<String>("Account"), row.Field<DateTime?>("CreateDate")) );
            var towerRecords = rowsTower
                .Select(row => new RecordTriplet(row.Field<String>("SSN"), row.Field<String>("Account"), row.Field<DateTime?>("docdate")) );

            return kofaxRecords.Any(recordKofax => towerRecords.Contains(recordKofax, comparer));
        }

        /// <summary>
        /// This Func&lt;DateRow, bool&gt;  returns true for the given row if either SSN or Account is not blank and Satatus is null
        /// or Status is anything but "Not Found" or "Missing"
        /// </summary>
        /// <remarks>
        /// We are not checking for satus 'Not Found' here; we assume that case was already processed.
        /// </remarks>
        /// <param name="row"></param>
        /// <returns></returns>
        private bool IsStillUnprocessed(DataRow row)
        {
            if(row == null)
            {
                throw new ArgumentNullException("Argument of method IsStillUnprocessed cannot be null");
            }

            bool notBlankSSNOrAcc = !String.IsNullOrWhiteSpace(row.Field<String>("SSN")) || !String.IsNullOrWhiteSpace(row.Field<String>("Account"));
            string status = row.Field<String>("Status");
            if (DBNull.Value.Equals(status) || status == null) { status = String.Empty; }
            status = status.Trim();
            bool isBlank = String.IsNullOrEmpty(status);
            bool isNotFoundOrMissing = status.ToUpper() == "NOT FOUND" || status.ToUpper() == "MISSING";

            return notBlankSSNOrAcc && (isBlank || !isNotFoundOrMissing);
        }
        #endregion


        /// <summary>
        /// Adds table 'FormIDs_To_Process' to existing DataSet
        /// </summary>
        /// <param name="ds"></param>
        /// <returns></returns>
        protected DataSet AddTableToDataSet(DataSet ds)
        {
            log.Info(spacer + "AddTableToDataSet: Start");
            string selectSqlCommand = "SELECT * FROM [dbo].[FormIDs_To_Process] ORDER BY UIDNumber";
            try
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                using (SqlCommand selectCommand = kofaxConnection.CreateCommand())
                {
                    selectCommand.CommandText = selectSqlCommand; 
                    adapter.SelectCommand = selectCommand;
                    adapter.Fill(ds, "FormIDs_To_Process");
                }

                log.Debug(spacer + "    " + $"Added to DataSet table 'FormIDs_To_Process' with {ds.Tables["FormIDs_To_Process"].Rows.Count} rows");
                return ds;
            }
            catch (SqlException s)
            {
                log.Error("AddTableToDataSet - SQL Exception: " + s.ToString());
                return null;
            }
            catch (TimeoutException t)
            {
                log.Error("AddTableToDataSet - Timeout Exception: " + t.ToString());
                return null;
            }
            catch (Exception e)
            {
                log.Error("AddTableToDataSet - Exception: " + e.ToString());
                return null;
            }
            finally
            {
                log.Info(spacer + "AddTableToDataSet(): End");
            }
        }

        /// <summary>
        /// Retrieves records from 'tower.memdoc' table for which field SpStr3 was found in the given list. Returns DataSet 
        /// with first table 'Tower_MemdocRecords' populated with fetched records.
        /// </summary>
        /// <param name="uidList"></param>
        /// <returns>DataSet with first table 'Tower_MemdocRecords' populated with fetched records</returns>
        protected DataSet FetchFromIDM(List<String> uidList)
        {
            log.Info(spacer + "FetchFromIDM: Start");
            try
            {
                DataSet resultDataset = new DataSet();

                using (SqlCommand selectCommand = towerConnection.CreateCommand())
                {
                    selectCommand.CommandText = "dbo.KfxIndxRcon_SelectRecFromTowerMemdoc";
                    selectCommand.CommandType = CommandType.StoredProcedure;
                    selectCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;
                    SqlParameter parameter = selectCommand.Parameters.AddWithValue("@id_list", CreateDataTable(uidList));

                    parameter.Direction = ParameterDirection.Input;
                    parameter.SqlDbType = SqlDbType.Structured;
                    parameter.TypeName = "dbo.list_varchar";

                    SqlParameter retVal = selectCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    // create and run DataAdapter with this SelectCommand
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    adapter.SelectCommand = selectCommand;

                    adapter.Fill(resultDataset, "Tower_MemdocRecords");

                    if (!(bool)retVal.Value)
                    {
                        log.Error("Failed to populate DataSet with records from TowerDB");
                        return null;
                    }
                    else
                    {
                        log.Debug(spacer + "    " + $"Added to DataSet table 'Tower_MemdocRecords' with {resultDataset.Tables["Tower_MemdocRecords"].Rows.Count} rows");
                    }

                    return resultDataset;
                }

            }
            catch (SqlException s)
            {
                log.Error("FetchFromIDM - SQL Exception: " + s.ToString());
                return null;
            }
            catch (TimeoutException t)
            {
                log.Error("FetchFromIDM - Timeout Exception: " + t.ToString());
                return null;
            }
            catch (Exception e)
            {
                log.Error("FetchFromIDM - Exception: " + e.ToString());
                return null;
            }
            finally
            {
                log.Info(spacer + "FetchFromIDM(): End");
            }
        }

        protected  DataTable CreateDataTable(IEnumerable<String> uidList)
        {
            DataTable table = new DataTable();
            table.Columns.Add("id", typeof(string));
            foreach(String uid in uidList)
            {
                table.Rows.Add(uid);
            }
            return table;
        }

        /// <summary>
        /// Performs bulk copy of data from DataSet table to Kofax DB table with given name. 
        /// </summary>
        /// <remarks>
        /// Column mapping assumes that the table is [dbo].[Tower_MemdocRecords]; for other tables it wouldn't work.
        /// Table <paramref name="tableName"/> is assumed to have index 0 in the DataSet.
        /// </remarks>
        /// <param name="ds"></param>
        /// <param name="tableName">Name of destination table in database</param>
        /// <returns>
        /// True on successful insert, false if bulk insert failed or counts of inserted records and 
        /// DataSet records don't match.
        /// </returns>
        protected bool BulkCopyDataSetToKofaxTable(DataSet ds, String tableName)
        {  
            try
            {
                log.Info(spacer + "BulkCopyDataSetToKofaxTable(): Start");
                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(kofaxConnection))
                {
                    bulkCopy.ColumnMappings.Add("spstr3", "SpStr3");
                    bulkCopy.ColumnMappings.Add("docdate", "DocDate");
                    bulkCopy.ColumnMappings.Add("account", "Account");
                    bulkCopy.ColumnMappings.Add("ssn", "SSN");

                    bulkCopy.DestinationTableName = tableName;

                    bulkCopy.WriteToServer(ds.Tables[0]);

                    // because bulkCopy.WriteToServer() does not throw exception on SQL Server errors, to detect error
                    // we compare numbers of rows in the database after insertion with number of rows in the DataSet
                    int dbCount = GetRowCountFromDBTable(tableName, kofaxConnection);
                    if(dbCount < 0) {
                        throw new Exception($"Failed to get count of rows in the table {tableName} after BulkCopy");
                    }
                    if(ds.Tables[0].Rows.Count != dbCount)
                    {
                        string msg = $"BulkCopy into table {tableName} failed: number of rows in DB table is {dbCount}, ";
                        msg += $"number of rows in DataSet is {ds.Tables[0].Rows.Count}";
                        throw new Exception(msg);
                    }

                    log.Debug(spacer + $"Performed BulkCopy of {dbCount} rows from DataSet to DB table '{tableName}'");
                }

                return true;
            }
            catch (SqlException s)
            {
                log.Error("BulkCopyDataSetToKofaxTable - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.Error("BulkCopyDataSetToKofaxTable - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.Error("BulkCopyDataSetToKofaxTable - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log.Info(spacer + "BulkCopyDataSetToKofaxTable(): End");
            }
        }

        /// <summary>
        /// Updated the table in the DB with information from the corresponding table in the DataSet.
        /// </summary>
        /// <param name="ds">DataSet</param>
        /// <param name="tableName">Name of the table in the DB and in the DataSet. 
        ///     Note: this table must have a Primary Key, otherwise updateCommand couldn't be generated 
        /// </param>
        /// <returns>True if updated successfully</returns>
        protected bool UpdateKofaxTableFromDataSet(DataSet ds, String tableName)
        {
            string selectDummyCommand = $"SELECT * FROM {tableName}";
            try
            {
                log.Info(spacer + "UpdateTableFromDataSet(): Start");

                int dbCount = 0; // number of rows successfully updated in the database
                using (SqlDataAdapter sqlDtaAdapter = new SqlDataAdapter())
                {
                    sqlDtaAdapter.SelectCommand = new SqlCommand(selectDummyCommand, kofaxConnection);

                    using (SqlCommandBuilder cb = new SqlCommandBuilder(sqlDtaAdapter))
                    {
                        sqlDtaAdapter.UpdateCommand = cb.GetUpdateCommand();
                        dbCount = sqlDtaAdapter.Update(ds, tableName);
                    }
                }

                int dsCount = ds.Tables[tableName].Rows.Count;
                log.Debug(spacer + "    " + $"Updated {dsCount} rows in the DB table '{tableName}'; DataSet row count is {dsCount}");
                return true;

            }
            catch (SqlException s)
            {
                log.Error("UpdateTableFromDataSet - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.Error("UpdateTableFromDataSet - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.Error("UpdateTableFromDataSet - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log.Info(spacer + "UpdateTableFromDataSet(): End");
            }
        }

        protected bool ExecSP(string spName, string tableName)
        {
            try
            {
                log.Info(spacer + $"ExecSP({spName}): Start");
                using (SqlCommand sqlCommand = kofaxConnection.CreateCommand())
                {
                    sqlCommand.CommandText = spName;
                    sqlCommand.CommandType = CommandType.StoredProcedure;
                    sqlCommand.CommandTimeout = Properties.Settings.Default.DbCmdTimeout;

                    SqlParameter retCount = sqlCommand.Parameters.AddWithValue("@ReturnRowCounts", 0);
                    retCount.Direction = ParameterDirection.Output;
                    retCount.SqlDbType = SqlDbType.Int;

                    SqlParameter retVal = sqlCommand.Parameters.AddWithValue("@ReturnResult", false);
                    retVal.Direction = ParameterDirection.Output;
                    retVal.SqlDbType = SqlDbType.Bit;

                    sqlCommand.ExecuteNonQuery();

                    if ((bool)retVal.Value)
                    {
                        int affectedRows = (int)retCount.Value;
                        log.Info(spacer + "    " + $"SP '{spName}' successfully updated {affectedRows} rows in the table {tableName}");
                        return true;
                    }
                    else
                    {
                        log.Error($"SP '{spName}' has failed.");
                        return false;
                    }
                }

            }
            catch (SqlException s)
            {
                log.Error($"ExecSP({spName}) - SQL Exception: " + s.ToString());
                return false;
            }
            catch (TimeoutException t)
            {
                log.Error($"ExecSP({spName}) - Timeout Exception: " + t.ToString());
                return false;
            }
            catch (Exception e)
            {
                log.Error($"ExecSP({spName}) - Exception: " + e.ToString());
                return false;
            }
            finally
            {
                log.Info(spacer + $"ExecSP({spName}): End");
            }
        }

        public static void SendEmailMessage(string msg)
        {
            try
            {
                log.Info(spacer + "NightlyRecon.SendEmailMessage(): Start");
                string from = Properties.Settings.Default.emailFrom;
                if (String.IsNullOrEmpty(from))
                {
                    string logMessage = "Unable to determine the email address of the current user. The email will not be sent.";
                    log.Error(logMessage);
                    log.Info(spacer + "SendEmailMessage(): End");
                    return;
                }

                SECUEmail secuEmail = new SECUEmail(log, spacer + "  ");
                secuEmail.SendSmtpEmail = Properties.Settings.Default.useSMTP;
                secuEmail.FromAddress = from;
                secuEmail.Subject = Properties.Settings.Default.emailSubject;
                secuEmail.Body = Properties.Settings.Default.emailBody + Environment.NewLine + "Error details:  " + msg;

                // Properties.Settings.Default.emailTo - comma separated list of receiver addresses
                secuEmail.ToAddress = new List<string>();
                foreach (var address in Properties.Settings.Default.emailTo.Split(new[] { ";", ",", " " }, StringSplitOptions.RemoveEmptyEntries))
                {
                    secuEmail.ToAddress.Add(address);
                }

                if (Properties.Settings.Default.useSMTP)  // use SMTP server to send email
                {
                    secuEmail.SMTPHost = Properties.Settings.Default.SMTPServerName;
                    secuEmail.SMTPPort = Properties.Settings.Default.SMTPPort;
                    secuEmail.SmtpUserName = Properties.Settings.Default.SmtpUserName;
                    secuEmail.SmtpPassword = Properties.Settings.Default.SmtpPassword;
                    secuEmail.TurnTraceOn = true;
                }
                else  //EWS email
                {
                    secuEmail.exchangeVersion = Properties.Settings.Default.ExchangeVersion;
                    secuEmail.Autodiscover = true;  // Autodiscover is a preferred method 
                }

                secuEmail.SendMail();
                if (!String.IsNullOrEmpty(secuEmail.ErrorMessage))
                {
                    string message = "Failed to send email. Error message: " + secuEmail.ErrorMessage;
                    log.Error(message);
                }
            }
            catch (Exception ex)
            {
                log.Error("Exception caught in SendEmailMessage(): " + ex.ToString());
            }
            finally
            {
                log.Info(spacer + "NightlyRecon.SendEmailMessage(): end");
            }
        }

        private int GetRowCountFromDBTable(string tableName, SqlConnection connection)
        {
            try
            {
                string kofaxSqlQuery = $"SELECT COUNT(*) FROM {tableName} WITH(NOLOCK)";
                int count = -1;
                using (SqlCommand cmdCount = new SqlCommand(kofaxSqlQuery, connection))
                {
                    count = (int)cmdCount.ExecuteScalar();
                }
                return count;
            }
            catch (Exception)
            {
                return -1;
            }
        }
    }


    /// <summary>
    /// Represents record object with 3 string fields: SSN, Account and CreateDate. Null values are represented by empty strings in object fields. 
    /// Field CreateDate contains string representation of the date without time.
    /// </summary>
    public class RecordTriplet
    {
        public string SSN { get; private set; }

        public string Account { get; private set; }

        public string CreateDate { get; private set; }

        // constructor with 3 parameters
        public RecordTriplet(string ssn, string acc, DateTime? createDate)
        {
            SSN = ssn == null ? String.Empty : ssn.Trim();
            Account = acc == null ? String.Empty : acc.Trim();
            CreateDate = createDate.HasValue ? createDate.Value.Date.ToString("MM-dd-yyyy") : String.Empty;
        }
    } //end class RecordTriplet


    /// <summary>
    /// Predicate for custom equality comparison of RecordTriplet objects. Objects are considered equal when only one of fields SSN or Account 
    /// don't match and in one of objects this field is blank while in other object it is non-blank.
    /// </summary>
    public class RecordTripletEqualityComparer : EqualityComparer<RecordTriplet>
    {
        // Derived from class EqualityComparer<T> (https://docs.microsoft.com/en-us/dotnet/api/system.collections.generic.equalitycomparer-1)
        // which is recommended base class for custom implementation of IEqualityComparer<T> interface.

        public override bool Equals(RecordTriplet first, RecordTriplet second)
        {
            if (first == null && second == null)
                return true;
            else if (first == null || second == null)
                return false;

            if (first.CreateDate.Trim() != second.CreateDate.Trim())
            {
                return false;
            }

            if( (first.SSN == string.Empty && first.Account == String.Empty) || (second.SSN == string.Empty && second.Account == String.Empty))
            {
                return false;
            }

            if (first.SSN == second.SSN && first.Account == second.Account)
            {
                return true;
            }

            if (first.SSN != second.SSN && first.Account != second.Account)
            {
                return false;
            }

            if (first.SSN == second.SSN && (first.Account == String.Empty || second.Account == String.Empty))
            {
                return true;
            }
            else if (first.Account == second.Account && (first.SSN == String.Empty || second.SSN == String.Empty))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        /// <summary>
        /// Method required for interface implementation, but is not used in our application
        /// </summary>
        /// <param name="tr"></param>
        /// <returns></returns>
        public override int GetHashCode(RecordTriplet tr)
        {
            if (tr == null) { return 0; }
            return tr.SSN.GetHashCode() ^ tr.Account.GetHashCode() ^ tr.CreateDate.GetHashCode();
        }
    }

}