﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Linq;

namespace KofaxIndexRecon
{
    public partial class ConfigurationForm : Form
    {
        private readonly String configFile;
        private string appName; // Name of the application; we need it because it appears in the setting names

        public ConfigurationForm(String configFile)  // Constructor
        {
            InitializeComponent();
            this.configFile = configFile;

            appName = Path.GetFileName(configFile);
            var tokens = appName.Split('.');
            if (tokens.Length > 0) { appName = tokens[0]; }
            else { appName = "KofaxIndexRecon"; }
        }

        private void ConfigurationForm_Load(object sender, EventArgs e)
        {
            if (!File.Exists(configFile))
            {
                string msg = $"Config file '{configFile}' not found. Installation aborted." + Environment.NewLine + Environment.NewLine + "Please notify BSD of this problem.";
                MessageBox.Show(msg, "Configure Settings", MessageBoxButtons.OK, MessageBoxIcon.Error);
                DialogResult = DialogResult.Abort;
                Close();
            }

            PopulateForm(configFile);

            // We don't want text in tbTowerConn to be highlighted when the form opens
            tbTowerConn.SelectionStart = tbTowerConn.Text.Length;
            tbTowerConn.DeselectAll();
        }


        private void UpdateConfig(String configFile)
        {
            try
            {
                XDocument doc = XDocument.Load(configFile);

                XAttribute kofaxConnString = GetConnStringAttribute(doc, $"{appName}.Properties.Settings.kofaxConnString");
                if (kofaxConnString != null) kofaxConnString.Value = tbKofaxConn.Text.Trim();
                else { ShowError("connection string", $"{appName}.Properties.Settings.kofaxConnString"); }

                XAttribute towerConnString = GetConnStringAttribute(doc, $"{appName}.Properties.Settings.towerConnString");
                if (towerConnString != null) towerConnString.Value = tbTowerConn.Text.Trim();
                else { ShowError("connection string", $"{appName}.Properties.Settings.towerConnString"); }

                XAttribute logFile = GetLogFileValueAttribute(doc);
                if (logFile != null) logFile.Value = Path.Combine(tbLogFolder.Text.Trim(), $"{appName}.log");
                else { ShowError("log file name in element 'LogFileAppender', sub-element", "File"); }

                List<XElement> settings = GetAllSettings(doc); // remember 'settings' XElement list to avoid multiple reading of config file

                XElement branchScanReportFolder = GetSettingElement(settings, "BranchScanningReportFolder");
                if (branchScanReportFolder != null) branchScanReportFolder.Value = tbBranchScanRepFolder.Text.Trim();
                else { ShowError("setting", $"BranchScanningReportFolder"); }

                XElement partialReportFolder = GetSettingElement(settings, "PartialReportFolder");
                if (partialReportFolder != null) partialReportFolder.Value = tbPartialReportFolder.Text.Trim();
                else { ShowError("setting", $"PartialReportFolder"); }

                XElement emailFrom = GetSettingElement(settings, "emailFrom");
                if (emailFrom != null) emailFrom.Value = tbEmailFrom.Text.Trim();
                else { ShowError("setting", $"emailFrom"); }

                XElement emailTo = GetSettingElement(settings, "emailTo");
                if (emailTo != null) emailTo.Value = tbEmailTo.Text.Trim();
                else { ShowError("setting", $"emailTo"); }

                doc.Save(configFile);
            }
            catch (Exception ex)
            {
                String msg = "Installation aborted. Exception caught when saving configuration settings:  " + ex.ToString() + 
                             Environment.NewLine + Environment.NewLine + "Please notify BSD of this problem.";
                MessageBox.Show(msg, "Configuration Settings", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ShutDown();
            }
        }

        private void PopulateForm(String configFile)
        {
            try
            {
                tbKofaxConn.Text = GetConnStringValue(configFile, $"{appName}.Properties.Settings.kofaxConnString");
                tbTowerConn.Text = GetConnStringValue(configFile, $"{appName}.Properties.Settings.towerConnString");

                tbLogFolder.Text = GetLogFolderValue(configFile);

                List<XElement> settings = GetAllSettings(configFile);
                tbBranchScanRepFolder.Text = FetchSettingValue(settings, "BranchScanningReportFolder").Trim();
                tbPartialReportFolder.Text = FetchSettingValue(settings, "PartialReportFolder").Trim();
                tbEmailFrom.Text = FetchSettingValue(settings, "emailFrom").Trim();
                tbEmailTo.Text = FetchSettingValue(settings, "emailTo").Trim();
            }
            catch (Exception ex)
            {
                String msg = "Installation aborted. Exception caught when populating Settings Configuration Form:  " + ex.ToString() +
                             Environment.NewLine + Environment.NewLine + "Please notify BSD of this problem.";
                MessageBox.Show(msg, "Configure Settings", MessageBoxButtons.OK, MessageBoxIcon.Error);
                ShutDown();
            }
        }

        #region    // Helper methods
        private List<XElement> GetAllSettings(string configFile)
        {
            XDocument doc = XDocument.Load(configFile);
            return GetAllSettings(doc);
        }

        private List<XElement> GetAllSettings(XDocument doc)
        {
            try
            {
                return doc.Element("configuration")?.Element("applicationSettings")
                    ?.Element($"{appName}.Properties.Settings")?.Elements("setting").ToList();
            }
            catch { return new List<XElement>(); }
        }

        private string FetchSettingValue(List<XElement> settings, string settingName)
        {
            if (settings == null || settings.Count == 0 || string.IsNullOrWhiteSpace(settingName)) return string.Empty;

            try
            {
                return settings.FirstOrDefault(x => x.Attribute("name")?.Value == settingName)?.Element("value")?.Value;
            }
            catch { return string.Empty; }
        }

        private XElement GetSettingElement(List<XElement> settings, string settingName)
        {
            if (settings == null || settings.Count == 0 || string.IsNullOrWhiteSpace(settingName)) return null;
            try
            {
                return settings.FirstOrDefault(x => x.Attribute("name")?.Value == settingName)?.Element("value");
            }
            catch { return null; }
        }

        private string GetLogFolderValue(string configFile)
        {
            try
            {
                XDocument doc = XDocument.Load(configFile);
                return Path.GetDirectoryName(GetLogFileValueAttribute(doc)?.Value);
            }
            catch { return string.Empty; }
        }

        private XAttribute GetLogFileValueAttribute(XDocument doc)
        {
            try
            {
                XElement fileAppender = doc.Element("configuration")?.Element("log4net")?.Elements("appender")
                    ?.Where(x => x.Attribute("name")?.Value == "LogFileAppender").First();
                return fileAppender?.Elements("param")?.FirstOrDefault(x => x.Attribute("name")?.Value == "File")?.Attribute("value");
            }
            catch { return null; }
        }

        private string GetConnStringValue(string configFile, string connStringName)
        {
            try
            {
                XDocument doc = XDocument.Load(configFile);
                return GetConnStringAttribute(doc, connStringName)?.Value?.Trim();
            }
            catch { return string.Empty; }
        }

        private XAttribute GetConnStringAttribute(XDocument doc, string connStringName)
        {
            try
            {
                var conStrings = doc.Element("configuration")?.Element("connectionStrings")?.Elements("add");
                return conStrings?.FirstOrDefault(x => x.Attribute("name")?.Value == connStringName)
                    ?.Attribute("connectionString");
            }
            catch { return null; }
        }

        public void ShowError(string settingKind, string settingName)
        {
            string msg = $"Installer failed to update {settingKind} '{settingName}' in the config file. "
                         + Environment.NewLine + "Please update this setting manually.";
            MessageBox.Show(msg, "Installer Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        #endregion // Helper methods


        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;

                // Check for any empty field. All fields are required for a successful install         
                var emptyTextBox = Controls.OfType<TextBox>().FirstOrDefault(t => string.IsNullOrWhiteSpace(t.Text));
                if (emptyTextBox != null)
                {
                    MessageBox.Show(new Form {TopMost = true},
                        @"All field values are required" + Environment.NewLine + Environment.NewLine +
                        "for a successful install");
                    emptyTextBox.Focus();
                    return;
                }

                UpdateConfig(configFile);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception thrown: " + ex.Message);
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("The installation is not yet complete. Are you sure you want to exit?", "Configure Settings", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                DialogResult = DialogResult.Cancel;
                Close();
            }
        }

        private void btnBrowseBranchScanRepFolder_Click(object sender, EventArgs e)
        {
            try
            {
                Thread worker = new Thread(() =>
                {
                    FolderBrowserDialog dialog = new FolderBrowserDialog();
                    dialog.Description = "Select Folder for 'Branch Scanning' Report";
                    dialog.ShowNewFolderButton = true;
                    dialog.RootFolder = Environment.SpecialFolder.MyComputer;

                    DialogResult res = dialog.ShowDialog();
                    if (res == DialogResult.OK && dialog.SelectedPath != null)
                    {
                        tbBranchScanRepFolder.Text = dialog.SelectedPath;
                    }
                });
                worker.SetApartmentState(ApartmentState.STA); // This is what makes the difference
                worker.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception thrown: " + ex.Message);
            }
        }

        private void btnBrowseLogFolder_Click(object sender, EventArgs e)
        {
            try
            {
                Thread worker = new Thread(() =>
                {
                    FolderBrowserDialog dialog = new FolderBrowserDialog();
                    dialog.Description = "Select Log Folder";
                    dialog.ShowNewFolderButton = true;
                    dialog.RootFolder = Environment.SpecialFolder.MyComputer;

                    DialogResult res = dialog.ShowDialog();
                    if (res == DialogResult.OK && dialog.SelectedPath != null)
                    {
                        tbLogFolder.Text = dialog.SelectedPath;
                    }
                });
                worker.SetApartmentState(ApartmentState.STA); // this is what makes the difference
                worker.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception thrown: " + ex.Message);
            }
        }

        private void btnBrowsePartialRepFolder_Click(object sender, EventArgs e)
        {
            try
            {
                Thread worker = new Thread(() =>
                {
                    FolderBrowserDialog dialog = new FolderBrowserDialog();
                    dialog.Description = "Select Folder for 'Partial' Report ";
                    dialog.ShowNewFolderButton = true;
                    dialog.RootFolder = Environment.SpecialFolder.MyComputer;

                    DialogResult res = dialog.ShowDialog();
                    if (res == DialogResult.OK && dialog.SelectedPath != null)
                    {
                        tbPartialReportFolder.Text = dialog.SelectedPath;
                    }
                });
                worker.SetApartmentState(ApartmentState.STA); // This is what makes the difference
                worker.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception thrown: " + ex.Message);
            }
        }

        private void ShutDown()
        {
            Cursor.Current = Cursors.Default;
            DialogResult = DialogResult.Abort;
            Close();
        }


    }
}
