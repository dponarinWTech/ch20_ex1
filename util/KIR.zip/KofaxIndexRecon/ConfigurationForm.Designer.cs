﻿namespace KofaxIndexRecon
{
    partial class ConfigurationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfigurationForm));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTop = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.tbEmailTo = new System.Windows.Forms.TextBox();
            this.lblEmailTo = new System.Windows.Forms.Label();
            this.tbEmailFrom = new System.Windows.Forms.TextBox();
            this.lblEmailFrom = new System.Windows.Forms.Label();
            this.btnBrowseLogFolder = new System.Windows.Forms.Button();
            this.tbLogFolder = new System.Windows.Forms.TextBox();
            this.lblLogFolder = new System.Windows.Forms.Label();
            this.btnBrowseBranchScanRepFolder = new System.Windows.Forms.Button();
            this.tbBranchScanRepFolder = new System.Windows.Forms.TextBox();
            this.lblBranchScanRepFolder = new System.Windows.Forms.Label();
            this.tbTowerConn = new System.Windows.Forms.TextBox();
            this.lblTowerConn = new System.Windows.Forms.Label();
            this.tbKofaxConn = new System.Windows.Forms.TextBox();
            this.lblKofaxConn = new System.Windows.Forms.Label();
            this.btnBrowsePartialRepFolder = new System.Windows.Forms.Button();
            this.tbPartialReportFolder = new System.Windows.Forms.TextBox();
            this.lblPartialReportFolder = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.lblTop);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(705, 69);
            this.panel1.TabIndex = 1;
            // 
            // lblTop
            // 
            this.lblTop.AutoSize = true;
            this.lblTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTop.Location = new System.Drawing.Point(192, 24);
            this.lblTop.Name = "lblTop";
            this.lblTop.Size = new System.Drawing.Size(377, 25);
            this.lblTop.TabIndex = 1;
            this.lblTop.Text = "Kofax Index Configuration Settings";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(613, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(92, 69);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(465, 528);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(135, 26);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(311, 528);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(135, 26);
            this.btnOK.TabIndex = 9;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // tbEmailTo
            // 
            this.tbEmailTo.Location = new System.Drawing.Point(126, 489);
            this.tbEmailTo.Name = "tbEmailTo";
            this.tbEmailTo.Size = new System.Drawing.Size(474, 20);
            this.tbEmailTo.TabIndex = 8;
            // 
            // lblEmailTo
            // 
            this.lblEmailTo.AutoSize = true;
            this.lblEmailTo.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailTo.Location = new System.Drawing.Point(24, 488);
            this.lblEmailTo.Name = "lblEmailTo";
            this.lblEmailTo.Size = new System.Drawing.Size(88, 21);
            this.lblEmailTo.TabIndex = 75;
            this.lblEmailTo.Text = "Email To:";
            // 
            // tbEmailFrom
            // 
            this.tbEmailFrom.Location = new System.Drawing.Point(126, 447);
            this.tbEmailFrom.Name = "tbEmailFrom";
            this.tbEmailFrom.Size = new System.Drawing.Size(474, 20);
            this.tbEmailFrom.TabIndex = 7;
            // 
            // lblEmailFrom
            // 
            this.lblEmailFrom.AutoSize = true;
            this.lblEmailFrom.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailFrom.Location = new System.Drawing.Point(21, 446);
            this.lblEmailFrom.Name = "lblEmailFrom";
            this.lblEmailFrom.Size = new System.Drawing.Size(109, 21);
            this.lblEmailFrom.TabIndex = 74;
            this.lblEmailFrom.Text = "Email From:";
            // 
            // btnBrowseLogFolder
            // 
            this.btnBrowseLogFolder.Location = new System.Drawing.Point(620, 406);
            this.btnBrowseLogFolder.Name = "btnBrowseLogFolder";
            this.btnBrowseLogFolder.Size = new System.Drawing.Size(75, 22);
            this.btnBrowseLogFolder.TabIndex = 6;
            this.btnBrowseLogFolder.Text = "Browse";
            this.btnBrowseLogFolder.UseVisualStyleBackColor = true;
            this.btnBrowseLogFolder.Click += new System.EventHandler(this.btnBrowseLogFolder_Click);
            // 
            // tbLogFolder
            // 
            this.tbLogFolder.Location = new System.Drawing.Point(21, 408);
            this.tbLogFolder.Name = "tbLogFolder";
            this.tbLogFolder.Size = new System.Drawing.Size(581, 20);
            this.tbLogFolder.TabIndex = 5;
            // 
            // lblLogFolder
            // 
            this.lblLogFolder.AutoSize = true;
            this.lblLogFolder.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogFolder.Location = new System.Drawing.Point(20, 386);
            this.lblLogFolder.Name = "lblLogFolder";
            this.lblLogFolder.Size = new System.Drawing.Size(182, 21);
            this.lblLogFolder.TabIndex = 73;
            this.lblLogFolder.Text = "Log Folder Location:";
            // 
            // btnBrowseBranchScanRepFolder
            // 
            this.btnBrowseBranchScanRepFolder.Location = new System.Drawing.Point(620, 244);
            this.btnBrowseBranchScanRepFolder.Name = "btnBrowseBranchScanRepFolder";
            this.btnBrowseBranchScanRepFolder.Size = new System.Drawing.Size(75, 22);
            this.btnBrowseBranchScanRepFolder.TabIndex = 4;
            this.btnBrowseBranchScanRepFolder.Text = "Browse";
            this.btnBrowseBranchScanRepFolder.UseVisualStyleBackColor = true;
            this.btnBrowseBranchScanRepFolder.Click += new System.EventHandler(this.btnBrowseBranchScanRepFolder_Click);
            // 
            // tbBranchScanRepFolder
            // 
            this.tbBranchScanRepFolder.Location = new System.Drawing.Point(21, 245);
            this.tbBranchScanRepFolder.Name = "tbBranchScanRepFolder";
            this.tbBranchScanRepFolder.Size = new System.Drawing.Size(581, 20);
            this.tbBranchScanRepFolder.TabIndex = 3;
            // 
            // lblBranchScanRepFolder
            // 
            this.lblBranchScanRepFolder.AutoSize = true;
            this.lblBranchScanRepFolder.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBranchScanRepFolder.Location = new System.Drawing.Point(18, 223);
            this.lblBranchScanRepFolder.Name = "lblBranchScanRepFolder";
            this.lblBranchScanRepFolder.Size = new System.Drawing.Size(352, 21);
            this.lblBranchScanRepFolder.TabIndex = 72;
            this.lblBranchScanRepFolder.Text = "BranchScanning Report Folder Location:";
            // 
            // tbTowerConn
            // 
            this.tbTowerConn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTowerConn.Location = new System.Drawing.Point(21, 113);
            this.tbTowerConn.Name = "tbTowerConn";
            this.tbTowerConn.Size = new System.Drawing.Size(578, 22);
            this.tbTowerConn.TabIndex = 1;
            // 
            // lblTowerConn
            // 
            this.lblTowerConn.AutoSize = true;
            this.lblTowerConn.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTowerConn.Location = new System.Drawing.Point(18, 94);
            this.lblTowerConn.Name = "lblTowerConn";
            this.lblTowerConn.Size = new System.Drawing.Size(256, 21);
            this.lblTowerConn.TabIndex = 76;
            this.lblTowerConn.Text = "Tower DB Connection String:";
            // 
            // tbKofaxConn
            // 
            this.tbKofaxConn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbKofaxConn.Location = new System.Drawing.Point(23, 170);
            this.tbKofaxConn.Name = "tbKofaxConn";
            this.tbKofaxConn.Size = new System.Drawing.Size(578, 22);
            this.tbKofaxConn.TabIndex = 2;
            // 
            // lblKofaxConn
            // 
            this.lblKofaxConn.AutoSize = true;
            this.lblKofaxConn.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKofaxConn.Location = new System.Drawing.Point(23, 151);
            this.lblKofaxConn.Name = "lblKofaxConn";
            this.lblKofaxConn.Size = new System.Drawing.Size(253, 21);
            this.lblKofaxConn.TabIndex = 78;
            this.lblKofaxConn.Text = "Kofax DB Connection String:";
            // 
            // btnBrowsePartialRepFolder
            // 
            this.btnBrowsePartialRepFolder.Location = new System.Drawing.Point(616, 313);
            this.btnBrowsePartialRepFolder.Name = "btnBrowsePartialRepFolder";
            this.btnBrowsePartialRepFolder.Size = new System.Drawing.Size(75, 22);
            this.btnBrowsePartialRepFolder.TabIndex = 80;
            this.btnBrowsePartialRepFolder.Text = "Browse";
            this.btnBrowsePartialRepFolder.UseVisualStyleBackColor = true;
            this.btnBrowsePartialRepFolder.Click += new System.EventHandler(this.btnBrowsePartialRepFolder_Click);
            // 
            // tbPartialReportFolder
            // 
            this.tbPartialReportFolder.Location = new System.Drawing.Point(17, 314);
            this.tbPartialReportFolder.Name = "tbPartialReportFolder";
            this.tbPartialReportFolder.Size = new System.Drawing.Size(581, 20);
            this.tbPartialReportFolder.TabIndex = 79;
            // 
            // lblPartialReportFolder
            // 
            this.lblPartialReportFolder.AutoSize = true;
            this.lblPartialReportFolder.Font = new System.Drawing.Font("Gadugi", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPartialReportFolder.Location = new System.Drawing.Point(14, 292);
            this.lblPartialReportFolder.Name = "lblPartialReportFolder";
            this.lblPartialReportFolder.Size = new System.Drawing.Size(269, 21);
            this.lblPartialReportFolder.TabIndex = 81;
            this.lblPartialReportFolder.Text = "Partial Report Folder Location:";
            // 
            // ConfigurationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(705, 567);
            this.ControlBox = false;
            this.Controls.Add(this.btnBrowsePartialRepFolder);
            this.Controls.Add(this.tbPartialReportFolder);
            this.Controls.Add(this.lblPartialReportFolder);
            this.Controls.Add(this.tbKofaxConn);
            this.Controls.Add(this.lblKofaxConn);
            this.Controls.Add(this.tbTowerConn);
            this.Controls.Add(this.lblTowerConn);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.tbEmailTo);
            this.Controls.Add(this.lblEmailTo);
            this.Controls.Add(this.tbEmailFrom);
            this.Controls.Add(this.lblEmailFrom);
            this.Controls.Add(this.btnBrowseLogFolder);
            this.Controls.Add(this.tbLogFolder);
            this.Controls.Add(this.lblLogFolder);
            this.Controls.Add(this.btnBrowseBranchScanRepFolder);
            this.Controls.Add(this.tbBranchScanRepFolder);
            this.Controls.Add(this.lblBranchScanRepFolder);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ConfigurationForm";
            this.Text = "Settings Configuration Form";
            this.Load += new System.EventHandler(this.ConfigurationForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTop;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.TextBox tbEmailTo;
        private System.Windows.Forms.Label lblEmailTo;
        private System.Windows.Forms.TextBox tbEmailFrom;
        private System.Windows.Forms.Label lblEmailFrom;
        private System.Windows.Forms.Button btnBrowseLogFolder;
        private System.Windows.Forms.TextBox tbLogFolder;
        private System.Windows.Forms.Label lblLogFolder;
        private System.Windows.Forms.Button btnBrowseBranchScanRepFolder;
        private System.Windows.Forms.TextBox tbBranchScanRepFolder;
        private System.Windows.Forms.Label lblBranchScanRepFolder;
        private System.Windows.Forms.TextBox tbTowerConn;
        private System.Windows.Forms.Label lblTowerConn;
        private System.Windows.Forms.TextBox tbKofaxConn;
        private System.Windows.Forms.Label lblKofaxConn;
        private System.Windows.Forms.Button btnBrowsePartialRepFolder;
        private System.Windows.Forms.TextBox tbPartialReportFolder;
        private System.Windows.Forms.Label lblPartialReportFolder;
    }
}