﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KofaxIndexRecon
{
    /// <summary>
    /// Extension of StringBuilder class: It maintains counter of lines in the StringBuilder.
    /// </summary>
    public class StringBuilderWithLineCount
    {
        private StringBuilder strBuild;
        public int LineCount { get; private set; }

        public StringBuilderWithLineCount()
        {
            strBuild = new StringBuilder();
            LineCount = 0;
        }

        public void Clear()
        {
            strBuild.Clear();
            LineCount = 0;
        }

        /// <summary>
        /// Appends "in place" given string to the end of StringBuilder and adds NewLine.
        /// </summary>
        /// <param name="strToAppend"></param>
        public StringBuilderWithLineCount AppendLine(String strToAppend = null)
        {
            int lines = String.IsNullOrEmpty(strToAppend) ? 0 : strToAppend.Count(c => c == '\n');
            strBuild.AppendLine(strToAppend ?? string.Empty);
            LineCount += lines + 1;
            return this;
        }

        /// <summary>
        /// Appends "in place" to the end of the current StringBuilderWithLineCount second one. If parameter is null nothing is appended.
        /// </summary>
        /// <param name="second"></param>
        /// <returns></returns>
        public StringBuilderWithLineCount Append(StringBuilderWithLineCount second)
        {
            if (second == null) return this; 

            LineCount += second.LineCount;
            strBuild.Append(second.ToString());
            return this;
        }

        /// <summary>
        /// Finds last occurrence of NewLine in the StringBuilder and inserts "in place" formFeed character before it. 
        /// </summary>
        /// <param name="strToInsert"></param>
        /// <returns></returns>
        public StringBuilderWithLineCount InsertBeforeLastNewLine(string strToInsert)
        {
            if (String.IsNullOrEmpty(strToInsert)) { return this; }
            int lastIndex = strBuild.ToString().LastIndexOf(Environment.NewLine); // last index of NewLine
            if (lastIndex < 0) { return this; } 

            strBuild = strBuild.Replace(Environment.NewLine, strToInsert + Environment.NewLine, lastIndex, Environment.NewLine.Length);
            LineCount += strToInsert.Count(c => c == '\n');

            return this;
        }

        /// <summary>
        /// Replaces "in place" last occurrence of the specified string '<paramref name="oldValue"/>' in the StringBuilderWithLineCount
        /// with the specified string '<paramref name="newValue"/>'
        /// </summary>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        /// <returns></returns>
        public void ReplaceLastOccurrence(string oldValue, string newValue)
        {
            if (String.IsNullOrEmpty(oldValue)) { return; }
            int lastIndex = strBuild.ToString().LastIndexOf(oldValue);
            if (lastIndex < 0) { return; } // do nothing if the old string was not found

            strBuild = strBuild.Replace(oldValue, newValue, lastIndex, oldValue.Length);
            LineCount -= oldValue.Count(c => c == '\n');
            LineCount += newValue.Count(c => c == '\n');
        }

        public override string ToString()
        {
            return strBuild.ToString();
        }
    }  // end class StringBuilderWithLineCount
}
