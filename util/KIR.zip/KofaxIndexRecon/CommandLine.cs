﻿using System;
using System.Reflection;
using log4net;
using log4net.Config;

namespace KofaxIndexRecon
{
    class CommandLine
    {
        private static readonly ILog log = LogManager.GetLogger(typeof(CommandLine));

        static void Main(string[] args)
        {
            // setup logger
            XmlConfigurator.Configure();

            //string ReconDate = "";
            
           
            if (args.Length == 0 || args.Length > 1)
            {
                DisplayHelpFile();
            }
            else
            {
                log.Info(Environment.NewLine + $"\t\t **** Kofax Index Reconciliation  v.{Assembly.GetExecutingAssembly().GetName().Version.ToString()} ****" );                          
             
                switch (args[0])
                {
                    case "-h":
                        DisplayHelpFile();
                        break;

                    case "-n":
                        NightlyRecon nightlyRecon = new NightlyRecon();
                        nightlyRecon.StartRecon();
                        break;

                    case "-w":
                        WeeklyRecon weeklyRecon = new WeeklyRecon();
                        weeklyRecon.StartRecon();
                        break;

                    //  Delete me after test. Testing config form
                    //case "-i":
                    //    String confFile = Assembly.GetEntryAssembly().Location;
                    //    confFile = confFile + ".config";
                    //    ConfigurationForm frmDB = new ConfigurationForm(confFile);
                    //    frmDB.ShowDialog();
                    //    break;

                    default:
                        Console.WriteLine("Invalid command line parameter.  Please retype the command.\n");
                        DisplayHelpFile();
                        log.Error("Invalid command line parameter.");
                        break;
                }
            }

        }


        static void DisplayHelpFile()
        {
            string helpMessage = "The command syntax is as follows: \n";
            helpMessage += "\t" + "KofaxIndexRecon.exe -n \n\n";
            helpMessage += "To run the tool the command line switches are as follows: \n\n";
            helpMessage += "\t" + "-h" + "\t\t" + "Displays this help screen.\n";
            helpMessage += "\t" + "-n" + "\t\t" + "Designates that the nightly procedure will be run.\n";
            helpMessage += "\t" + "-w" + "\t\t" + "Designates that the weekly procedure will be run.\n";
            helpMessage += "\t\t\n\n";

            Console.WriteLine(helpMessage);
        }

    }
}
