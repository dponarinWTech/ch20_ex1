USE [TowerDBKIR]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE SCHEMA tower

CREATE TABLE [tower].[memdoc](
	[npages] [int] NULL,
	[ifnds] [int] NULL,
	[ifnid] [int] NULL,
	[dtype] [varchar](20) NULL,
	[account] [varchar](20) NULL,
	[instnum] [varchar](3) NULL,
	[ssn] [varchar](11) NULL,
	[docdate] [datetime] NULL,
	[slevel] [int] NULL,
	[comment] [varchar](40) NULL,
	[wiid] [int] NULL,
	[timestmp] [int] NULL,
	[uname] [varchar](20) NULL,
	[currentq] [int] NULL,
	[status] [varchar](1) NULL,
	[spstring] [varchar](20) NULL,
	[spnum] [int] NULL,
	[spdate] [datetime] NULL,
	[timeout] [int] NULL,
	[priority] [varchar](20) NULL,
	[ctype] [varchar](20) NULL,
	[accttype] [varchar](20) NULL,
	[appid] [varchar](11) NULL,
	[spstr2] [varchar](20) NULL,
	[spstr3] [varchar](20) NULL,
	[spstr4] [varchar](20) NULL,
	[spstr5] [varchar](80) NULL,
	[spnum2] [int] NULL,
	[spnum3] [int] NULL,
	[spdate2] [datetime] NULL,
	[towid] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
 CONSTRAINT [PK_towid] PRIMARY KEY CLUSTERED 
(
	[towid] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING ON
GO


