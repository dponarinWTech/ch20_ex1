USE [Kofax_FormInfoKIR]
GO

-- NOTE: Update "Domain"  AND  "UserID" for target environment
-- These changes are valid for three applications - 
--	1 - Kofax Index Recon - Nightly and weekly process
-- 	2 - Kofax Index Recon User Interface (UI)
--  3 - Kofax UID Batch class

CREATE LOGIN [DEVNCSECU\svc-dkfx-process] FROM WINDOWS WITH DEFAULT_DATABASE=[Kofax_FormInfoKIR], DEFAULT_LANGUAGE=[us_english]
GO