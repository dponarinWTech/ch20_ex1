USE [Kofax_FormInfoKIR]
GO

IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE NAME = 'DEVNCSECU\svc-dkfx-process')
	CREATE USER [DEVNCSECU\svc-dkfx-process]  FOR LOGIN [DEVNCSECU\svc-dkfx-process] WITH DEFAULT_SCHEMA=[dbo]
GO

-- Permissions for database Tables
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.FormInfo TO [DEVNCSECU\svc-dkfx-process]
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.ExecutionHistory TO [DEVNCSECU\svc-dkfx-process]
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.FormIDs_To_Process TO [DEVNCSECU\svc-dkfx-process]
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.Tower_MemdocRecords TO [DEVNCSECU\svc-dkfx-process]
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.BranchScanReport TO [DEVNCSECU\svc-dkfx-process]
GRANT SELECT, UPDATE, DELETE, INSERT, ALTER ON dbo.MargoFormErrorReport TO [DEVNCSECU\svc-dkfx-process]

-- Permissions for database stored procedures
GRANT EXECUTE ON KfxIndxRcon_SelectRecFromKofaxInfo TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON KfxIndxRcon_UpdtRecScannedButMissingInTower TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON KfxIndxRcon_UpdateFormInfoTable TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON KfxIndxRcon_UpdtRecNotScanned TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON KfxIndxRcon_WklyBranchScan TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON KfxIndxRcon_WklyRpt_MargoFormError TO [DEVNCSECU\svc-dkfx-process]
GRANT EXECUTE ON KfxIndxRcon_TruncateTables TO [DEVNCSECU\svc-dkfx-process]

GO