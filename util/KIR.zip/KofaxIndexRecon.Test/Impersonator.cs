﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;  //For DLLImport call below
using System.Security;
using System.Security.Permissions;
using System.Security.Principal;

namespace KofaxIndexRecon.Test
{
    /// <summary>
    /// Obtained from article "CSharp C# Impersonation Simple Example"
    /// http://chriskonigesminicoding.blogspot.com/2013/07/csharp-c-impersonation-simple-example.html 
    /// 
    /// Usage pattern:
    /// 
    ///         private Impersonator impersonator;
    ///         if (!impersonator.ImpersonateTestUser(domain, name, password))
    ///         {
    ///             // some code to notify about Impersonator failure
    ///         }
    ///         
    ///         ...
    ///         // code to run under impersonated identity
    ///         ...
    ///         
    ///         impersonator.SwitchToOriginalUser();  // undo impersonation
    ///         
    /// </summary>
    class Impersonator
    {
        public WindowsIdentity newId = null;
        public WindowsIdentity originalId = null;
        private SafeTokenHandle safeTokenHandle = null;
        private WindowsImpersonationContext impersonatedUser;

        [DllImport("advapi32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        public static extern bool LogonUser(String lpszUsername, String lpszDomain, String lpszPassword, 
            int dwLogonType, int dwLogonProvider, out SafeTokenHandle phToken);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        public extern static bool CloseHandle(IntPtr handle);

        [PermissionSetAttribute(SecurityAction.Demand, Name = "FullTrust")]
        public void SwitchToOriginalUser()
        {
            if (originalId == null)
            {
                throw new Exception("Original user must be set up first with call to ImpersonateTestUser!");
            }
            else
            {
                ImpersonateUserNow(originalId);
            }
        }

        [PermissionSetAttribute(SecurityAction.Demand, Name = "FullTrust")]
        public bool ImpersonateTestUser(string userDomainNameNow, string userNameNow, string userPasswordNow)
        {
            try
            {
                const int LOGON32_PROVIDER_DEFAULT = 0;
                //This parameter causes LogonUser to create a primary token. 
                const int LOGON32_LOGON_INTERACTIVE = 2;

                // Call LogonUser to obtain a handle to an access token. 
                bool returnValue = LogonUser(userNameNow, userDomainNameNow, userPasswordNow,
                    LOGON32_LOGON_INTERACTIVE, LOGON32_PROVIDER_DEFAULT,
                    out safeTokenHandle);

                Console.WriteLine("LogonUser called: {0}\\{1}", userDomainNameNow, userNameNow);

                if (false == returnValue)
                {
                    int ret = Marshal.GetLastWin32Error();
                    Console.WriteLine("LogonUser failed with error code : {0}", ret);
                    throw new System.ComponentModel.Win32Exception(ret);
                }


                originalId = WindowsIdentity.GetCurrent();
                newId = new WindowsIdentity(safeTokenHandle.DangerousGetHandle());
                WindowsImpersonationContext impersonatedUser = newId.Impersonate();

            }
            catch (Exception ex)
            {
                Console.WriteLine("Impersonator exception occurred. " + ex.Message);
                return false;
            }
            return true;
        }

        public bool ImpersonateUserNow(WindowsIdentity userNow)
        {
            impersonatedUser = userNow.Impersonate();
            return true;
        }

        public string CurrenttWindowsIdentity()
        {
            return WindowsIdentity.GetCurrent().Name;
        }

        public void JustRevertToOriginalUser()
        {
            impersonatedUser.Undo();
        }
    }


    public sealed class SafeTokenHandle : SafeHandleZeroOrMinusOneIsInvalid
    {
        private SafeTokenHandle()
            : base(true)
        {
        }

        [DllImport("kernel32.dll")]
        [ReliabilityContract(Consistency.WillNotCorruptState, Cer.Success)]
        [SuppressUnmanagedCodeSecurity]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool CloseHandle(IntPtr handle);

        protected override bool ReleaseHandle()
        {
            return CloseHandle(handle);
        }
    }

}
