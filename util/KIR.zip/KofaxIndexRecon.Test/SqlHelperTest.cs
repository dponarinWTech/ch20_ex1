﻿using System;
using NUnit.Framework;
using log4net;
using Rhino.Mocks;
using System.Data.SqlClient;
using System.IO;

using Microsoft.SqlServer.Management.Common;
using Microsoft.SqlServer.Management.Smo;

//using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace KofaxIndexRecon.Test
{
    [TestFixture]
    class SqlHelperTest
    {
        private log4net.ILog _mockLog;
        private SqlHelper sqlHelper;
        private SqlConnection kofaxConnectionTest;
        private SqlConnection towerConnectionTest;
        private string spacer = " :( ";
        private Impersonator impersonator;

        [OneTimeSetUp]
        public void Setup()
        {
            // it does not write to log file when we run Unit tests, so we mock the logger to be able to check
            // that it was called and which text was sent to it
            _mockLog = MockRepository.GenerateStub<log4net.ILog>();

            sqlHelper = new SqlHelper(_mockLog, spacer);
            impersonator = new Impersonator();
        }

        // Using current user's permissions execute scripts that drop DB permissions for Service Account
        internal string RemoveServiceAccountDBPermissions()
        {
            try
            {
                string script = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\DropLogin.sql"));

                kofaxConnectionTest = sqlHelper.SetupConnection(DBSelector.Kofax, Properties.Settings.Default.KofaxConnectionString);
                Server server = new Server(new ServerConnection(kofaxConnectionTest));
                server.ConnectionContext.ExecuteNonQuery(script);

                script = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\DropUserKofax.sql"));
                script = script.Replace("USE [Kofax_FormInfo]", "USE [Kofax_FormInfoKIR]");
                server.ConnectionContext.ExecuteNonQuery(script);

                script = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\DropUserTower.sql"));
                script = script.Replace("USE [TowerDB]", "USE [TowerDBKIR]");

                towerConnectionTest = sqlHelper.SetupConnection(DBSelector.Tower, Properties.Settings.Default.TowerConnectionString);
                server = new Server(new ServerConnection(towerConnectionTest));
                server.ConnectionContext.ExecuteNonQuery(script);

                return string.Empty;
            }
            catch(Exception ex)
            {
                if (kofaxConnectionTest != null && kofaxConnectionTest.State == System.Data.ConnectionState.Open)
                {
                    kofaxConnectionTest.Close();
                }
                if (towerConnectionTest != null && towerConnectionTest.State == System.Data.ConnectionState.Open)
                {
                    towerConnectionTest.Close();
                }
                return ex.Message;
            }
        }

        // Run scripts (from External folder) that grant DB permissions to Service Account
        internal string GrantServiceAccountDBPermissions()
        {
            try
            {
                if(kofaxConnectionTest == null || kofaxConnectionTest.State == System.Data.ConnectionState.Closed)
                {
                    kofaxConnectionTest = sqlHelper.SetupConnection(DBSelector.Kofax, Properties.Settings.Default.KofaxConnectionString);
                }
                Server server = new Server(new ServerConnection(kofaxConnectionTest));
                string script = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\Kofax_FormInfoExternal\Create_Kofax_FormInfo_login.sql"));
                script = script.Replace("USE [Kofax_FormInfo]", "USE [Kofax_FormInfoKIR]");
                server.ConnectionContext.ExecuteNonQuery(script);

                script = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\Kofax_FormInfoExternal\Grant_Permissions_Kofax_FormInfo.sql"));
                script = script.Replace("USE [Kofax_FormInfo]", "USE [Kofax_FormInfoKIR]");
                server.ConnectionContext.ExecuteNonQuery(script);

                if (towerConnectionTest.State == System.Data.ConnectionState.Closed)
                {
                    towerConnectionTest = sqlHelper.SetupConnection(DBSelector.Kofax, Properties.Settings.Default.TowerConnectionString);
                }
                server = new Server(new ServerConnection(towerConnectionTest));

                script = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\TowerDBExternal\Create_TowerDB_login.sql"));
                script = script.Replace("USE [TowerDB]", "USE [TowerDBKIR]");
                server.ConnectionContext.ExecuteNonQuery(script);

                script = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\TowerDBExternal\Grant_Permissions_TowerDB.sql"));
                script = script.Replace("USE [TowerDB]", "USE [TowerDBKIR]");
                server.ConnectionContext.ExecuteNonQuery(script);
                return string.Empty;
            }
            catch(Exception ex)
            {
                return ex.Message;
            }
            finally
            {
                if (kofaxConnectionTest != null && kofaxConnectionTest.State == System.Data.ConnectionState.Open)
                {
                    kofaxConnectionTest.Close();
                }
                if (towerConnectionTest != null && towerConnectionTest.State == System.Data.ConnectionState.Open)
                {
                    towerConnectionTest.Close();
                }
            }
        }

        [Test]
        public void Test_SqlHelper_Files_Exist()
        {
            Assert.IsTrue(File.Exists(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\Kofax_FormInfoExternal\Create_Kofax_FormInfo_login.sql")));
            Assert.IsTrue(File.Exists(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\Kofax_FormInfoExternal\Grant_Permissions_Kofax_FormInfo.sql")));
            Assert.IsTrue(File.Exists(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\TowerDBExternal\Create_TowerDB_login.sql")));
            Assert.IsTrue(File.Exists(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\TowerDBExternal\Grant_Permissions_TowerDB.sql")));
            Assert.IsTrue(File.Exists(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\DropLogin.sql")));
            Assert.IsTrue(File.Exists(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\DropUserKofax.sql")));
            Assert.IsTrue(File.Exists(Path.Combine(TestContext.CurrentContext.TestDirectory, @"TestSqlScripts\DropUserTower.sql")));
        }

        [Test]
        public void Test_SqlHelper_SetupConnection_Kofax()
        {
            // reset Servise Account's DB permissions
            Assert.IsEmpty(RemoveServiceAccountDBPermissions());
            Assert.IsEmpty(GrantServiceAccountDBPermissions());

            // open connection under Service Account's credentials
            if (!impersonator.ImpersonateTestUser(Properties.Settings.Default.ServiceAccountDomain,
                                            Properties.Settings.Default.ServiceAccountID,
                                            Properties.Settings.Default.ServiceAccountPassword))
            {
                Assert.IsEmpty("Impersonation failed!");
            }
            else
            {
                kofaxConnectionTest = sqlHelper.SetupConnection(DBSelector.Kofax, Properties.Settings.Default.KofaxConnectionString);
                impersonator.SwitchToOriginalUser();
            }

            Assert.AreEqual(System.Data.ConnectionState.Open, kofaxConnectionTest.State);

            // test that particular message was sent to logger using method Debug()
            _mockLog.AssertWasCalled(l => l.Debug(Arg<string>.Is.Equal(spacer + "SetupConnection - connect to DB Kofax_FormInfo")));

            if (kofaxConnectionTest.State == System.Data.ConnectionState.Open) { kofaxConnectionTest.Close(); }
        }

        [Test]
        public void Test_SqlHelper_SetupConnection_Tower()
        {
            // reset Servise Account's DB permissions
            Assert.IsEmpty(RemoveServiceAccountDBPermissions());
            Assert.IsEmpty(GrantServiceAccountDBPermissions());

            // open connection under Service Account's credentials
            if (!impersonator.ImpersonateTestUser(Properties.Settings.Default.ServiceAccountDomain,
                                Properties.Settings.Default.ServiceAccountID,
                                Properties.Settings.Default.ServiceAccountPassword))
            {
                Assert.IsEmpty("Impersonation failed!");
            }
            else
            {
                towerConnectionTest = sqlHelper.SetupConnection(DBSelector.Tower, Properties.Settings.Default.TowerConnectionString);
                impersonator.SwitchToOriginalUser();
            }

            Assert.AreEqual(System.Data.ConnectionState.Open, towerConnectionTest.State);

            // test that particular message was sent to logger using method Debug()
            _mockLog.AssertWasCalled(l => l.Debug(Arg<string>.Is.Equal(spacer + "SetupConnection - connect to DB TowerDB")));

            if (towerConnectionTest.State == System.Data.ConnectionState.Open) { towerConnectionTest.Close(); }
        }

        [Test]
        public void Test_SqlHelper_Impersonator_GetDBUser()
        {
            string userID;
            Assert.IsEmpty(RemoveServiceAccountDBPermissions());
            Assert.IsEmpty(GrantServiceAccountDBPermissions());

            // open connection under Service Account's credentials
            if (!impersonator.ImpersonateTestUser(Properties.Settings.Default.ServiceAccountDomain,
                                Properties.Settings.Default.ServiceAccountID,
                                Properties.Settings.Default.ServiceAccountPassword))
            {
                Assert.IsEmpty("Impersonation failed!");
                return;
            }
            else
            {
                kofaxConnectionTest = sqlHelper.SetupConnection(DBSelector.Kofax, Properties.Settings.Default.KofaxConnectionString);

                Assert.AreEqual(Properties.Settings.Default.ServiceAccountDomain + "\\" + Properties.Settings.Default.ServiceAccountID, 
                                System.Security.Principal.WindowsIdentity.GetCurrent().Name);

                impersonator.SwitchToOriginalUser();
            }

            Microsoft.VisualStudio.TestTools.UnitTesting.PrivateObject privateObjSqlHelper = 
                new Microsoft.VisualStudio.TestTools.UnitTesting.PrivateObject(sqlHelper);

            userID = privateObjSqlHelper.Invoke("GetDBUser", kofaxConnectionTest) as string;

            Assert.AreEqual(Properties.Settings.Default.ServiceAccountDomain + "\\" + Properties.Settings.Default.ServiceAccountID, userID.Trim() );
        }


    }
}
