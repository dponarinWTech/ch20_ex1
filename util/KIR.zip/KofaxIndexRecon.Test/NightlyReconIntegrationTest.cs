﻿using System;
using System.Collections.Generic;
using System.Linq;
using KofaxIndexRecon;
using NUnit.Framework;
using Rhino.Mocks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Assert = NUnit.Framework.Assert;

namespace KofaxIndexRecon.Test
{
    /* **************************************************************************************************************************
     * 
     * This class performs tests against toy databases Kofax_FormInfoKIR and TowerDBKIR on the local SQL Server (see connection 
     * strings in the settings KofaxConnectionString and TowerConnectionString). 
     * 
     * To create these databases run all scripts in the folder \KofaxIndexRecon.Test\Resources\TestDBCreationScripts in the order
     * of their numbers.
     *  -- Note: Database creation scripts, particularly CreateDB_TowerDBKIR.sql, may take several minutes to complete. -- 
     *  
     * **************************************************************************************************************************/
    [TestFixture]
    public class NightlyReconIntegrationTest
    {
        private log4net.ILog _mockLog;
        private NightlyRecon nightlyReconTest;
        private PrivateObject privateObjNightlyRecon;   // PrivateObject to access private fields and methods of NightlyRecon
        private Impersonator impersonator;
        private SqlConnection sqlConnectionKofax;
        private SqlConnection sqlConnectionTower;

        /// <summary>
        /// number of records inserted to 'FormInfo' table
        /// </summary>
        private int numRecordsInFormInfo = 0;    
        /// <summary>
        /// number of records inserted to 'FormIDs_To_Process' table
        /// </summary>
        int numRecordsInFormInfoToProcess = 0;
        /// <summary>
        /// number of records inserted to 'Tower_MemdocRecords' table
        /// </summary>
        private int numRecordsInTowerMemdocRecords = 0;
        /// <summary>
        /// number of records inserted to Tower database, table 'memdoc'
        /// </summary>
        private int numRecordsInTower = 0;
        /// <summary>
        /// UID of record to be updated by SP 'KfxIndxRcon_UpdtRecScannedButMissingInTower' (ScanDate is null AND 
        /// Status is null AND there is no matching rec. in Tower). Expected Status = MISSING, Reason = 'Kofax Index 
        /// Database has the document but it is Missing in Tower Database'.
        /// </summary>
        private string uidScannedNotUpdated = "";

        /// <summary>
        /// Id of record to be updated by SP 'KfxIndxRcon_UpdtRecNotScanned' (ScanDate is null AND Status is null);
        /// expected Status = MISSING, Reason ='ScanDate Empty'
        /// </summary>
        private int idScanDateEmpty = 0;
        List<string> uniqueIds;  // unique Ids from 'FormIDs_To_Process'

        private void PopulateFormInfo(SqlConnection sqlConnKofax, SqlConnection sqlConnTower)
        {
            string oldDate = DateTime.Now.AddDays(-100).ToString("yyyy-MM-dd");

            string xml = GetXml(new string[] { "111111111" }, new string[] { "0001" });
            // Id = 1, Status = null, ScanDate is 100 days back
            // expected final Status = FOUND
            int countTmp = InsertOneRecordKofax(sqlConnKofax, xml, null, null, oldDate);
            InsertOneRecordTower(sqlConnTower, countTmp, "0001", "111111111", oldDate); 
            numRecordsInFormInfoToProcess++; // should get into 'FormIDs_To_Process'
            numRecordsInTowerMemdocRecords++; // should get into 'Tower_MemdocRecords'
            uniqueIds.Add("TST" + countTmp.ToString("D8"));

            xml = GetXml(new string[] { "222222222" }, new string[] { "0002" });
            oldDate = DateTime.Now.AddDays(-3).ToString("yyyy-MM-dd");
            // Id = 2, Status = 'Not Found', ScanDate is not null and more than 1 day back, Reason is not null
            // expected final Status = 'Not Found', Reason = null
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, "Not Found", "Some Reason", oldDate); 
            numRecordsInFormInfoToProcess++;
            uniqueIds.Add("TST" + countTmp.ToString("D8"));
            // shouldn't get into TowerDB and 'Tower_MemdocRecords'

            xml = GetXml(new string[] { "333333333" }, new string[] { "0003" });
            // Id = 3, Status = PARTIAL, ScanDate is not null
            // expected final Status = FOUND
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, "PARTIAL", "zzz", oldDate); 
            InsertOneRecordTower(sqlConnTower, countTmp, "0003", "333333333", oldDate);
            numRecordsInFormInfoToProcess++;   // should get into 'FormIDs_To_Process'
            numRecordsInTowerMemdocRecords++;  // should get into 'Tower_MemdocRecords'
            uniqueIds.Add("TST" + countTmp.ToString("D8"));

            xml = GetXml(new string[] { "444444444" }, new string[] { "0004" });
            // Id = 4, Status = 'Not Found', ScanDate is not null
            // expected final Status = FOUND
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, "Not Found", "zzz", oldDate);
            InsertOneRecordTower(sqlConnTower, countTmp, "0004", "444444444", oldDate);
            numRecordsInFormInfoToProcess++; // should get into 'FormIDs_To_Process'
            numRecordsInTowerMemdocRecords++;  // should get into 'Tower_MemdocRecords'
            uniqueIds.Add("TST" + countTmp.ToString("D8"));

            xml = GetXml(new string[] { "555555555" }, new string[] { "0005" });
            // Id = 5, Status is null, ScanDate is null
            // expected final Status = MISSING, Rason = 'ScanDate Empty'
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml);
            InsertOneRecordTower(sqlConnTower, countTmp, "0005", "555555555");
            // shouldn't get into table 'FormIDs_To_Process' hence, though gets into TowerDB wouldn't 
            // get into 'Tower_MemdocRecords'
            idScanDateEmpty = countTmp;

            oldDate = DateTime.Now.AddDays(-100).ToString("yyyy-MM-dd");
            xml = GetXml(new string[] { "666666666" }, new string[] { "0006" });
            // Id = 6, Status = null, ScanDate is 100 days back
            // expected final Status = MISSING, Reason = 'Kofax Index Database has the document but it is Missing in Tower Database'
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, null, null, oldDate);
            numRecordsInFormInfoToProcess++;   // should get into 'FormIDs_To_Process'                                
            uniqueIds.Add("TST" + countTmp.ToString("D8"));
            uidScannedNotUpdated = "TST" + countTmp.ToString("D8");
            // shouldn't get into TowerDB and 'Tower_MemdocRecords'

            oldDate = DateTime.Now.AddDays(-5).ToString("yyyy-MM-dd");
            xml = GetXml(new string[] { "711111111", "722222222"}, new string[] { "0071", "0072" });
            // Id = 7, Status = null, Reason is not null, ScanDate is not null, not all matching records there are in Tower
            // expected final Status = PARTIAL, Reason = 'Missing SSN or Account number, or CreateDate mismatch'
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, null, "some reason", oldDate);
            InsertOneRecordTower(sqlConnTower, countTmp, "0071", "711111111", oldDate);
            InsertOneRecordTower(sqlConnTower, countTmp, "0072", "711111111", oldDate);
            InsertOneRecordTower(sqlConnTower, countTmp, "0072", "722222222", oldDate);
            uniqueIds.Add("TST" + countTmp.ToString("D8"));
            numRecordsInFormInfoToProcess += 4;
            numRecordsInTowerMemdocRecords += 3;

            xml = GetXml(new string[] { "811111111", "822222222" }, new string[] { "0081", "0082" });
            // Id = 8, Status = null, Reason is not null, ScanDate is not null, all matching records there are in Tower
            // expected final Status = FOUND, Reason = null
            countTmp = InsertOneRecordKofax(sqlConnKofax, xml, null, "some reason", oldDate);
            InsertOneRecordTower(sqlConnTower, countTmp, "0081", "811111111", oldDate);
            InsertOneRecordTower(sqlConnTower, countTmp, "0082", "811111111", oldDate);
            InsertOneRecordTower(sqlConnTower, countTmp, "0081", "822222222", oldDate);
            InsertOneRecordTower(sqlConnTower, countTmp, "0082", "822222222", oldDate);
            uniqueIds.Add("TST" + countTmp.ToString("D8"));
            numRecordsInFormInfoToProcess += 4;
            numRecordsInTowerMemdocRecords += 4;
        }

        [OneTimeSetUp]
        public void SetupOnce()
        {
            nightlyReconTest = new NightlyRecon();
            impersonator = new Impersonator();
            _mockLog = MockRepository.GenerateStub<log4net.ILog>();

            privateObjNightlyRecon = new PrivateObject(nightlyReconTest);

            uniqueIds = new List<string>();

            // reset Servise Account's DB permissions
            SqlHelperTest sqlHelperTest = new SqlHelperTest();
            sqlHelperTest.RemoveServiceAccountDBPermissions();
            sqlHelperTest.GrantServiceAccountDBPermissions();

            _mockLog = MockRepository.GenerateStub<log4net.ILog>();

            privateObjNightlyRecon.Invoke("OpenConnections", Properties.Settings.Default.KofaxConnectionString, Properties.Settings.Default.TowerConnectionString);
            sqlConnectionKofax = privateObjNightlyRecon.GetField("kofaxConnection") as SqlConnection;
            sqlConnectionTower = privateObjNightlyRecon.GetField("towerConnection") as SqlConnection;
            TruncateFormInfo(sqlConnectionKofax);
            TruncateTower(sqlConnectionTower);
            TruncateCurrentTables(sqlConnectionKofax, sqlConnectionTower);
            PopulateFormInfo(sqlConnectionKofax, sqlConnectionTower);
        }

        [SetUp]
        public void Setup()
        {
            // impersonate as Service Account before each test
            if (!impersonator.ImpersonateTestUser(Properties.Settings.Default.ServiceAccountDomain,
                    Properties.Settings.Default.ServiceAccountID,
                    Properties.Settings.Default.ServiceAccountPassword))
            {
                throw new Exception("KofaxIndexReconIntegrationTest.Setup() - Impersonator has failed!");
            }

            if (sqlConnectionKofax != null && sqlConnectionKofax.State != System.Data.ConnectionState.Open) { sqlConnectionKofax.Open(); }
            if (sqlConnectionTower != null && sqlConnectionTower.State != System.Data.ConnectionState.Open) { sqlConnectionTower.Open(); }
            TruncateCurrentTables(sqlConnectionKofax, sqlConnectionTower);
        }

        [Test]
        public void OpenConnectionsTest()
        {
            var returnValue = privateObjNightlyRecon.Invoke("OpenConnections", Properties.Settings.Default.KofaxConnectionString, Properties.Settings.Default.TowerConnectionString);
            Assert.AreEqual(true, returnValue);

            Assert.AreEqual(System.Data.ConnectionState.Open, sqlConnectionKofax.State);
            Assert.AreEqual(System.Data.ConnectionState.Open, sqlConnectionTower.State);

            Assert.AreEqual(Properties.Settings.Default.ServiceAccountDomain + "\\" + Properties.Settings.Default.ServiceAccountID,
                System.Security.Principal.WindowsIdentity.GetCurrent().Name);
        }

        [Test]
        public void TruncateTablesTest()
        {

            var returnValue = privateObjNightlyRecon.Invoke("TruncateTables");
            Assert.AreEqual(true, returnValue);

            int count = (int)RunScalarQuery(sqlConnectionKofax, "SELECT COUNT(*) FROM [dbo].[FormIDs_To_Process];");
            Assert.AreEqual(0, count);

            count = (int)RunScalarQuery(sqlConnectionKofax, "SELECT COUNT(*) FROM [dbo].[Tower_MemdocRecords];");
            Assert.AreEqual(0, count);
        }

        [Test]
        public void Populate_FormIDs_To_Process_Test()
        {
            var returnValue = privateObjNightlyRecon.Invoke("Populate_FormIDs_To_Process");
            Assert.AreEqual(true, returnValue);

            int cnt = (int)RunScalarQuery(sqlConnectionKofax, "SELECT COUNT(*) FROM [dbo].[FormIDs_To_Process]; ");
            Assert.AreEqual(numRecordsInFormInfoToProcess, cnt);
        }

        [Test]
        public void UpdtRecNotScannedTest()
        {
            var returnValue = privateObjNightlyRecon.Invoke("ExecSP", "dbo.KfxIndxRcon_UpdtRecNotScanned", "FormInfo");
            Assert.AreEqual(true, returnValue);

            var status = (string)RunScalarQuery(sqlConnectionKofax, $"SELECT [Status] FROM [dbo].[FormInfo] WHERE [Id] = {idScanDateEmpty}; ");
            Assert.AreEqual("MISSING", status.Trim().ToUpper());

            var reason = (string)RunScalarQuery(sqlConnectionKofax, $"SELECT [Reason] FROM [dbo].[FormInfo] WHERE [Id] = {idScanDateEmpty}; ");
            Assert.AreEqual("SCANDATE EMPTY", reason.Trim().ToUpper());
        }

        [Test]
        public void GetUniqueIDListTest()
        {
            var returnValue = privateObjNightlyRecon.Invoke("TruncateTables");
            Assert.AreEqual(true, returnValue);

            returnValue = privateObjNightlyRecon.Invoke("Populate_FormIDs_To_Process");
            Assert.AreEqual(true, returnValue);

            List<String> listFromDB = (List<String>)privateObjNightlyRecon.Invoke("GetUniqueIDList");
            Assert.IsTrue(uniqueIds.All(s => listFromDB.Contains(s)));
            Assert.AreEqual(uniqueIds.Count, listFromDB.Count);
        }

        [Test]
        public void FetchFromIDMTest()
        {
            var returnValue = privateObjNightlyRecon.Invoke("Populate_FormIDs_To_Process");
            Assert.AreEqual(true, returnValue);

            List<string> listFromDB = (List<string>)privateObjNightlyRecon.Invoke("GetUniqueIDList");
            DataSet dsFromTower = (DataSet)privateObjNightlyRecon.Invoke("FetchFromIDM", listFromDB);
            Assert.IsTrue( dsFromTower.Tables.Contains("Tower_MemdocRecords") );
            Assert.AreEqual(numRecordsInTowerMemdocRecords, dsFromTower.Tables["Tower_MemdocRecords"].Rows.Count);
            Assert.AreEqual(numRecordsInTowerMemdocRecords, dsFromTower.Tables[0].Rows.Count);

            DataTable tbl = dsFromTower.Tables["Tower_MemdocRecords"];
            // check that row with Id = 5 is not in the DataSet
            Assert.IsFalse(tbl.AsEnumerable().Any(row => row.Field<string>("spstr3") == "TST" + idScanDateEmpty.ToString("D8") ));

            // verify rows with Id 1, 3 4 there are in the DataSet
            Assert.IsTrue(tbl.AsEnumerable().Any(row => row.Field<string>("spstr3") == "TST00000001"));
            Assert.IsTrue(tbl.AsEnumerable().Any(row => row.Field<string>("spstr3") == "TST00000003"));
            Assert.IsTrue(tbl.AsEnumerable().Any(row => row.Field<string>("spstr3") == "TST00000004"));
        }

        [Test]
        public void BulkCopyDataSetToKofaxTableTest()
        {
            var returnValue = privateObjNightlyRecon.Invoke("Populate_FormIDs_To_Process");
            Assert.AreEqual(true, returnValue);

            List<string> listFromDB = (List<string>)privateObjNightlyRecon.Invoke("GetUniqueIDList");
            DataSet dsFromTower = (DataSet)privateObjNightlyRecon.Invoke("FetchFromIDM", listFromDB);

            returnValue = privateObjNightlyRecon.Invoke("BulkCopyDataSetToKofaxTable", dsFromTower, "[dbo].[Tower_MemdocRecords]");
            Assert.AreEqual(true, returnValue);
            int count = (int)RunScalarQuery(sqlConnectionKofax, "SELECT COUNT(*) FROM [dbo].[Tower_MemdocRecords];");
            Assert.AreEqual(numRecordsInTowerMemdocRecords, count);
            count = (int)RunScalarQuery(sqlConnectionKofax, "SELECT COUNT(*) FROM [dbo].[Tower_MemdocRecords] WHERE [SpStr3] = 'TST00000001';");
            Assert.AreEqual(1, count);
            count = (int)RunScalarQuery(sqlConnectionKofax, "SELECT COUNT(*) FROM [dbo].[Tower_MemdocRecords] WHERE [SpStr3] = 'TST00000003';");
            Assert.AreEqual(1, count);
            count = (int)RunScalarQuery(sqlConnectionKofax, "SELECT COUNT(*) FROM [dbo].[Tower_MemdocRecords] WHERE [SpStr3] = 'TST00000004';");
            Assert.AreEqual(1, count);
        }

        [Test]
        public void UpdtRecScannedButMissingInTowerTest()
        {
            var returnValue = privateObjNightlyRecon.Invoke("Populate_FormIDs_To_Process");
            Assert.AreEqual(true, returnValue);

            List<string> listFromDB = (List<string>)privateObjNightlyRecon.Invoke("GetUniqueIDList");
            DataSet dsFromTower = (DataSet)privateObjNightlyRecon.Invoke("FetchFromIDM", listFromDB);
            returnValue = privateObjNightlyRecon.Invoke("BulkCopyDataSetToKofaxTable", dsFromTower, "Tower_MemdocRecords");
            Assert.AreEqual(true, returnValue);

            returnValue = privateObjNightlyRecon.Invoke("ExecSP", "dbo.KfxIndxRcon_UpdtRecScannedButMissingInTower", "FormIDs_To_Process");
            Assert.AreEqual(true, returnValue);
            string status = (string)RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uidScannedNotUpdated}';");
            Assert.AreEqual("MISSING-PROCESSED-T", status?.Trim().ToUpper());
            string reason = (string)RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uidScannedNotUpdated}';");
            Assert.AreEqual("Kofax Index Database has the document but it is Missing in Tower Database".ToUpper(), reason?.Trim().ToUpper());
        }

        [Test]
        public void AddTableToDataSetTest()
        {
            var returnValue = privateObjNightlyRecon.Invoke("Populate_FormIDs_To_Process");
            Assert.AreEqual(true, returnValue);

            List<string> listFromDB = (List<string>)privateObjNightlyRecon.Invoke("GetUniqueIDList");
            DataSet ds = (DataSet)privateObjNightlyRecon.Invoke("FetchFromIDM", listFromDB);
            returnValue = privateObjNightlyRecon.Invoke("BulkCopyDataSetToKofaxTable", ds, "[dbo].[Tower_MemdocRecords]");
            Assert.AreEqual(true, returnValue);

            returnValue = privateObjNightlyRecon.Invoke("ExecSP", "dbo.KfxIndxRcon_UpdtRecScannedButMissingInTower", "FormIDs_To_Process");
            Assert.AreEqual(true, returnValue);

            ds = (DataSet)privateObjNightlyRecon.Invoke("AddTableToDataSet", ds);
            Assert.IsNotNull(ds);
            Assert.AreEqual(numRecordsInFormInfoToProcess, ds.Tables["FormIDs_To_Process"].Rows.Count);
        }



        [Test]
        public void AssignStatusesTest()
        {
            var returnValue = privateObjNightlyRecon.Invoke("Populate_FormIDs_To_Process");
            Assert.IsTrue((bool)returnValue);

            List<string> listFromDB = (List<string>)privateObjNightlyRecon.Invoke("GetUniqueIDList");
            DataSet ds = (DataSet)privateObjNightlyRecon.Invoke("FetchFromIDM", listFromDB);
            returnValue = privateObjNightlyRecon.Invoke("BulkCopyDataSetToKofaxTable", ds, "[dbo].[Tower_MemdocRecords]");
            Assert.IsTrue((bool)returnValue);

            returnValue = privateObjNightlyRecon.Invoke("ExecSP", "dbo.KfxIndxRcon_UpdtRecScannedButMissingInTower", "FormIDs_To_Process");
            Assert.IsTrue((bool)returnValue);

            ds = (DataSet)privateObjNightlyRecon.Invoke("AddTableToDataSet", ds);
            Assert.IsNotNull(ds);

            returnValue = privateObjNightlyRecon.Invoke("AssignStatuses", ds, listFromDB);
            Assert.IsTrue((bool)returnValue);

            // test Status and Reason values in DataSet
            string status, reason;
            status = GetRowByUid(ds, 0)?.Field<string>("Status")?.Trim();
            Assert.AreEqual("FOUND", status?.ToUpper());

            status = GetRowByUid(ds, 1)?.Field<string>("Status")?.Trim();
            reason = GetRowByUid(ds, 1)?.Field<string>("Reason")?.Trim();
            Assert.AreEqual("NOT FOUND", status?.ToUpper());
            Assert.IsNull(reason);

            status = GetRowByUid(ds, 2)?.Field<string>("Status")?.Trim();
            reason = GetRowByUid(ds, 2)?.Field<string>("Reason")?.Trim();
            Assert.AreEqual("FOUND", status?.ToUpper());
            Assert.IsNull(reason);

            status = GetRowByUid(ds, 3)?.Field<string>("Status")?.Trim();
            reason = GetRowByUid(ds, 3)?.Field<string>("Reason")?.Trim();
            Assert.AreEqual("FOUND", status?.ToUpper());
            Assert.IsNull(reason);

            // record with SSN="555555555"  should not get into list 'uniqueIds' and wouldn't be processed by AssignStatuses

            status = GetRowByUid(ds, 4)?.Field<string>("Status")?.Trim();
            reason = GetRowByUid(ds, 4)?.Field<string>("Reason")?.Trim();
            Assert.AreEqual("MISSING", status?.ToUpper());
            Assert.AreEqual("Kofax Index Database has the document but it is Missing in Tower Database".ToUpper(), 
                reason?.ToUpper());

            status = GetRowByUid(ds, 5)?.Field<string>("Status")?.Trim();
            reason = GetRowByUid(ds, 5)?.Field<string>("Reason")?.Trim();
            Assert.AreEqual("PARTIAL", status?.ToUpper());
            Assert.AreEqual("Missing SSN or Account number, or CreateDate mismatch".ToUpper(),
                reason?.ToUpper());

            status = GetRowByUid(ds, 6)?.Field<string>("Status")?.Trim();
            reason = GetRowByUid(ds, 6)?.Field<string>("Reason")?.Trim();
            Assert.AreEqual("FOUND", status?.ToUpper());
            Assert.IsNull(reason);
        }

        [Test]
        public void UpdateKofaxTableFromDataSet()
        {
            // run NightlyRecon from the top
            var returnValue = privateObjNightlyRecon.Invoke("Populate_FormIDs_To_Process");
            Assert.IsTrue((bool)returnValue);

            List<string> listFromDB = (List<string>)privateObjNightlyRecon.Invoke("GetUniqueIDList");
            DataSet ds = (DataSet)privateObjNightlyRecon.Invoke("FetchFromIDM", listFromDB);
            returnValue = privateObjNightlyRecon.Invoke("BulkCopyDataSetToKofaxTable", ds, "[dbo].[Tower_MemdocRecords]");
            Assert.IsTrue((bool)returnValue);

            returnValue = privateObjNightlyRecon.Invoke("ExecSP", "dbo.KfxIndxRcon_UpdtRecScannedButMissingInTower", "FormIDs_To_Process");
            Assert.IsTrue((bool)returnValue);

            ds = (DataSet)privateObjNightlyRecon.Invoke("AddTableToDataSet", ds);
            Assert.IsNotNull(ds);

            returnValue = privateObjNightlyRecon.Invoke("AssignStatuses", ds, listFromDB);
            Assert.IsTrue((bool)returnValue);

            returnValue = privateObjNightlyRecon.Invoke("UpdateKofaxTableFromDataSet", ds, "FormIDs_To_Process");
            Assert.IsTrue((bool)returnValue);

            // test records in FormIDs_To_Process table
            var status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[0]}';");
            var reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[0]}';");
            Assert.AreEqual("FOUND", (status as String)?.ToUpper());
            Assert.IsTrue(DBNull.Value.Equals(reason));

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[1]}';");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[1]}';");
            Assert.AreEqual("NOT FOUND", (status as String)?.ToUpper());
            Assert.IsTrue(DBNull.Value.Equals(reason));

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[2]}';");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[2]}';");
            Assert.AreEqual("FOUND", (status as String)?.ToUpper());
            Assert.IsTrue(DBNull.Value.Equals(reason));

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[3]}';");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[3]}';");
            Assert.AreEqual("FOUND", (status as String)?.ToUpper());
            Assert.IsTrue(DBNull.Value.Equals(reason));

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[4]}';");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[4]}';");
            Assert.AreEqual("MISSING", (status as String)?.ToUpper());
            Assert.AreEqual("Kofax Index Database has the document but it is Missing in Tower Database".ToUpper(), 
                (reason as string)?.Trim().ToUpper());

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[5]}';");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[5]}';");
            Assert.AreEqual("PARTIAL", (status as String)?.ToUpper());
            Assert.AreEqual("Missing SSN or Account number, or CreateDate mismatch".ToUpper(), 
                (reason as string)?.Trim().ToUpper());

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[6]}';");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormIDs_To_Process] WHERE [UIDNumber] = '{uniqueIds[6]}';");
            Assert.AreEqual("FOUND", (status as String)?.ToUpper());
            Assert.IsTrue(DBNull.Value.Equals(reason));
        }

        [Test]
        public void WholeTest()
        {
            var returnValue = privateObjNightlyRecon.Invoke("Populate_FormIDs_To_Process");
            Assert.IsTrue((bool)returnValue);

            returnValue = privateObjNightlyRecon.Invoke("ExecSP", "dbo.KfxIndxRcon_UpdtRecNotScanned", "FormInfo");
            Assert.IsTrue((bool)returnValue);

            List<string> listFromDB = (List<string>)privateObjNightlyRecon.Invoke("GetUniqueIDList");
            DataSet ds = (DataSet)privateObjNightlyRecon.Invoke("FetchFromIDM", listFromDB);
            returnValue = privateObjNightlyRecon.Invoke("BulkCopyDataSetToKofaxTable", ds, "[dbo].[Tower_MemdocRecords]");
            Assert.IsTrue((bool)returnValue);

            returnValue = privateObjNightlyRecon.Invoke("ExecSP", "dbo.KfxIndxRcon_UpdtRecScannedButMissingInTower", "FormIDs_To_Process");
            Assert.IsTrue((bool)returnValue);

            ds = (DataSet)privateObjNightlyRecon.Invoke("AddTableToDataSet", ds);
            Assert.IsNotNull(ds);

            returnValue = privateObjNightlyRecon.Invoke("AssignStatuses", ds, listFromDB);
            Assert.IsTrue((bool)returnValue);

            returnValue = privateObjNightlyRecon.Invoke("UpdateKofaxTableFromDataSet", ds, "FormIDs_To_Process");
            Assert.IsTrue((bool)returnValue);

            returnValue = privateObjNightlyRecon.Invoke("ExecSP", "dbo.KfxIndxRcon_UpdateFormInfoTable", "FormInfo");
            Assert.IsTrue((bool)returnValue);

            // test records in FormInfo table
            var status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 1");
            var reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 1");
            Assert.AreEqual("FOUND", (status as String)?.ToUpper());
            Assert.IsTrue(DBNull.Value.Equals(reason));

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 2");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 2");
            Assert.AreEqual("NOT FOUND", (status as String)?.ToUpper());
            Assert.IsTrue(DBNull.Value.Equals(reason));

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 3");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 3");
            Assert.AreEqual("FOUND", (status as String)?.ToUpper());
            Assert.IsTrue(DBNull.Value.Equals(reason));

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 4");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 4");
            Assert.AreEqual("FOUND", (status as String)?.ToUpper());
            Assert.IsTrue(DBNull.Value.Equals(reason));

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 5");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 5");
            Assert.AreEqual("MISSING", (status as String)?.ToUpper());
            Assert.AreEqual("ScanDate Empty".ToUpper(), (reason as string)?.Trim().ToUpper());

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 6");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 6");
            Assert.AreEqual("MISSING", (status as String)?.ToUpper());
            Assert.AreEqual("Kofax Index Database has the document but it is Missing in Tower Database".ToUpper(),
                (reason as string)?.Trim().ToUpper());

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 7");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 7");
            Assert.AreEqual("PARTIAL", (status as String)?.ToUpper());
            Assert.AreEqual("Missing SSN or Account number, or CreateDate mismatch".ToUpper(), 
                (reason as string)?.Trim().ToUpper());

            status = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Status] FROM [dbo].[FormInfo] WHERE [Id] = 8");
            reason = RunScalarQuery(sqlConnectionKofax, $"SELECT TOP 1 [Reason] FROM [dbo].[FormInfo] WHERE [Id] = 8");
            Assert.AreEqual("FOUND", (status as String)?.ToUpper());
            Assert.IsTrue(DBNull.Value.Equals(reason));
        }

        /// <summary>
        /// Returns DataRow from table 'FormIDs_To_Process' in the given DataSet which have UIDNumber equal to
        /// entry in list uniqueIds (filled in PopulateFormInfo) with given index.
        /// </summary>
        /// <param name="ds"></param>
        /// <param name="uidIndexInUidList"></param>
        /// <returns></returns>
        private DataRow GetRowByUid(DataSet ds, int uidIndexInUidList)
        {
            try
            {
                return ds.Tables["FormIDs_To_Process"].AsEnumerable()
                .Where(row => row.Field<string>("UIDNumber")?.Trim() == uniqueIds[uidIndexInUidList]).FirstOrDefault();
            }catch(Exception e)
            {
                throw new Exception($"Exception in method {GetCurrentMethodName()}():  " + e.ToString());
            }
        }


        [TearDown]
        public void TearDown()
        {
            impersonator.SwitchToOriginalUser();

            if (sqlConnectionKofax != null && sqlConnectionKofax.State == System.Data.ConnectionState.Open) { sqlConnectionKofax.Close(); }
            if (sqlConnectionTower != null && sqlConnectionTower.State == System.Data.ConnectionState.Open) { sqlConnectionTower.Close(); }
        }

        [OneTimeTearDown]
        public void TearDownOnce()
        {
            _mockLog = null;
            privateObjNightlyRecon = null;
            impersonator = null;
            nightlyReconTest = null;
        }

        // sql should return single nimeric value convertible to int.
        private object RunScalarQuery(SqlConnection sqlConnection, string query)
        {
            object result = null;
            SqlCommand command = new SqlCommand(query, sqlConnection);

            if (sqlConnection != null && sqlConnection.State != System.Data.ConnectionState.Open) { sqlConnection.Open(); }
            result = command.ExecuteScalar();
            return result;
        }

        private string GetXml(string[] SSNs, string[] Accounts)
        {
            string result = @"<form index=""0""><formtype>TST</formtype><ssnlist>";
            if(SSNs != null)
            {
                foreach(string ssn in SSNs)
                {
                    result += @"<ssn>" + ssn?.Trim() + @"</ssn>";
                }
            }
            result += @"</ssnlist><accountlist>";
            if (Accounts != null)
            {
                foreach (string acc in Accounts)
                {
                    result += @"<account accttype = ""002"">" + acc?.Trim() + @"</account>";
                }
            }
            result += @"</accountlist>  
                             <npages>00000</npages>  
                             <empid>S19788D</empid>  
                             <workstationid>WWSN0227</workstationid>  
                             <instnum>001</instnum>  
                             <branchnum>00021</branchnum>
                             </form>";
            return result;
        }

        private void TruncateCurrentTables(SqlConnection sqlConnKofax, SqlConnection sqlConnTower)
        {
            if (sqlConnKofax != null && sqlConnKofax.State != System.Data.ConnectionState.Open) { sqlConnKofax.Open(); }
            if (sqlConnTower != null && sqlConnTower.State != System.Data.ConnectionState.Open) { sqlConnTower.Open(); }

            List<string> tables = new List<string>() { "[dbo].[FormIDs_To_Process]", "[dbo].[Tower_MemdocRecords]" };
            foreach (string tbl in tables)
            {
                using (SqlCommand command = new SqlCommand($"TRUNCATE TABLE {tbl}", sqlConnKofax))
                {
                    command.ExecuteNonQuery();
                }
            }
        }
        /// <summary>
        /// Trunkates table 'FormInfo' in kofax database
        /// </summary>
        /// <param name="sqlConnKofax"></param>
        private void TruncateFormInfo(SqlConnection sqlConnKofax)
        {
            if (sqlConnKofax != null && sqlConnKofax.State != System.Data.ConnectionState.Open) { sqlConnKofax.Open(); }
            using (SqlCommand command = new SqlCommand($"TRUNCATE TABLE [dbo].[FormInfo]", sqlConnKofax))
            {
                command.ExecuteNonQuery();
            }
        }
        /// <summary>
        /// Truncates table 'memdoc' in TowerDB
        /// Truncates table 'memdoc' in TowerDB
        /// </summary>
        /// <param name="sqlConnTower"></param>
        private void TruncateTower(SqlConnection sqlConnTower)
        {
            if (sqlConnTower != null && sqlConnTower.State != System.Data.ConnectionState.Open) { sqlConnTower.Open(); }
            using (SqlCommand command = new SqlCommand("TRUNCATE TABLE [tower].[memdoc]", sqlConnTower))
            {
                command.ExecuteNonQuery();
            }
        }


        // Sqlconnection is assumed to be open
        private int InsertOneRecordKofax(SqlConnection sqlConnection, string xml, string status = null, string reason = null, string oldDate = null)
        {
            ++numRecordsInFormInfo;

            string sql1 = "INSERT INTO [dbo].[FormInfo]([Id], [FormType], [InfoXml]";
            string sql2 = "VALUES(@count, 'TST', @xml";
            if (status != null)
            {
                sql1 += ", [Status]";
                sql2 += ", @status";
            }
            if (reason != null)
            {
                sql1 += ", [Reason]";
                sql2 += ", @reason";
            }
            if (oldDate != null)
            {
                sql1 += ", [ScanDate], [CreateDate]";
                sql2 += ", @scanDate, @createDate";
            }
            string sql = sql1 + ")" + sql2 + ")";

            using (SqlCommand command = new SqlCommand(sql, sqlConnection))
            {
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = sql;
                command.Parameters.AddWithValue("@count", numRecordsInFormInfo);
                command.Parameters.AddWithValue("@xml", xml);
                if (status != null)
                {
                    command.Parameters.AddWithValue("@status", status);
                }
                if (reason != null)
                {
                    command.Parameters.AddWithValue("@reason", reason);
                }
                if (oldDate != null)
                {
                    command.Parameters.AddWithValue("@scanDate", oldDate);
                    command.Parameters.AddWithValue("@createDate", oldDate);
                }

                command.ExecuteNonQuery();
            }
            return numRecordsInFormInfo;
        }

        // Sqlconnection is assumed to be open
        private void InsertOneRecordTower(SqlConnection sqlConnection, 
                                          int id,
                                          string acc = null, 
                                          string ssn = null, 
                                          string docdate = null)
        {
            String uid = "TST" + id.ToString("D8");
            string sql1 = "INSERT INTO[tower].[memdoc]([spstr3]";
            string sql2 = "VALUES (@uid";
            if(acc != null)
            {
                sql1 += ", [account]";
                sql2 += ", @acc";
            }
            if (ssn != null)
            {
                sql1 += ", [ssn]";
                sql2 += ", @ssn";
            }
            if (docdate != null)
            {
                sql1 += ", [docdate]";
                sql2 += ", @docdate";
            }
            string sql = sql1 + ")" + sql2 + ")";

            using (SqlCommand command = new SqlCommand(sql, sqlConnection))
            {
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = sql;
                command.Parameters.AddWithValue("@uid", uid);
                if(acc != null) { command.Parameters.AddWithValue("@acc", acc); }
                if(ssn != null) { command.Parameters.AddWithValue("@ssn", ssn); }
                if(docdate != null) { command.Parameters.AddWithValue("@docdate", docdate); }

                command.ExecuteNonQuery();
            }
            numRecordsInTower++;
        }

        [MethodImpl(MethodImplOptions.NoInlining)]
        public string GetCurrentMethodName()
        {
            var st = new StackTrace();
            var sf = st.GetFrame(1);

            return sf.GetMethod().Name;
        }

    }
}
