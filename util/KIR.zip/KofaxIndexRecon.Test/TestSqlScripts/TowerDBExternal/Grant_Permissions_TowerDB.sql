USE [TowerDB]
GO

-- NOTE: Update "Domain"  AND  "UserID" for target environment
-- These changes are valid for "Kofax Index Recon - Nightly and weekly process" application

IF NOT EXISTS(SELECT * FROM sys.database_principals WHERE NAME = 'DEVNCSECU\svc-dkfx-process')
	CREATE USER [DEVNCSECU\svc-dkfx-process]  FOR LOGIN [DEVNCSECU\svc-dkfx-process] WITH DEFAULT_SCHEMA=[dbo]
GO

-- Permissions for database tables
GRANT SELECT ON tower.memdoc TO [DEVNCSECU\svc-dkfx-process]

-- Permissions for database stored procedure
GRANT EXECUTE ON dbo.KfxIndxRcon_SelectRecFromTowerMemdoc TO [DEVNCSECU\svc-dkfx-process]

-- Permissions for database "Type"
GRANT EXECUTE ON TYPE::dbo.list_varchar TO [DEVNCSECU\svc-dkfx-process]
GO
