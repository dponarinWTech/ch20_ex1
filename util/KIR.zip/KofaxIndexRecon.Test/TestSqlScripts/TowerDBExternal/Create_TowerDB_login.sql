USE [TowerDB]
GO

-- NOTE: Update "Domain"  AND  "UserID" for target environment
-- These changes are valid for "Kofax Index Recon - Nightly and weekly process" application

CREATE LOGIN [DEVNCSECU\svc-dkfx-process] FROM WINDOWS WITH DEFAULT_DATABASE=[TowerDB], DEFAULT_LANGUAGE=[us_english]
GO
