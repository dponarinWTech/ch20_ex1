USE [Kofax_FormInfo]
GO

-- NOTE: Update "Domain"  AND  "UserID" for target environment
-- These changes are valid for following applications - 
--	1 - Kofax Index Recon - Nightly and weekly process
--  2 - Kofax Margo Branch Scan Report
-- 	3 - Kofax Index Recon User Interface (UI)
--  4 - Kofax UID Batch class

CREATE LOGIN [DEVNCSECU\svc-dkfx-process] FROM WINDOWS WITH DEFAULT_DATABASE=[Kofax_FormInfo], DEFAULT_LANGUAGE=[us_english]
GO

