USE [master]
GO

IF  EXISTS (SELECT * FROM sys.server_principals WHERE name = N'DEVNCSECU\svc-dkfx-process')
    DROP LOGIN [DEVNCSECU\svc-dkfx-process]
GO