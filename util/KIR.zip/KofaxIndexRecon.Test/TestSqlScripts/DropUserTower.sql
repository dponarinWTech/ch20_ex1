USE [TowerDB]
GO

IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'DEVNCSECU\svc-dkfx-process')
   DROP USER [DEVNCSECU\svc-dkfx-process]
GO