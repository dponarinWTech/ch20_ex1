﻿using System;
using System.Collections.Generic;
using NUnit.Framework;
using System.Data;
using Rhino.Mocks;
using System.IO;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestContext = NUnit.Framework.TestContext;
using Assert = NUnit.Framework.Assert;

namespace KofaxIndexRecon.Test
{
    [TestFixture]
    class BranchReportUnitTest
    {
        private BranchReport branchReportObject;
        private log4net.ILog _mockLog;

        private StringBuilderWithLineCount report;
        private DataSet dataSet;
        char formFeed = (char)0x0C;

        [OneTimeSetUp]
        public void SetupOnce()
        {
            _mockLog = MockRepository.GenerateStub<log4net.ILog>();
            report = new StringBuilderWithLineCount();
            dataSet = CreateEmptyDataSet();
        }

        [SetUp]
        public void Setup()
        {
            TruncateTables(ref dataSet);
            report.Clear();
            branchReportObject = new BranchReport(dataSet, "0021", _mockLog);
        }


        [Test]
        public void WriteOneRowFoundTest()
        {
            // add 1st row which produces multiple data lines in the report
            DataRow row = GetRow(dataSet.Tables["BranchScanReport"], "TST00000001", "0021", 0, "FOUND",
                                GetStringList(5, 8), // account list with 5  8-digit accounts
                                GetStringList(7, 9)  /* SSN list with 7   9-digit SSNs */);

            branchReportObject.WriteOneRowFound(ref report, row);
            // assert that header with "PAGE   1" was added
            string text = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"Resources\Header_found_page1_03_04_19_br21.txt"));
            text = text.Replace("03/04/2019", DateTime.Now.ToString("MM/dd/yyyy"));
            Assert.IsTrue( report.ToString().Contains(text.TrimStart()) );
            int lineCount = report.LineCount; // number of lines before insertion of 2nd data row

            // insert 2nd row that will produce 1 data line in the report
            row = GetRow(dataSet.Tables["BranchScanReport"], "TST00000002", "0021", 0, "FOUND", "00000022", "222222222");
            branchReportObject.WriteOneRowFound(ref report, row);
            // assert that exactly 1 row was added
            Assert.AreEqual(lineCount + 1, report.LineCount);            

            // insert dummy data rows until length of 1st page of report is NumberOfLinesPerPageInReport
            row = GetRow(dataSet.Tables["BranchScanReport"], "DUMMY", "0021", 0, "FOUND", "99", "999999999");
            lineCount = report.LineCount;
            for (int i = 0; i < Properties.Settings.Default.NumberOfLinesPerPageInReport - lineCount; ++i)
            {
                branchReportObject.WriteOneRowFound(ref report, row);
            }
            // make sure we haven't completed first page of report by mistake
            Assert.IsFalse(report.ToString().Contains( formFeed.ToString() ));
            Assert.AreEqual(Properties.Settings.Default.NumberOfLinesPerPageInReport, report.LineCount);

            // insert next data row which should go to the second page of report
            row = GetRow(dataSet.Tables["BranchScanReport"], "TST00000003", "0021", 0, "FOUND", "00000033", "333333333");
            branchReportObject.WriteOneRowFound(ref report, row);

            // assert that header with "PAGE  2" was inserted
            Assert.IsTrue(report.ToString().Contains(formFeed.ToString()));
            text = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"Resources\Header_Found_page1_03_04_19_br21.txt"));
            text = text.Replace("03/04/2019", DateTime.Now.ToString("MM/dd/yyyy"));
            text = text.Replace("PAGE   1", "PAGE   2");
            Assert.IsTrue(report.ToString().Contains(text.TrimStart()));
        }

        [Test]
        public void WriteOneRowMissingTest()
        {
            string text = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"Resources\Header_Missing_page1_03_04_19_br21.txt"));
            text = text.Replace("03/04/2019", DateTime.Now.ToString("MM/dd/yyyy"));
            // make sure report is empty initially
            Assert.AreEqual(0, report.LineCount, "Report is not blank initially");

            // add 1 row that produces single line in report
            DataRow row = GetRow(dataSet.Tables["BranchScanReport"], "TST00000000", "0021", 0, "MISSING", GetStringList(1, 8), GetStringList(1, 9));
            branchReportObject.WriteOneRowMissing(ref report, row); 
            // assert that header with "PAGE   1" was added
            Assert.IsTrue(report.ToString().Contains(text.Trim()), "Report with 1 data row does not contain Missing header with 'PAGE   1'");

            // add one row which produces multiple data lines in the report
            row = GetRow(dataSet.Tables["BranchScanReport"], "TST00000001", "0021", 0, "MISSING",
                                GetStringList(5, 8), // account list with 5  8-digit accounts
                                GetStringList(7, 9)  /* SSN list with 7   9-digit SSNs */);
            branchReportObject.WriteOneRowMissing(ref report, row);
            int lineCount = report.LineCount; 

            // insert 2nd row that will produce 1 data line in the report
            row = GetRow(dataSet.Tables["BranchScanReport"], "TST00000002", "0021", 0, "MISSING", "00000022", "222222222");
            branchReportObject.WriteOneRowMissing(ref report, row);
            // assert that exactly 1 row was added
            Assert.AreEqual(lineCount + 1, report.LineCount);

            // insert dummy data rows until length of 1st page of report is NumberOfLinesPerPageInReport
            row = GetRow(dataSet.Tables["BranchScanReport"], "DUMMY", "0021", 0, "FOUND", "99", "999999999");
            lineCount = report.LineCount;
            int i = -1;
            for (i = 0; i < Properties.Settings.Default.NumberOfLinesPerPageInReport - lineCount; ++i)
            {
                branchReportObject.WriteOneRowMissing(ref report, row);
            }
            // make sure we haven't completed first page of report by mistake
            Assert.IsFalse(report.ToString().Contains(formFeed.ToString()));
            Assert.AreEqual(Properties.Settings.Default.NumberOfLinesPerPageInReport, report.LineCount);

            // insert next data row which should go to the second page of report
            row = GetRow(dataSet.Tables["BranchScanReport"], "TST00000003", "0021", 0, "FOUND", "00000033", "333333333");
            branchReportObject.WriteOneRowMissing(ref report, row);

            // assert that header with "PAGE  2" was inserted
            Assert.IsTrue(report.ToString().Contains(formFeed.ToString()));
            text = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"Resources\Header_Missing_page1_03_04_19_br21.txt"));
            text = text.Replace("03/04/2019", DateTime.Now.ToString("MM/dd/yyyy"));
            text = text.Replace("PAGE   1", "PAGE   2");
            Assert.IsTrue(report.ToString().Contains(text.TrimStart()));
        }

        // make data with several branches with Found and Missing data, one branch with Found only data, and one branch with
        // Missing only data. 
        // Make sure for Found branch Found header is there, while missing - not. 
        // Make sure for Missing branch Missing header is there, while found - not.
        [Test]
        public void GetBranchReportTest()
        {
            string FOUND_MESSAGE = "These items have been scanned into the imaging system and can be destroyed";
            string MISSING_MESSAGE = "These items have been created through Margo, but cannot be found in the imaging system";
            int count = 0;

            // Branch 0001 has both Found and Missing records.
            // Some previous versions failed to insert correct page delimiter [FF][CR][LF] between Found and missing parts of branch report if there
            // was exactly 1 Missing record - need to test it
            AddRows("0001", "FOUND", ref count, 6);
            AddRows("0001", "MISSING", ref count, 1);

            // branch 0002 has Found records only
            AddRows("0002", "FOUND", ref count, 9);

            // branch 0003 has Missing records only
            AddRows("0003", "MISSING", ref count, 10);

            // branch 0004 has page break inside multiline row
            AddRows("0004", "FOUND", ref count, 47); 
            AddMultilineRow("0004", "FOUND", ref count, 15);
            AddRows("0004", "FOUND", ref count, 3);
            AddRows("0004", "MISSING", ref count, 45);
            AddMultilineRow("0004", "MISSING", ref count, 15);
            AddRows("0004", "MISSING", ref count, 3);


            // instantiate BranchReport for branch 0001
            branchReportObject = new BranchReport(dataSet, "0001", _mockLog);
            
            report = branchReportObject.GetBranchReport(true); // parameter 'true' signals to make very first line of report blank
            // verify that report for Branch 0001 has both Found and Missing headers
            Assert.IsTrue(report.ToString().Contains(FOUND_MESSAGE), "Report for branch 0001 does not contain Found header");
            Assert.IsTrue(report.ToString().Contains(MISSING_MESSAGE), "Report for branch 0001 does not contain Missing header");
            // verify that BranchReport ends with formFeed followed by NewLine
            string rep = report.ToString();
            Assert.AreEqual(3, rep.Length - rep.LastIndexOf(formFeed + Environment.NewLine),
                "BranchReport for branch 0001 does not end with formFeed followed by NewLine");
            // same test and also checks that there are correct number of page delimiters
            var pages = rep.Split(new string[] { formFeed + Environment.NewLine }, StringSplitOptions.None);
            Assert.AreEqual(3, pages.Length, "Wrong number of pages in branch 0001 (using String.Split with StringSplitOptions.None)");

            // verify that very first line is blank and 1st page has correct number of lines
            var tuple = GetFirstLineAndLineCount(rep);
            Assert.IsTrue(string.IsNullOrEmpty(tuple.firstLine), 
                $"Very first line of report for branch 0001 is not blank. First line: [{tuple.firstLine}]");
            int linesPerPage = Properties.Settings.Default.NumberOfLinesPerPageInReport;
            Assert.AreEqual(tuple.lineCount, linesPerPage, 
                $"On first page of branch 0001 report there are {tuple.lineCount} lines, but expected {linesPerPage} lines");


            // instantiate BranchReport for branch 0002
                branchReportObject = new BranchReport(dataSet, "0002", _mockLog);
            // verify that report for Branch 0002 has Found only header
            report = branchReportObject.GetBranchReport(); // very first line of report in not blank by default
            rep = report.ToString();
            Assert.IsTrue(rep.Contains(FOUND_MESSAGE), "Report for branch 0002 does not contain Found header");
            Assert.IsFalse(rep.Contains(MISSING_MESSAGE), "Report for branch 0002 should not contain Missing header, but it does");
            // verify that very first line is not blank and 1st page has correct number of lines
            tuple = GetFirstLineAndLineCount(rep);
            Assert.IsFalse(string.IsNullOrEmpty(tuple.firstLine), "Very first line of report for branch 0002 is blank.");
            Assert.AreEqual(tuple.lineCount, linesPerPage,
                $"On first page of branch 0002 report there are {tuple.lineCount} lines, but expected {linesPerPage} lines");

            // instantiate BranchReport for branch 0003
            branchReportObject = new BranchReport(dataSet, "0003", _mockLog);
            // verify that report for Branch 0003 has Missing only header
            report = branchReportObject.GetBranchReport();
            Assert.IsFalse(report.ToString().Contains(FOUND_MESSAGE), "Report for branch 0003 should not contain Found header, but it does");
            Assert.IsTrue(report.ToString().Contains(MISSING_MESSAGE), "Report for branch 0003 does not contain Missing header");

            // instantiate BranchReport for branch 0004
            branchReportObject = new BranchReport(dataSet, "0004", _mockLog);
            report = branchReportObject.GetBranchReport();
            // verify that Found report has page delimiter inside multiline row
            var lines = GetAllLinesFromString(report.ToString());
            Assert.True(lines.Count > 2 * linesPerPage, $"Report for branch 0004 has less than {linesPerPage * 2} lines");
            string lastLineOnPage = lines.ElementAt(linesPerPage - 1);
            string subString = lastLineOnPage.Substring(0, 12);
            Assert.True(string.IsNullOrWhiteSpace(subString), "Report for branch 0004: last line on 1st page supposed to be " 
                + "non-first line in multiline row. Offending line: \n" + lastLineOnPage);
            Assert.True(lastLineOnPage.Contains(formFeed.ToString()), 
                "Report for branch 0004: last line on 1st page does not contain formFeed. Offending line: \n" + lastLineOnPage);
            // verify there is page delimiter between found and Missing parts of report
            lastLineOnPage = lines.ElementAt(2 * linesPerPage - 1);
            Assert.True(lastLineOnPage.Contains(formFeed.ToString()),
                "Report for branch 0004: last line on 2nd page does not contain formFeed. Offending line: \n" + lastLineOnPage);
            // verify that Missing report has page delimiter inside multiline row
            lastLineOnPage = lines.ElementAt(3 * linesPerPage - 1);
            subString = lastLineOnPage.Substring(0, 12);
            Assert.True(string.IsNullOrWhiteSpace(subString), "Report for branch 0004: last line on 3rd page supposed to be " + 
                "non-first line in multiline row. Offending line: \n" + lastLineOnPage);
            Assert.True(lastLineOnPage.Contains(formFeed.ToString()),
                "Report for branch 0004: last line on 3rd page does not contain formFeed. Offending line: \n" + lastLineOnPage);

            // instantiate BranchReport for nonexistent branch 0022
            string branchNum = "0022";
            branchReportObject = new BranchReport(dataSet, branchNum, _mockLog);
            Assert.AreEqual(0, branchReportObject.FoundRowCount, $"Report for branch {branchNum} must be blank, but contains some Found records");
            Assert.AreEqual(0, branchReportObject.MissingRowCount, $"Report for branch {branchNum} must be blank, but contains some Missing records");
            report = branchReportObject.GetBranchReport();
            Assert.AreEqual(0, report.LineCount, $"Report for non-existent branch {branchNum} have non-zero number of lines");
            Assert.IsFalse(report.ToString().Contains(FOUND_MESSAGE), $"Report for branch {branchNum} must be blank, but contains Found header");
            Assert.IsFalse(report.ToString().Contains(MISSING_MESSAGE), $"Report for branch {branchNum} must be blank, but contains Missing header");
        }

        /// <summary>
        /// Verifies that fields _foundRows and _missingRows include only records with correct status
        /// </summary>
        [Test]
        public void BranchReportTest()
        {
            int count = 0;

            AddRows("0001", null, ref count, 1);
            AddRows("0001", "Not Found", ref count, 3);
            AddRows("0001", "COMPLETE", ref count, 3);
            AddRows("0001", "PARTIAL", ref count, 4);
            AddRows("0001", "FOUND", ref count, 5);
            AddRows("0001", "MISSING", ref count, 6);

            branchReportObject = new BranchReport(dataSet, "0001", _mockLog);
            Assert.AreEqual(5, branchReportObject.FoundRowCount, "Wrong count of Found records");
            Assert.AreEqual(6, branchReportObject.MissingRowCount, "Wrong count of Missing records");
        }

#region // Helper methods
        private DataRow[] GetFoundFromDataSet(string branch)
        {
            return dataSet.Tables["BranchScanReport"]
                   .Select("Status = 'FOUND' AND BranchNum =" + branch.Trim(), "BranchNum ASC, UniqueID ASC")
                   ?? new DataRow[0];
        }

        private DataRow[] GetMissingFromDataSet(string branch)
        {
            return dataSet.Tables["BranchScanReport"]
                  .Select("Status = 'MISSING'AND BranchNum = " + branch.Trim(), "BranchNum ASC, NumberOfDays DESC, UniqueID ASC")
                  ?? new DataRow[0];
        }

        /// <summary>
        /// Adds to table "BranchScanReport" in dataSet specified number of rows (<paramref name="numOfRows"/>) with
        /// specifies barnch (<paramref name="branch"/>) and specified status (<paramref name="status"/>), each with 
        /// single SSN "999999999" and single Account "000099". UID in the rows are "TST" and number; starting number
        /// is initial value of <paramref name="count"/> + 1.
        /// </summary>
        /// <param name="branch"></param>
        /// <param name="status"></param>
        /// <param name="count"></param>
        /// <param name="numOfRows"></param>
        private void AddRows(string branch, string status, ref int count, int numOfRows)
        {
            DataRow row;
            int i;
            for (i = 1; i <= numOfRows; ++i)
            {
                string uid = "TST" + (count + i).ToString("D8");
                row = GetRow(dataSet.Tables["BranchScanReport"], uid, branch, 0, status, "000099", "999999999");
                dataSet.Tables["BranchScanReport"].Rows.Add(row);
            }
            count += i;
        }

        private void AddMultilineRow(string branch, string status, ref int count, int numOfSSNs)
        {
            count += 1;
            string ssnList = "";
            for (int i = 1; i <= numOfSSNs; ++i)
            {
                ssnList += i.ToString("D9") + "; ";
            }

            ssnList = ssnList.TrimEnd(';', ' ');
            string uid = "TST" + count.ToString("D8");
            DataRow row = GetRow(dataSet.Tables["BranchScanReport"], uid, branch, 0, status, "000099", ssnList);
            dataSet.Tables["BranchScanReport"].Rows.Add(row);
        }

        public static void TruncateTables(ref DataSet ds)
        {
            ds.Tables["MargoFormErrorReport"]?.Rows?.Clear();
            ds.Tables["BranchScanReport"]?.Rows?.Clear();
        }

        public static DataSet CreateEmptyDataSet()
        {
            DataSet ds = new DataSet("testDataSet");
            DataTable tbl1 = ds.Tables.Add("MargoFormErrorReport");
            AddColumns(ref tbl1);

            DataTable tbl2 = ds.Tables.Add("BranchScanReport");
            AddColumns(ref tbl2);

            return ds;
        }

        public static void AddColumns(ref DataTable table)
        {
            DataColumn uid = table.Columns.Add("UniqueID", typeof(string));
            uid.AllowDBNull = false;
            table.Columns.Add("BranchNum", typeof(string));
            table.Columns.Add("EmpID", typeof(string));
            table.Columns.Add("WorkstationID", typeof(string));
            table.Columns.Add("NumberOfDays", typeof(int));
            table.Columns.Add("Status", typeof(string));
            table.Columns.Add("CreateDate", typeof(DateTime));
            table.Columns.Add("AccountList", typeof(string));
            table.Columns.Add("SSNList", typeof(string));
        }

        public static DataRow GetRow(DataTable tbl, string uid, string branch = "0021", int numOfDays = 0, 
                               string status = null, string accList = null, string ssnList = null)
        {
            DataRow row = tbl.NewRow();
            row["UniqueID"] = uid;
            row["BranchNum"] = branch;
            row["EmpID"] = "S12345D";
            row["WorkstationID"] = "WWSN0227";
            row["NumberOfDays"] = numOfDays;
            row["Status"] = status;
            row["CreateDate"] = DateTime.Now.AddDays(-1 * numOfDays).Date;
            row["AccountList"] = accList;
            row["SSNList"] = ssnList;
            return row;
        }

        /// <summary>
        /// Returns string with semicolon-separated generated accounts. 
        /// First parameter: desired number of accounts in the string (maximum 100).
        /// Second parameter determines number of digits in the account (maximum 12)
        /// 
        /// </summary>
        /// <param name="numOfAccounts"></param>
        /// <param name="numOfDigits"></param>
        /// <returns></returns>
        private string GetStringList(int numOfAccounts, int numOfDigits = 9)
        {
            // if invalid numOfDigits received set it to default value 9
            if (numOfDigits <= 0 || numOfDigits > 12) { numOfDigits = 9; }

            string result = "";
            for (int i = 1; i <= Math.Min(numOfAccounts, 100); ++i)
            {
                result += i.ToString("D" + numOfDigits.ToString()) + "; ";
            }
            result = result.TrimEnd(new char[] { ';', ',', '.', ' ' });
            return result;
        }

        public static Stream GenerateStreamFromString(string s)
        {
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            writer.Write(s);
            writer.Flush();
            stream.Position = 0;

            // Don't dispose StreamWriter: it is just a wrapper around the base stream, and doesn't use any resources that need to be disposed;
            // disposing StreamWriter will close the stream that we're returning
            return stream;
        }

        /// <summary>
        /// Returns tuple with first line and number of lines on first page in the string representing a branch report.
        /// Page delimiter is FormFeed.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static (string firstLine, int lineCount) GetFirstLineAndLineCount(string input)
        {
            string formFeedStr = ((char)0x0C).ToString();
            int counter = 1;
            string line1 = string.Empty;
            using (var stream = GenerateStreamFromString(input))
            {
                using (StreamReader reader = new StreamReader(stream))
                {
                    line1 = reader.ReadLine();
                    string tmpLine = string.Empty;
                    if (!line1.Contains(formFeedStr.ToString()))
                    {
                        while (!tmpLine.Contains(formFeedStr.ToString()))
                        {
                            counter++;
                            tmpLine = reader.ReadLine();
                        }
                    }
                }
            }

            return (firstLine: line1, lineCount: counter);
        }

        /// <summary>
        /// Breaks down specified string into lines and returns them (in natural order) as a List.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static List<string> GetAllLinesFromString(string input)
        {
            List<string> result = new List<string>();
            string currentLine;
            using (StringReader strReader = new StringReader(input))
            {
                while ((currentLine = strReader.ReadLine()) != null)
                {
                    result.Add(currentLine);
                }
            }
            return result;
        }


        #endregion // Helper methods

    }

}
