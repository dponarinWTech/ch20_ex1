﻿using System;
using NUnit.Framework;
using Assert = NUnit.Framework.Assert;

namespace KofaxIndexRecon.Test
{
    [TestFixture]
    class ReportUnitTest
    {
        private Report reportObject;

        [OneTimeSetUp]
        public void SetupOnce()
        {
            reportObject = new Report();
        }

        [TestCase(16, "AAAAAAAAA", "AAAAAAAAA; ")]
        [TestCase(16, "AAAAAAAAAAAAAAA", "AAAAAAAAAAAAAAA;")]
        [TestCase(16, null, "")]
        [TestCase(16, "", "")]
        [TestCase(16, "  ", "")]
        public void GetNewLineWithWordTest(int size, string word, string expected)
        {
            string returnValue = reportObject.GetNewLineWithWord(word, size);
            Assert.AreEqual(expected, returnValue);
        }

        [Test]
        public void SplitStringToFormattedArrayTest()
        {
            string original = "111111111;  222222222  ;  333333333 ; 44444444444; 555555555; 666666666; ";
            string[] expected = new string[] { "111111111; 222222222; 333333333;",
                                               "44444444444; 555555555; ",
                                               "666666666"};
            int size = 32;
            string[] returnValue = reportObject.SplitStringToFormattedArray(original, size);
            Assert.AreEqual(expected, returnValue, "test case 1 failed");

            original = "; 111111111;  222222222;  333333333 ; ; 555555555 ";
            //original = " ; 111111111;  222222222;  333333333 ; ; 555555555 "; // uncomment in future versions
            expected = new string[] { "111111111; 222222222; 333333333;", "555555555" };
            returnValue = reportObject.SplitStringToFormattedArray( original, size);
            Assert.AreEqual(expected, returnValue, "test case 2 failed");

            original = "1234 at branch 22"; // make sure such entry treated as one account
            returnValue = reportObject.SplitStringToFormattedArray(original, size);
            Assert.AreEqual(1, returnValue.Length);

            original = String.Empty;
            returnValue = reportObject.SplitStringToFormattedArray(original, size);
            Assert.AreEqual(new string[] { }, returnValue, "failed with empty string input");

            original = null;
            returnValue = reportObject.SplitStringToFormattedArray(original, size);
            Assert.AreEqual(0, returnValue.Length, "failed with null input");
        }

        [Test]
        public void SplitStringToFormattedArrayTest_BadArg()
        {
            string original = "111111111, 2222222222222222222222, 333333333";
            int size = 22;
            string errorMessagePart = "input string exceeds slot size";

            try
            {
                reportObject.SplitStringToFormattedArray( original, size);

                //need this line to make TestCase fail if exception was not thrown
                Assert.Fail("Expected an exception to be thrown, but it was not");
            }
            catch (ArgumentException ex)
            {
                Assert.IsInstanceOf<ArgumentException>(ex);
                Assert.IsTrue(ex.Message.Contains(errorMessagePart));
            }

            original = "111111111, 222222, 33333333333333333333333";
            try
            {
                reportObject.SplitStringToFormattedArray( original, size);

                //need this line to make TestCase fail if exception was not thrown
                NUnit.Framework.Assert.Fail("Expected an exception to be thrown, but it was not");
            }
            catch (ArgumentException ex)
            {
                Assert.IsInstanceOf<ArgumentException>(ex);
                Assert.IsTrue(ex.Message.Contains(errorMessagePart));
            }
        }

        [Test]
        public void TreatNewPageTest()
        {
            char formFeed = (char)0x0C; // form feed character 

            // insert 1 less than NumberOfLinesPerPageInReport lines to report
            int linesPerPage = Properties.Settings.Default.NumberOfLinesPerPageInReport;
            StringBuilderWithLineCount sb = new StringBuilderWithLineCount();
            for(int i = 0; i < linesPerPage - 1; ++i)
            {
                sb.AppendLine($"   --- Line {i+1} ---");
            }

            // check that formFeed and header wouldn't be inserted to such report
            string returnValue = reportObject.TreatNewPage(ref sb, DummyCreateHeader);
            Assert.AreEqual(" ", returnValue, $"Page with (linesPerPage - 1) dummy lines, returns wrong value '{returnValue}' while should be ' '");
            Assert.AreEqual(linesPerPage - 1, sb.LineCount);
            Assert.IsFalse(sb.ToString().Contains("Dummy Header Text"), "Page with (linesPerPage - 1) dummy lines, TreatNewPage() inserted header");
            Assert.IsFalse(sb.ToString().Contains(formFeed.ToString()), "Page with (linesPerPage - 1) dummy lines, TreatNewPage() inserted formFeed");

            // add 1 more line to report and check that now formFeed and header will be added
            sb.AppendLine($"   --- Line {sb.LineCount + 1} ---");
            returnValue = reportObject.TreatNewPage(ref sb, DummyCreateHeader);
            Assert.AreEqual("0", returnValue, $"Page with linesPerPage dummy lines, returns wrong value '{returnValue}' while should be '0'");
            Assert.IsTrue(sb.ToString().Contains("Dummy Header Text"), "Page with linesPerPage dummy lines, TreatNewPage() did not insert header");
            Assert.IsTrue(sb.ToString().Contains("PAGE  2"), "Page with linesPerPage dummy lines, TreatNewPage() did not insert header with 'PAGE  2'");
            Assert.IsTrue(sb.ToString().Contains(formFeed.ToString()), "Page with linesPerPage dummy lines, TreatNewPage() did not insert formFeed");

        }


        private StringBuilderWithLineCount DummyCreateHeader(int currentLineCounter)
        {
            StringBuilderWithLineCount result = new StringBuilderWithLineCount();
            String headerDate = DateTime.Now.ToString("MM/dd/yyyy");
            int pageNumber = currentLineCounter / Properties.Settings.Default.NumberOfLinesPerPageInReport + 1;
            result.AppendLine(String.Format("{0,-3}{1, -45}{2,-75}{3,-6}{4,-4}", "1",
                                  headerDate, "Dummy Header Text", "PAGE", pageNumber));
            result.AppendLine("");

            return result;
        }
    }
}
