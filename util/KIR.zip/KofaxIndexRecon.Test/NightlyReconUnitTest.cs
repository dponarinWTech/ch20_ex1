﻿using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data;
using Assert = NUnit.Framework.Assert;

namespace KofaxIndexRecon.Test
{
    [TestFixture]
    class NightlyReconUnitTest
    {
        private NightlyRecon nightlyReconTest;
        private PrivateObject privateObjNightlyRecon;  // PrivateObject to access private fields and methods of NightlyRecon
        private DataSet ds;
        private List<string> uidList;  
        private int recordCount;
        int uniqueId;

        [OneTimeSetUp]
        public void SetupOnce()
        {
            nightlyReconTest = new NightlyRecon();
            privateObjNightlyRecon = new PrivateObject(nightlyReconTest);

            ds = new DataSet();

            DataTable tblTowerMemdocRecords = ds.Tables.Add("Tower_MemdocRecords");
            DataColumn spstr3 = tblTowerMemdocRecords.Columns.Add("SpStr3", typeof(string));
            spstr3.AllowDBNull = false;
            tblTowerMemdocRecords.Columns.Add("DocDate", typeof(DateTime)); // default value of AllowDBNull is true
            tblTowerMemdocRecords.Columns.Add("Account", typeof(string));
            tblTowerMemdocRecords.Columns.Add("SSN", typeof(string));

            DataTable tblFormIDsToProcess = ds.Tables.Add("FormIDs_To_Process");
            DataColumn id = tblFormIDsToProcess.Columns.Add("Id", typeof(int));
            tblFormIDsToProcess.PrimaryKey = new DataColumn[] { id }; // automatically sets AllowDBNull = false, Unique = true
            DataColumn uidNumber = tblFormIDsToProcess.Columns.Add("UIDNumber", typeof(string));
            uidNumber.AllowDBNull = false;
            DataColumn uid = tblFormIDsToProcess.Columns.Add("UID", typeof(int));
            uid.AllowDBNull = false;
            tblFormIDsToProcess.Columns.Add("SSN", typeof(string));
            tblFormIDsToProcess.Columns.Add("Account", typeof(string));
            tblFormIDsToProcess.Columns.Add("CreateDate", typeof(DateTime));
            tblFormIDsToProcess.Columns.Add("UpdateDate", typeof(DateTime));
            tblFormIDsToProcess.Columns.Add("UpdateBy", typeof(string));
            tblFormIDsToProcess.Columns.Add("ScanDate", typeof(DateTime));
            tblFormIDsToProcess.Columns.Add("Status", typeof(string));
            tblFormIDsToProcess.Columns.Add("Reason", typeof(string));

            uidList = new List<string>();
        }

        [SetUp]
        public void Setup()
        {
            foreach (DataTable tbl in ds.Tables)
            {
                tbl.Rows.Clear();
            }
            uidList.Clear();
            recordCount = 0;
            uniqueId = 1;
        }

        [Test]
        public void IsDocDateBlankTest()
        {
            // record with blank DocDate in table 'Tower_MemdocRecords'
            AddOneRecordKofax(ref recordCount, status: "BLANK", reason: "No reason");
            DataRow row = AddOneRecordTower(recordCount);
            var rows = ds.Tables["Tower_MemdocRecords"].AsEnumerable().Where(r => r.Field<String>("SpStr3") == row.Field<string>("SpStr3"));
            Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("IsDocDateBlank", rows));

            // record with explicit NULL in DocDate in tower
            AddOneRecordKofax(ref recordCount, status: "NULL", reason: "No reason");
            row = AddOneRecordTower(recordCount, null);
            rows = ds.Tables["Tower_MemdocRecords"].AsEnumerable().Where(r => r.Field<String>("SpStr3") == row.Field<string>("SpStr3"));
            Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("IsDocDateBlank", rows));

            // record with non-blank DocDate
            DateTime date = DateTime.Now.AddDays(-3);
            AddOneRecordKofax(ref recordCount, date, date, date, status: "HASDATE", reason: "No reason");
            row = AddOneRecordTower(recordCount, date);
            rows = ds.Tables["Tower_MemdocRecords"].AsEnumerable().Where(r => r.Field<String>("SpStr3") == row.Field<string>("SpStr3"));
            Assert.IsFalse((bool)privateObjNightlyRecon.Invoke("IsDocDateBlank", rows));

            // null argument
            try
            {
                object[] args = new object[] { null };
                privateObjNightlyRecon.Invoke("IsDocDateBlank", args);

                //need this line to make TestCase fail if exception was not thrown
                Assert.Fail("Expected an exception to be thrown, but it was not");
            }
            // PrivateObject wraps our exception in TargetInvocationException, so we need to check InnerException
            catch (System.Reflection.TargetInvocationException ex)
            {
                // verify that InnerException is of the type we expect
                Assert.IsInstanceOf<ArgumentNullException>(ex.InnerException);
            }
        }

        [Test]
        public void UpdateRecordsTest()
        {
            string uid = AddOneRecordKofax(ref recordCount, status: "BLANK", reason: "No reason").Field<string>("UIDNumber");
            var rowsToUpdate = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uid);
            DataRow updatedRow = rowsToUpdate.First();

            // since PrivateObject.Invoke does not pick up default argument values we have to explicitly give all argunet values
            privateObjNightlyRecon.Invoke("UpdateRecords", rowsToUpdate, "UPDATED-1", "Good Reason", null);
            Assert.AreEqual("UPDATED-1", updatedRow["Status"]);
            Assert.AreEqual("Good Reason", updatedRow["Reason"]);
            Assert.IsTrue( DBNull.Value.Equals(updatedRow["UpdateDate"]) );

            privateObjNightlyRecon.Invoke("UpdateRecords", rowsToUpdate, "UPDATED-2", null, null);
            Assert.AreEqual("UPDATED-2", updatedRow["Status"]);
            Assert.AreEqual("Good Reason", updatedRow["Reason"]);
            Assert.IsTrue(DBNull.Value.Equals(updatedRow["UpdateDate"]));

            privateObjNightlyRecon.Invoke("UpdateRecords", rowsToUpdate, "UPDATED-3", String.Empty, null);
            Assert.AreEqual("UPDATED-3", updatedRow["Status"]);
            Assert.IsTrue( DBNull.Value.Equals(updatedRow["Reason"]) );
            Assert.IsTrue(DBNull.Value.Equals(updatedRow["UpdateDate"]));

            DateTime dtNow = DateTime.Now;
            privateObjNightlyRecon.Invoke("UpdateRecords", rowsToUpdate, "UPDATED-4", "No-Reason", dtNow);
            Assert.AreEqual("UPDATED-4", updatedRow["Status"]);
            Assert.AreEqual("No-Reason", updatedRow["Reason"]);
            Assert.AreEqual(dtNow, updatedRow["UpdateDate"]);

            // does not throw exception if rowsToUpdate is null
            Assert.DoesNotThrow(() => privateObjNightlyRecon.Invoke("UpdateRecords", null, "UPDATED-4", "No-Reason", dtNow));
        }


        [Test]
        public void IsFoundAllTestNullArgs()
        {
            RecordTripletEqualityComparer comparer = new RecordTripletEqualityComparer();
            DateTime now = DateTime.Now;
            var rowsKofax = AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "111111111", "222222222" }, new string[] { "000001", "000002" }, createDate: now);
            var rowsTower = AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "111111111", "222222222" }, new string[] { "000001", "000002" }, now);

            // expect false if rowsKofax, or rowsTower, or both is null
            NUnit.Framework.Assert.AreEqual(false, (bool)privateObjNightlyRecon.Invoke("IsFoundAll", null, rowsTower, comparer));
            NUnit.Framework.Assert.AreEqual(false, (bool)privateObjNightlyRecon.Invoke("IsFoundAll", rowsKofax, null, comparer));
            object[] args = new object[] { null, null, comparer };
            NUnit.Framework.Assert.AreEqual(false, (bool)privateObjNightlyRecon.Invoke("IsFoundAll", args));
        }


        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", "0001", "0002", "2019-02-15", "2019-02-15", true)]
        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", "0001", "0002", "2019-02-15 14:35:00", "2019-02-15 10:00:00", true)]
        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", "0001", "0002", "2019-02-15", null, false)]
        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", "0001", "0002", null, "2019-02-15", false)]
        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", null, "0001", "0002", "2019-02-15", "2019-02-15", true)]
        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", "0001", null, "2019-02-15", "2019-02-15", false)]
        [TestCase("111111111", "222222222", "111111111", "222222222", null, null, "0001", "0002", "2019-02-15", "2019-02-15", true)]
        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", null, null, "2019-02-15", "2019-02-15", true)]
        [TestCase("111111111", null, "111111111", "222222222", "0001", "0002", "0001", "0002", "2019-02-15", "2019-02-15", true)]
        [TestCase("111111111", "222222222", "111111111", null, "0001", "0002", "0001", "0002", "2019-02-15", "2019-02-15", false)]
        [TestCase(null, null, "111111111", "222222222", "0001", "0002", "0001", "0002", "2019-02-15", "2019-02-15", true)]
        [TestCase("111111111", "222222222", null, null, "0001", "0002", "0001", "0002", "2019-02-15", "2019-02-15", true)]
        public void IsFoundAllTest(string ssn1, string ssn2, string ssn3, string ssn4, 
                                   string acc1, string acc2, string acc3, string acc4, 
                                   string dt1, string dt2, bool expect)
        {
            RecordTripletEqualityComparer comparer = new RecordTripletEqualityComparer();
            EnumerableRowCollection<DataRow> rowsKofax = AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount,
                                                                                     ListFromArgs(ssn1, ssn2).ToArray(),
                                                                                     ListFromArgs(acc1, acc2).ToArray(),
                                                                                     DateTimeFromString(dt1));

            EnumerableRowCollection<DataRow> rowsTower = AddTowerRecorsdWithManySSNsAndAccounts(recordCount,
                                                                                                ListFromArgs(ssn3, ssn4).ToArray(),
                                                                                                ListFromArgs(acc3, acc4).ToArray(),
                                                                                                DateTimeFromString(dt2));
            NUnit.Framework.Assert.AreEqual(expect, (bool)privateObjNightlyRecon.Invoke("IsFoundAll", rowsKofax, rowsTower, comparer));
        }

        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", "0001", "0002", "2019-02-15", "2019-02-15", true)]
        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", "0001", "0002", "2019-02-15 14:35:00", "2019-02-15 10:00:00", true)]
        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", "0001", "0002", "2019-02-15", "", false)]
        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", "0001", "0002", null, "2019-02-15", false)]
        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", "0001", null, "2019-02-15", "2019-02-15", true)]
        [TestCase("111111111", "222222222", "111111111", "222222222", "0001", "0002", null, null, "2019-02-15", "2019-02-15", true)]
        [TestCase("111111111", null, "111111111", "222222222", "0001", "0002", "0001", "0002", "2019-02-15", "2019-02-15", true)]
        [TestCase(null, null, "111111111", "222222222", "0001", "0002", "0001", "0002", "2019-02-15", "2019-02-15", true)]
        [TestCase("111111111", "333333333", "111111111", "222222222", "0009", "0008", "0007", "0008", "2019-02-15", "2019-02-15", true)]
        public void IsFoundAnyTest(string ssn1, string ssn2, string ssn3, string ssn4, 
                                   string acc1, string acc2, string acc3, string acc4, 
                                   string dt1, string dt2, bool expect)
        {
            RecordTripletEqualityComparer comparer = new RecordTripletEqualityComparer();
            EnumerableRowCollection<DataRow>  rowsKofax = AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, 
                                                                                                 ListFromArgs(ssn1, ssn2).ToArray(), 
                                                                                                 ListFromArgs(acc1, acc2).ToArray(),
                                                                                                 DateTimeFromString(dt1));

            EnumerableRowCollection<DataRow> rowsTower = AddTowerRecorsdWithManySSNsAndAccounts(recordCount, 
                                                                                                ListFromArgs(ssn3, ssn4).ToArray(), 
                                                                                                ListFromArgs(acc3, acc4).ToArray(),
                                                                                                DateTimeFromString(dt2));

            NUnit.Framework.Assert.AreEqual(expect, (bool)privateObjNightlyRecon.Invoke("IsFoundAny", rowsKofax, rowsTower, comparer));
        }
        [Test]
        public void IsFoundAnyTestNullArgs()
        {
            RecordTripletEqualityComparer comparer = new RecordTripletEqualityComparer();
            var rowsKofax = AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] {"111111111", "222222222"}, new string[] { "000001", "000002" }, createDate: DateTime.Now);
            var rowsTower = AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] {"111111111", "222222222"}, new string[] { "000001", "000002" }, DateTime.Now);
            NUnit.Framework.Assert.AreEqual(false, (bool)privateObjNightlyRecon.Invoke("IsFoundAll", rowsKofax, null, comparer));
            NUnit.Framework.Assert.AreEqual(false, (bool)privateObjNightlyRecon.Invoke("IsFoundAll", null, rowsTower, comparer));
            object[] args = new object[] {null, null, comparer};
            NUnit.Framework.Assert.AreEqual(false, (bool)privateObjNightlyRecon.Invoke("IsFoundAll", args));
        }

        [TestCase(" Missing ", true)]
        [TestCase("MISSING", true)]
        [TestCase("found", false)]
        [TestCase("  not found ", true)]
        [TestCase("", false)]
        [TestCase(null, false)]
        public void IsSatusInListTest(string status, bool expectedValue)
        {
            DateTime dt = DateTime.Now.AddDays(-1);
            EnumerableRowCollection<DataRow> rowsKofax = AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, 
                                                                                                new string[] { "111111111" }, 
                                                                                                new string[] { "0111" },
                                                                                                dt, dt, dt, 
                                                                                                status);
            // add second record with same uid and different status
            --recordCount;
            rowsKofax = AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount,
                                                                                    new string[] { "222222222" },
                                                                                    new string[] { "0222" },
                                                                                    dt, dt, dt,
                                                                                    "Lost Cause");
            NUnit.Framework.Assert.AreEqual(2, rowsKofax.Count());
            NUnit.Framework.Assert.AreEqual(expectedValue, (bool)privateObjNightlyRecon.Invoke("IsSatusInList", rowsKofax, "missing", "NOT Found"));
        }

        [Test]
        public void IsSatusInListTestNullArgs()
        {
            DateTime dt = DateTime.Now;
            EnumerableRowCollection<DataRow> rowsKofax = AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount,
                                                                                                new string[] { "111111111" },
                                                                                                new string[] { "0111" },
                                                                                                dt, dt, dt,
                                                                                                "COMPLETED");

            NUnit.Framework.Assert.AreEqual(false, (bool)privateObjNightlyRecon.Invoke("IsSatusInList", rowsKofax, null));
            NUnit.Framework.Assert.AreEqual(false, (bool)privateObjNightlyRecon.Invoke("IsSatusInList", null, "missing", "NOT Found"));
        }

        [Test]
        public void AreDBDateTimesEqualTest()
        {
            // Null in Kofax table, not null in Tower
            DataRow rowKofax = AddOneRecordKofax(ref recordCount, status: "BLANK", reason: "No reason");
            DateTime dt = DateTime.Now.AddDays(-3);
            DataRow rowTower = AddOneRecordTower(recordCount, dt);

            var returnVal = privateObjNightlyRecon.Invoke("AreDBDateTimesEqual", rowKofax, "CreateDate", rowTower, "DocDate");
            NUnit.Framework.Assert.AreEqual(false, returnVal);

            // not null in Kofax, null in Tower
            rowKofax = AddOneRecordKofax(ref recordCount, dt, dt, dt, status: "BLANK", reason: "No reason");
            rowTower = AddOneRecordTower(recordCount);
            returnVal = privateObjNightlyRecon.Invoke("AreDBDateTimesEqual", rowKofax, "CreateDate", rowTower, "DocDate");
            NUnit.Framework.Assert.AreEqual(false, returnVal);

            // nulls in both tables
            rowKofax = AddOneRecordKofax(ref recordCount, status: "BLANK", reason: "No reason");
            rowTower = AddOneRecordTower(recordCount);
            returnVal = privateObjNightlyRecon.Invoke("AreDBDateTimesEqual", rowKofax, "CreateDate", rowTower, "DocDate");
            NUnit.Framework.Assert.AreEqual(false, returnVal);

            // same date in both tables (in Kofax - with time, in Tower - without)
            rowKofax = AddOneRecordKofax(ref recordCount, dt, dt, dt, status: "BLANK", reason: "No reason");
            rowTower = AddOneRecordTower(recordCount, dt);
            NUnit.Framework.Assert.AreNotEqual(rowKofax.Field<DateTime>("CreateDate"), rowTower.Field<DateTime>("DocDate"));
            returnVal = privateObjNightlyRecon.Invoke("AreDBDateTimesEqual", rowKofax, "CreateDate", rowTower, "DocDate");
            NUnit.Framework.Assert.AreEqual(true, returnVal);

            // different dates
            rowKofax = AddOneRecordKofax(ref recordCount, dt, dt, dt, status: "BLANK", reason: "No reason");
            dt = DateTime.Now.AddDays(-5);
            rowTower = AddOneRecordTower(recordCount, dt);
            returnVal = privateObjNightlyRecon.Invoke("AreDBDateTimesEqual", rowKofax, "CreateDate", rowTower, "DocDate");
            NUnit.Framework.Assert.AreEqual(false, returnVal);

        }

        [TestCase( "CreateDate", "DocDate", true, false)]
        [TestCase("CreateDate", "DocDate", false, true)]
        [TestCase(null, "DocDate", false, false)]
        [TestCase("CreateDate", null, false, false)]
        [TestCase(null, null, true, true)]
        public void AreDBDateTimesEqualTestNullArgs(string fieldNameKofax, string fieldNameTower, bool rowKofaxNull, bool rowTowerNull)
        {
            DateTime dt = DateTime.Now;
            DataRow rowKofax = rowKofaxNull ? null : AddOneRecordKofax(ref recordCount, dt, dt, dt, status: "BLANK", reason: "No reason");
            DataRow rowTower = rowTowerNull ? null : AddOneRecordTower(recordCount, dt);

            try
            {
                privateObjNightlyRecon.Invoke("AreDBDateTimesEqual", rowKofax, fieldNameKofax, rowTower, fieldNameTower); 

                //need this line to make TestCase fail if exception was not thrown
                NUnit.Framework.Assert.Fail("Expected an exception to be thrown, but it was not"); 
            }
            // PrivateObject wraps our exception with TargetInvocationException
            catch (System.Reflection.TargetInvocationException ex)
            {
                // verify that InnerException is of the type we expect
                NUnit.Framework.Assert.IsInstanceOf<ArgumentNullException>(ex.InnerException);
            }
        }

        [TestCase(null, null, null, null, false)]  // all dates are null
        [TestCase(null, "0", null, null, false)]  // one Kofax date is not null, all other dates are null
        [TestCase(null, null, "1", null, false)]  // one Tower date is not null, all other dates are null
        [TestCase("1", "1", "1", null, false)]    // one Tower date is null, all other dates are the same
        [TestCase("-2", null, "-2", null, false)]  // one of dates is not null in both Kofax and Tower
        [TestCase("1", "1", "1", "1", true)]     // equal dates
        [TestCase("-1", "0", "0", "0", false)]   // one of dates is different from others
        [TestCase("1", "1", "1", "0", false)]
        public void AreScanDatesMatchTest(string dtKofax1, string dtKofax2, string dtTower1, string dtTower2, bool expect)
        {
            int days = 0;
            DateTime? dtKof1, dtKof2, dtTow1, dtTow2;
            if (Int32.TryParse(dtKofax1, out days)) { dtKof1 = DateTime.Now.AddDays(days); }
            else { dtKof1 = null; }
            if (Int32.TryParse(dtKofax2, out days)) { dtKof2 = DateTime.Now.AddDays(days); }
            else { dtKof2 = null; }
            if (Int32.TryParse(dtTower1, out days)) { dtTow1 = DateTime.Now.AddDays(days); }
            else { dtTow1 = null; }
            if (Int32.TryParse(dtTower2, out days)) { dtTow2 = DateTime.Now.AddDays(days); }
            else { dtTow2 = null; }

            DataRow row = AddOneRecordKofax(ref recordCount, dtKof1, dtKof1, dtKof1, "BLANK", "No reason");
            AddOneRecordTower(recordCount, dtTow1);
            --recordCount;
            AddOneRecordKofax(ref recordCount, dtKof2, dtKof2, dtKof2, "BLANK", "No reason");
            AddOneRecordTower(recordCount, dtTow2);
            NUnit.Framework.Assert.AreEqual(expect, CallIsScanDateMismatch(row.Field<string>("UIDNumber")));
        }

        [TestCase(true, false)]
        [TestCase(false, true)]
        [TestCase(true, true)]
        public void AreScanDatesMatchTestNullArgs(bool isKofaxNull, bool isTowerNull)
        {
            DateTime dt = DateTime.Now;
            EnumerableRowCollection<DataRow> rowsKofax = isKofaxNull ? null : 
                AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, null, null, dt, dt, dt );
            EnumerableRowCollection<DataRow> rowsTower = isTowerNull ? null : 
                AddTowerRecorsdWithManySSNsAndAccounts(recordCount, null, null, dt);

            AddOneRecordTower(recordCount, dt);
            try
            {
                privateObjNightlyRecon.Invoke("AreScanDatesMatch", rowsKofax, rowsTower);

                //need this line to make TestCase fail if exception was not thrown
                NUnit.Framework.Assert.Fail("Expected an exception to be thrown, but it was not");
            }
            // PrivateObject wraps our exception with TargetInvocationException
            catch (System.Reflection.TargetInvocationException ex)
            {
                // verify that InnerException is of the type we expect
                NUnit.Framework.Assert.IsInstanceOf<ArgumentNullException>(ex.InnerException);
            }
        }

        [TestCase("111111111", "0011", "Not Found", false)]
        [TestCase("111111111", "0011", " Not FounD  ", false)]
        [TestCase("111111111", "0011", null, true)]
        [TestCase("111111111", null, null, true)]
        [TestCase(null, "0011", null, true)]
        [TestCase(null, null, "ZZZ", false)]
        [TestCase(null, null, null, false)]
        [TestCase("111111111", "0011", "Missing", false)]
        [TestCase("111111111", "0011", " MissinG ", false)]
        [TestCase(null, "0011", "AAA", true)]
        [TestCase("111111111", "0011", "Not   Found", true)]
        public void IsStillUnprocessedTest(string ssn, string acc, string status, bool expectedValue)
        {
            DateTime now = DateTime.Now;
            DataRow row = AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] {ssn},
                                                             new string[] {acc}, now, now, now, 
                                                             status).Last();
            NUnit.Framework.Assert.AreEqual(expectedValue, (bool)privateObjNightlyRecon.Invoke("IsStillUnprocessed", row));
        }

        [Test]
        public void IsStillUnprocessedTestNullArg()
        {
            try
            {
                object[] args = new object[] { null };
                privateObjNightlyRecon.Invoke("IsStillUnprocessed", args);

                //need this line to make TestCase fail if exception was not thrown
                NUnit.Framework.Assert.Fail("Expected an exception to be thrown, but it was not");
            }
            // PrivateObject wraps our exception in TargetInvocationException
            catch (System.Reflection.TargetInvocationException ex)
            {
                // verify that InnerException is of the type we expect
                NUnit.Framework.Assert.IsInstanceOf<ArgumentNullException>(ex.InnerException);
            }
        }

        [Test]
        public void AssignStatusesTest_1() // blank 'docdate' in tower in 2nd record - MISSING
        {
            DateTime dt = DateTime.Now;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "111111111" },
                                                   new string[] { "0011" }, dt, dt, dt, "aaa");
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "111111111" }, new string[] { "0011" }, dt);
            --recordCount; // will add one more record with the same UID
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "222222222" },
                                                   new string[] { "0022" }, dt, dt, dt, "aaa");
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "222222222" }, new string[] { "0022" }, null);
            var rows = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidList.Last());
            NUnit.Framework.Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));
            bool allStatuses = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Status")) &&
                                                row.Field<string>("Status").Trim().ToUpper() == "MISSING");
            bool allReasons = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Reason")) &&
                                               row.Field<string>("Reason").Trim().ToUpper() == "NO CREATION DATE FOUND IN TOWER");
            NUnit.Framework.Assert.IsTrue(allStatuses);
            NUnit.Framework.Assert.IsTrue(allReasons);
        }

        [Test]
        public void AssignStatusesTest_2()  // CreateDate mismatch - MISSING
        {
            DateTime dt = DateTime.Now;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "111111111" },
                                       new string[] { "0011" }, dt, dt, dt, "aaa");
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "111111111" }, new string[] { "0011" }, dt.AddDays(-2));
            --recordCount;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "222222222" },
                                                   new string[] { "0022" }, dt, dt, dt, "aaa");
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "222222222" }, new string[] { "0022" }, dt);
            var rows = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidList.Last());
            NUnit.Framework.Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));
            bool allStatuses = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Status")) &&
                                    row.Field<string>("Status").Trim().ToUpper() == "MISSING");
            bool AllReasons = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Reason")) &&
                                               row.Field<string>("Reason").Trim().ToUpper() == "CREATION DATE DOES NOT MATCH.");
            NUnit.Framework.Assert.IsTrue(allStatuses);
            NUnit.Framework.Assert.IsTrue(AllReasons);
        }

        [Test]
        public void AssignStatusesTest_3()  // different time in CreateDate - FOUND
        {
            DateTime dt = DateTime.Now;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, null, new string[] { "0011", "0022" }, dt, dt, dt);
            DateTime newDt = dt.AddHours(1).Date == dt.Date ? dt.AddHours(1) : dt.AddHours(-1);
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, null, new string[] { "0011", "0022" }, newDt);
            var rows = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidList.Last());
            NUnit.Framework.Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));
            bool allStatuses = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Status")) &&
                        row.Field<string>("Status").Trim().ToUpper() == "FOUND");
            NUnit.Framework.Assert.IsTrue(allStatuses);
        }

        [Test]
        public void AssignStatusesTest_4_1()  // SSN mismatch in 2nd record - PARTIAL
        {
            DateTime dt = DateTime.Now;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "111111111" },
                                                   new string[] { "0011" }, dt, dt, dt);
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "111111111" }, new string[] { "0011" }, dt);
            --recordCount;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "222222222" },
                                       new string[] { "0022" }, dt, dt, dt);
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "333333333" }, new string[] { "0022" }, dt);
            NUnit.Framework.Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));
            var rows = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidList.Last());
            bool allStatuses = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Status")) &&
                        row.Field<string>("Status").Trim().ToUpper() == "PARTIAL");
            bool AllReasons = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Reason")) &&
                        row.Field<string>("Reason").Trim().ToUpper() == "Missing SSN or Account number, or CreateDate mismatch".ToUpper());
            NUnit.Framework.Assert.IsTrue(allStatuses);
            NUnit.Framework.Assert.IsTrue(AllReasons);
        }

        [Test]
        public void AssignStatusesTest_4_2()  // Account mismatch in 2nd record - PARTIAL
        {
            DateTime dt = DateTime.Now;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "111111111" },
                                       new string[] { "0011" }, dt, dt, dt);
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "111111111" }, new string[] { "0011" }, dt);
            --recordCount;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "222222222" },
                                       new string[] { "0022" }, dt, dt, dt);
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "222222222" }, new string[] { "0033" }, dt);
            NUnit.Framework.Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));
            var rows = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidList.Last());
            bool allStatuses = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Status")) &&
                        row.Field<string>("Status").Trim().ToUpper() == "PARTIAL");
            bool AllReasons = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Reason")) &&
                        row.Field<string>("Reason").Trim().ToUpper() == "Missing SSN or Account number, or CreateDate mismatch".ToUpper());
            NUnit.Framework.Assert.IsTrue(allStatuses);
            NUnit.Framework.Assert.IsTrue(AllReasons);
        }

        [Test]
        public void AssignStatusesTest_5()  // complete mismatch of SSNs and Accounts - MISSING
        {
            DateTime dt = DateTime.Now;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "111111111", "222222222" },
                                                          null, dt, dt, dt, "ZZZ");
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "999999999", "888888888" }, null, dt);
            NUnit.Framework.Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));
            var rows = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidList.Last());
            bool allStatuses = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Status")) &&
                                               row.Field<string>("Status").Trim().ToUpper() == "MISSING");
            bool AllReasons = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Reason")) &&
                                               row.Field<string>("Reason").Trim().ToUpper() == "MISSING RECORD");
            NUnit.Framework.Assert.IsTrue(allStatuses);
            NUnit.Framework.Assert.IsTrue(AllReasons);
        }

        [Test]
        public void AssignStatusesTest_6_1() // 2 records with null both SSN and Account - NOT FOUND
        {
            DateTime dt = DateTime.Now;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, null, null, dt, dt, dt, "Blank");
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, null, null, dt);
            --recordCount; // will add one more record with the same UID
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, null, null, dt, dt, dt, "Blank");
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, null, null, dt);
            var rows = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidList.Last());
            NUnit.Framework.Assert.AreEqual(2, rows.Count());
            NUnit.Framework.Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));
            bool allStatuses = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Status")) &&
                                               row.Field<string>("Status").Trim().ToUpper() == "NOT FOUND");
            bool AllReasons = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Reason")) && 
                        row.Field<string>("Reason").Trim().ToUpper() == "Both SSN and Account are blank".ToUpper());
            NUnit.Framework.Assert.IsTrue(allStatuses);
        }

        [Test]
        public void AssignStatusesTest_6_2() // in both records one of fields, SSN or Account, is blank in one DB and non-blank in other DB - FOUND
        {
            DateTime dt = DateTime.Now;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, null, new string[] { "0011" }, dt, dt, dt);
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "111111111" }, new string[] { "0011" }, dt);
            --recordCount; // will add one more record with the same UID
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "222222222" }, new string[] { "0022" }, dt, dt, dt);
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "222222222" }, null, dt);
            NUnit.Framework.Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));

            var rows = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidList.Last());
            bool allStatuses = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Status")) &&
                        row.Field<string>("Status").Trim().ToUpper() == "FOUND");
            NUnit.Framework.Assert.IsTrue(allStatuses);
        }

        [Test]
        public void AssignStatusesTest_6_3() // in both records one of fields, SSN or Account, is blank in both DBs - FOUND
        {
            DateTime dt = DateTime.Now;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, null, new string[] { "0011" }, dt, dt, dt);
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, null, new string[] { "0011" }, dt);
            --recordCount; // will add one more record with the same UID
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "222222222" }, null, dt, dt, dt);
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "222222222" }, null, dt);
            NUnit.Framework.Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));

            var rows = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidList.Last());
            bool allStatuses = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Status")) &&
                        row.Field<string>("Status").Trim().ToUpper() == "FOUND");
            NUnit.Framework.Assert.IsTrue(allStatuses);
        }

        [Test]
        public void AssignStatusesTest_7() // both records missing in Tower - MISSING
        {
            DateTime dt = DateTime.Now;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "111111111" },
                                                   new string[] { "0011" }, dt, dt, dt, "BBBB");
            --recordCount;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "222222222" },
                                       new string[] { "0022" }, dt, dt, dt, null, null);
            NUnit.Framework.Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));
            var rows = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidList.Last());
            bool allStatuses = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Status")) &&
                                   row.Field<string>("Status").Trim().ToUpper() == "MISSING");
            bool AllReasons = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Reason")) &&
                                               row.Field<string>("Reason").Trim().ToUpper() == "MISSING RECORD");
            NUnit.Framework.Assert.IsTrue(allStatuses);
            NUnit.Framework.Assert.IsTrue(AllReasons);
        }

        [Test]
        public void AssignStatusesTest_8()  // Status = "MISSING-PROCESSED-T" - MISSING
        {
            DateTime dt = DateTime.Now;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "111111111" },
                                       new string[] { "0011" }, dt, dt, dt, "BBBB", "Good Reason");
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "111111111" }, new string[] { "0011" }, dt);
            --recordCount;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "222222222" },
                           new string[] { "0022" }, dt, dt, dt, "MISSING-PROCESSED-T", "Good Reason");
            AddTowerRecorsdWithManySSNsAndAccounts(recordCount, new string[] { "222222222" }, new string[] { "0022" }, dt);

            Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));
            var rows = ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidList.Last());
            bool allStatuses = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Status")) &&
                       row.Field<string>("Status").Trim().ToUpper() == "MISSING");
            bool AllReasons = rows.All(row => !String.IsNullOrEmpty(row.Field<string>("Reason")) &&
                                               row.Field<string>("Reason").Trim().ToUpper() == "GOOD REASON");

            //DEBUG
            Assert.AreEqual(2, rows.Count(), $"Wrong number of rows with UID [{uidList.Last()}]");
            Assert.AreEqual("MISSING", rows.First().Field<string>("Status")?.ToUpper(), $"First record has wrong status {rows.First().Field<string>("Status")}");
            Assert.AreEqual("MISSING", rows.Last().Field<string>("Status")?.ToUpper(), $"Last record has wrong status {rows.First().Field<string>("Status")}");

            Assert.IsTrue(allStatuses, "Not all statuses have expected value 'MISSING'");
            Assert.IsTrue(AllReasons, $"Not all reasons have expected value 'Good Reason'");
        }

        [Test]
        public void AssignStatusesTest_9()
        {
            DateTime dt = DateTime.Now.AddDays(-3).Date;
            AddKofaxRecorsdWithManySSNsAndAccounts(ref recordCount, new string[] { "999999999" },
                new string[] { "0099" }, dt, dt, dt, "Not Found", "SomeReason");
            Assert.IsTrue((bool)privateObjNightlyRecon.Invoke("AssignStatuses", ds, uidList));
            var row = ds.Tables["FormIDs_To_Process"].AsEnumerable()
                .Where(r => r.Field<String>("UIDNumber") == uidList.Last()).FirstOrDefault();
            Assert.AreEqual("TST" + recordCount.ToString("D8"), row.Field<String>("UIDNumber")?.Trim());
            Assert.AreEqual("NOT FOUND", row.Field<string>("Status")?.Trim().ToUpper());
            Assert.IsTrue( row.Field<string>("Reason") == null );
        }


#region // helper methods
        /// <summary>
        /// Adds to table 'FormIDs_To_Process' one record with Id and UID equal to count, SSN and Account are generated based 
        /// on count. Count is incremented.
        /// </summary>
        /// <param name="count"></param>
        /// <param name="createDate"></param>
        /// <param name="updateDate"></param>
        /// <param name="scanDate"></param>
        /// <param name="status"></param>
        /// <param name="reason"></param>
        /// <returns></returns>
        private DataRow AddOneRecordKofax(ref int count, 
                                       DateTime? createDate = null, 
                                       DateTime? updateDate = null, 
                                       DateTime? scanDate = null, 
                                       string status = null, 
                                       string reason = null)
        {
            ++count;

            string uidStr = "TST" + count.ToString("D8");
            string ssn = count.ToString("D9");
            string acc = count.ToString("D6");
            DataRow row = ds.Tables["FormIDs_To_Process"].Rows.Add(uniqueId++, uidStr, count, ssn, acc, createDate, 
                updateDate, "s24715d", scanDate, status, reason);

            if (!uidList.Contains(uidStr)) { uidList.Add(uidStr); }
            return row;
        }

        private DataRow AddOneRecordTower(int count, DateTime? docdate = null)
        {
            string spStr3 = "TST" + count.ToString("D8");
            string ssn = count.ToString("D9");
            string acc = count.ToString("D6");
            if (docdate.HasValue)
            {
                docdate = docdate.Value.Date;
            }
            return ds.Tables["Tower_MemdocRecords"].Rows.Add(spStr3, docdate, acc, ssn);
        }

        private EnumerableRowCollection<DataRow> AddKofaxRecorsdWithManySSNsAndAccounts(ref int count, 
                                                                   string[] SSNs = null, 
                                                                   string[] accounts = null, 
                                                                   DateTime? createDate = null, 
                                                                   DateTime? updateDate = null, 
                                                                   DateTime? scanDate = null, 
                                                                   string status = null, 
                                                                   string reason = null)
        {
            ++count;
            string uidStr = "TST" + count.ToString("D8");
            if (!uidList.Contains(uidStr)) { uidList.Add(uidStr); }

            if (SSNs != null && SSNs.Length > 0 && accounts != null && accounts.Length > 0)
            {
                foreach (string ssn in SSNs)
                {
                    foreach (string acc in accounts)
                    {
                        ds.Tables["FormIDs_To_Process"].Rows.Add(uniqueId++, uidStr, count, ssn, acc, 
                            createDate, updateDate, "SYSTEM", scanDate, status, reason);
                    }
                }
            }else if(SSNs != null && SSNs.Length > 0)
            {
                foreach (string ssn in SSNs)
                {
                    ds.Tables["FormIDs_To_Process"].Rows.Add(uniqueId++, uidStr, count, ssn, null, createDate, updateDate,
                                                             "SYSTEM", scanDate, status, reason);
                }
            }
            else if (accounts != null && accounts.Length > 0)
            {
                foreach (string acc in accounts)
                {
                    ds.Tables["FormIDs_To_Process"].Rows.Add(uniqueId++, uidStr, count, null, acc, createDate, updateDate, 
                                                             "SYSTEM", scanDate, status, reason);
                }
            }
            else
            {
                ds.Tables["FormIDs_To_Process"].Rows.Add(uniqueId++, uidStr, count, null, null, createDate, updateDate, 
                                                         "SYSTEM", scanDate, status, reason);
            }
            return ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uidStr);
        }

        private EnumerableRowCollection<DataRow> AddTowerRecorsdWithManySSNsAndAccounts(int count, 
                                                                    string[] SSNs = null, 
                                                                    string[] accounts = null, 
                                                                    DateTime? docdate = null)
        {
            string spStr3 = "TST" + count.ToString("D8");

            if (SSNs != null && SSNs.Length > 0  && accounts != null && accounts.Length > 0)
            {
                foreach (string ssn in SSNs)
                {
                    foreach (string acc in accounts)
                    {
                        ds.Tables["Tower_MemdocRecords"].Rows.Add(spStr3, docdate, acc, ssn);                     
                    }
                }
            }
            else if(SSNs != null && SSNs.Length > 0)
            {
                foreach (string ssn in SSNs)
                {
                    ds.Tables["Tower_MemdocRecords"].Rows.Add(spStr3, docdate, null, ssn);                    
                }
            }
            else if (accounts != null && accounts.Length > 0)
            {
                foreach (string acc in accounts)
                {
                    ds.Tables["Tower_MemdocRecords"].Rows.Add(spStr3, docdate, acc, null);                  
                }
            }
            else
            {
                ds.Tables["Tower_MemdocRecords"].Rows.Add(spStr3, docdate, null, null);
            }

            return ds.Tables["Tower_MemdocRecords"].AsEnumerable().Where(r => r.Field<String>("SpStr3") == spStr3);
        }

        /// <summary>
        /// Returns list of strings UIDNumber from table 'FormIDs_To_Process' from records that have Status equal 
        /// one of statuses given as parameter.
        /// </summary>
        /// <param name="ds"></param>
        /// <param name="statuses">Array of statuses</param>
        /// <returns></returns>
        private List<string> GetUIDStringsdBasedOnStatuses(DataSet ds, params string[] statuses)
        {
            return ds.Tables["FormIDs_To_Process"].AsEnumerable()
                .Where(r => statuses.Contains(r.Field<string>("Status")))
                .Select(r => r.Field<string>("UIDNumber")).Distinct().ToList();
        }

        private EnumerableRowCollection<DataRow> GetKofaxRows(string uid)
        {
            return ds.Tables["FormIDs_To_Process"].AsEnumerable().Where(r => r.Field<String>("UIDNumber") == uid);
        }
        private EnumerableRowCollection<DataRow> GetTowerRows(string uid)
        {
            return ds.Tables["Tower_MemdocRecords"].AsEnumerable().Where(r => r.Field<String>("SpStr3") == uid);
        }
        private bool CallIsScanDateMismatch(string uid)
        {
            EnumerableRowCollection<DataRow>  rowsKofax = GetKofaxRows(uid);
            EnumerableRowCollection<DataRow>  rowsTower = GetTowerRows(uid);
            return (bool)privateObjNightlyRecon.Invoke("AreScanDatesMatch", rowsKofax, rowsTower); 
        }

        /// <summary>
        /// Returns list of 2 strings received as arguments. If any of strings is null or empty it is not added to list.
        /// </summary>
        /// <param name="str1"></param>
        /// <param name="str2"></param>
        /// <returns></returns>
        private List<string> ListFromArgs(string str1, string str2)
        {
            List<string> result = new List<string>();
            if (!String.IsNullOrEmpty(str1)) result.Add(str1);
            if (!String.IsNullOrEmpty(str2)) result.Add(str2);
            return result;
        }
        private DateTime? DateTimeFromString(string dt)
        {
            if (String.IsNullOrEmpty(dt)) return null;
            return DateTime.Parse(dt);
        }
#endregion

    }
}
