﻿using System;
using NUnit.Framework;
using System.Data;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestContext = NUnit.Framework.TestContext;
using Assert = NUnit.Framework.Assert;

namespace KofaxIndexRecon.Test
{
    [TestFixture]
    class PartialReportUnitTest
    {
        private PartialReport partialReportObject;
        private PrivateObject privateObjPartialReport;  // PrivateObject to access private methods and fields of class PartialReport

        private StringBuilderWithLineCount report;
        private DataSet dataSet;

        char formFeed = (char)0x0C;

        [OneTimeSetUp]
        public void SetupOnce()
        {
            report = new StringBuilderWithLineCount();
            dataSet = BranchReportUnitTest.CreateEmptyDataSet();
        }

        [SetUp]
        public void Setup()
        {
            BranchReportUnitTest.TruncateTables(ref dataSet);
            report.Clear();
            partialReportObject = new PartialReport(dataSet);
            privateObjPartialReport = new PrivateObject(partialReportObject);
        }

        [Test]
        public void WriteOneRowPartialTest()
        {
            // add 1st row which produces multiple data lines in the report
            DataRow row = BranchReportUnitTest.GetRow(dataSet.Tables["MargoFormErrorReport"], "TST00000001", "0021", 0, "PARTIAL",
                    GetStringList(5, 8), // account list with 5  8-digit accounts
                    GetStringList(8, 9)  /* SSN list with 7   9-digit SSNs */);
            partialReportObject.WriteOneRowPartial(ref report, row);
            Assert.IsNotNull(report);
            // assert that header with "PAGE  1" was added
            string textHeader = File.ReadAllText(Path.Combine(TestContext.CurrentContext.TestDirectory, @"Resources\Header_Partial_page1_03_04_19.txt"));
            textHeader = textHeader.Replace("03/04/2019", DateTime.Now.ToString("MM/dd/yyyy"));
            Assert.IsTrue(report.ToString().Contains(textHeader.Trim()), "Report with 1 row does not contain Partial Report header");
            int lineCount = report.LineCount;

            // insert 2nd row that will produce 1 data line in the report
            row = BranchReportUnitTest.GetRow(dataSet.Tables["MargoFormErrorReport"], "TST00000002", "0021", 0, "PARTIAL", "00000022", "222222222");
            partialReportObject.WriteOneRowPartial(ref report, row);
            // assert that exactly 1 row was added
            Assert.AreEqual(lineCount + 1, report.LineCount, "Wrong count of lines in report with 2 rows");

            // insert dummy data rows until length of 1st page of report is NumberOfLinesPerPageInReport
            row = BranchReportUnitTest.GetRow(dataSet.Tables["MargoFormErrorReport"], "DUMMY", "0021", 0, "PARTIAL", "99", "999999999");
            lineCount = report.LineCount;
            int i = -1;
            for (i = 0; i < Properties.Settings.Default.NumberOfLinesPerPageInReport - lineCount; ++i)
            {
                partialReportObject.WriteOneRowPartial(ref report, row);
            }
            // make sure we haven't completed first page of report by mistake
            Assert.IsFalse(report.ToString().Contains(formFeed.ToString()), 
                "Report with unfinished first page contains FormFeed");
            Assert.AreEqual(Properties.Settings.Default.NumberOfLinesPerPageInReport, report.LineCount, 
                "Wrong count of lines in report with one page with max number of rows");

            // insert next data row which should go to the second page of report
            row = BranchReportUnitTest.GetRow(dataSet.Tables["MargoFormErrorReport"], "TST00000003", "0021", 0, "PARTIAL", "00000033", "333333333");
            partialReportObject.WriteOneRowPartial(ref report, row);

            // assert that header with "PAGE  2" was inserted
            Assert.IsTrue(report.ToString().Contains(formFeed.ToString()), 
                "Report with 2 pages does not contain FormFeed");
            textHeader = textHeader.Replace("PAGE  1", "PAGE  2");
            Assert.IsTrue(report.ToString().Contains(textHeader.TrimStart()), 
                "Report with 2 pages does not contain header with 'PAGE  2'");
        }

        [Test]
        public void GetPartialReportTest_EmptyDataSet()
        {
            DataRow[] partialRows;

            // instantiate PartialReport with empty DataSet
            partialReportObject = new PartialReport(dataSet);
            privateObjPartialReport = new PrivateObject(partialReportObject);
            partialRows = privateObjPartialReport.GetField("_partialRows") as DataRow[];
            Assert.IsNotNull(partialRows);
            Assert.AreEqual(0, partialRows.Length);
            // verify that report has only BLANK_MESSAGE
            report = partialReportObject.GetPartialReport();
            Assert.IsTrue(String.IsNullOrEmpty(report.ToString()));         
        }

        [Test]
        public void GetPartialReportTest_VerifyFirstPage()
        {
            string PARTIAL_HEADER = "POTENTIAL MARGO FORMS SCANNING ERRORS";
            DataRow[] partialRows;
            int count = 0;

            //  Add some rows to table 'MargoFormErrorReport', no matter with which status
            AddRows("0001", "FOUND", ref count, 3);
            partialReportObject = new PartialReport(dataSet);
            privateObjPartialReport = new PrivateObject(partialReportObject);
            partialRows = privateObjPartialReport.GetField("_partialRows") as DataRow[];
            Assert.IsNotNull(partialRows, "partialRows is null");
            Assert.AreEqual(3, partialRows.Length, $"partialRows.Length = {partialRows.Length} while should be 3");

            // verify that report now has header with "PAGE  1"
            report = partialReportObject.GetPartialReport();
            Assert.IsTrue(report.ToString().Contains(PARTIAL_HEADER), "Partial report with 3 data records does not have Partial header");
            Assert.IsTrue(report.ToString().Contains("PAGE  1"), "Partial report with 3 data records does not have 'PAGE  1' in the header");
            Assert.IsFalse(report.ToString().Contains(formFeed.ToString()), "Partial report with 3 data records contains formFeed");
            Assert.IsFalse(report.ToString().Contains("PAGE  2"), "Partial report with 3 data records contains 'PAGE  2' in the header");

            // make exactly NumberOfLinesPerPageInReport lines on the first page
            int lineCount = report.LineCount;
            for (int i = 0; i < Properties.Settings.Default.NumberOfLinesPerPageInReport - lineCount; ++i)
            {
                AddRows("0002", "PARTIAL", ref count, 1);
            }
            partialReportObject = new PartialReport(dataSet);
            report = partialReportObject.GetPartialReport();
            Assert.AreEqual(Properties.Settings.Default.NumberOfLinesPerPageInReport, report.LineCount, 
                $"Tried to insert exactly {Properties.Settings.Default.NumberOfLinesPerPageInReport} lines to the report, but got {report.LineCount}");
            // make sure form feed was not added at the end of page
            Assert.IsFalse(report.ToString().Contains(formFeed.ToString()), $"Report with exactly {Properties.Settings.Default.NumberOfLinesPerPageInReport} lines contains formFeed"); 
        }

        [Test]
        public void GetPartialReportTest_MoreThanOnePage()
        {
            string PARTIAL_HEADER = "POTENTIAL MARGO FORMS SCANNING ERRORS";
            int count = 0;

            // Add NumberOfLinesPerPageInReport rows to DataSet to table "MargoFormErrorReport"
            for (int i = 0; i < Properties.Settings.Default.NumberOfLinesPerPageInReport; ++i)
            {
                AddRows("0001", "PARTIAL", ref count, 1);
            }            

            // verify that report now has header with "PAGE  2"
            partialReportObject = new PartialReport(dataSet);
            report = partialReportObject.GetPartialReport();
            Assert.IsTrue(report.ToString().Contains(PARTIAL_HEADER), "Report does not contain Partial Report header");
            Assert.IsTrue(report.ToString().Contains(formFeed.ToString()), "Report does not contain FormFeed");
            Assert.IsTrue(report.ToString().Contains("PAGE  2"), "Report does not contain 'PAGE  2'");
        }

        #region // helper methods

        private string GetStringList(int numOfAccounts, int numOfDigits = 9)
        {
            // if invalid numOfDigits received set it to dafault value 9
            if (numOfDigits <= 0 || numOfDigits > 12) { numOfDigits = 9; }

            string result = "";
            for (int i = 1; i <= Math.Min(numOfAccounts, 100); ++i)
            {
                result += i.ToString("D" + numOfDigits.ToString()) + "; ";
            }
            result = result.TrimEnd(new char[] { ';', ',', '.', ' ' });
            return result;
        }

        /// <summary>
        /// Adds '<paramref name="numOfRows"/>' rows to DataSet to table MargoFormErrorReport; UID of each row is based on 
        /// '<paramref name="count"/>'. All rows have specified branch and status. 
        /// </summary>
        /// <param name="branch"></param>
        /// <param name="status"></param>
        /// <param name="count"></param>
        /// <param name="numOfRows"></param>
        private void AddRows(string branch, string status, ref int count, int numOfRows)
        {
            DataRow row;
            int i;
            for (i = 1; i <= numOfRows; ++i)
            {
                string uid = "TST" + (count + i).ToString("D8");
                row = BranchReportUnitTest.GetRow(dataSet.Tables["MargoFormErrorReport"], uid, branch, 0, status, "000099", "999999999");
                dataSet.Tables["MargoFormErrorReport"].Rows.Add(row);
            }
            count += i;
        }
        #endregion

    }
}
