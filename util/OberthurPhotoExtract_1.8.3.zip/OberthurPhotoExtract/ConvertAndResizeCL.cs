﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Compression;
using System.Linq;

namespace OberthurPhotoExtract
{
    class ConvertAndResizeCL
    {
        public static Logger log; 
        private readonly string className;

        public ConvertAndResizeCL(Logger logger)
        {
            log = logger;
            className = this.GetType().Name;
        }


        // photoFile - fully qualified name of image file; it is assumed to be not null and it is assumed that the file exists
        public bool ResizeSinglePhoto(string photoFile)
        {
            if (!photoFile.ToLower().EndsWith(".jpg") && !photoFile.ToLower().EndsWith(".jpeg"))
            {
                log.LogError($"{className}.{GetCallerName()}: received non-JPG file name parameter '{photoFile}'");
                return false;
            }
            try
            {
                Image fromImage = Image.FromFile(photoFile);
                Image destImage = ScaleImage(fromImage, Properties.Settings.Default.PhotoWidth, Properties.Settings.Default.PhotoHeight);
                if (destImage == null)
                {
                    throw new Exception($"{className}.{GetCallerName()}: Error scaling image '{photoFile}' ");
                }
                fromImage.Dispose(); // have to release image's lock on file to be able to save
                destImage.Save(photoFile, ImageFormat.Jpeg);
                return true;
            }
            catch (Exception e)
            {
                log.LogError($"Exception in {className}.{GetCallerName()} while processing file '{photoFile}':  {e}");
                return false;
            }
        }

        private Image ScaleImage(Image srcImage, int destWidth, int destHeight)
        {
            try
            {
                Bitmap destImage = new Bitmap(destWidth, destHeight);
                destImage.SetResolution(srcImage.HorizontalResolution, srcImage.VerticalResolution);

                using (Graphics graphics = Graphics.FromImage(destImage))
                {
                    graphics.CompositingMode = CompositingMode.SourceCopy;
                    graphics.CompositingQuality = CompositingQuality.HighQuality;
                    graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    graphics.SmoothingMode = SmoothingMode.HighQuality;
                    graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                    graphics.Clear(Color.White); // this converts background to white
                    graphics.DrawImage(srcImage, 0, 0, destWidth, destHeight);
                }
                return destImage;
            }
            catch (Exception e)
            {
                log.LogError($"Exception in {className}.{GetCallerName()}:  {e}");
                return null;
            }

        }

        public bool CreateZip(string outDirectory)
        {
            log.LogInfo($"{className}.{GetCallerName()}:  Begin");
            string zipFileName = Path.Combine(outDirectory,Properties.Settings.Default.ZipFileName);
            log.LogInfo($"{className}.{GetCallerName()} - Zip file location: {zipFileName}");
            try
            {
                if (File.Exists(zipFileName))
                {
                    File.Delete(zipFileName);
                }

                using (ZipArchive newFile = ZipFile.Open(zipFileName, ZipArchiveMode.Create))
                {
                    var filteredFiles = Directory
                        .EnumerateFiles(outDirectory)
                        .Where(file => (file.ToLower().EndsWith(".txt") ||
                                        file.ToLower().EndsWith(".jpg") ||
                                        file.ToLower().EndsWith(".pcx")) &&
                                       !file.ToLower().EndsWith("_temp.jpg")).ToList();
                    foreach (string fileName in filteredFiles)
                    {
                        newFile.CreateEntryFromFile(fileName, Path.GetFileName(fileName));
                    }
                }

                return true;
            }
            catch (Exception e)
            {
                log.LogError($"Exception in {className}.{GetCallerName()}:  {e}");
                //errorMessage = e.ToString();
                return false;
            }
            finally
            {
                log.LogInfo($"{className}.{GetCallerName()}:  End");
            }
        }

        public string GetCallerName()
        {
            try
            {
                // get call stack
                System.Diagnostics.StackTrace stackTrace = new System.Diagnostics.StackTrace();

                // get calling method name
                return stackTrace.GetFrame(1).GetMethod().Name;
            }
            catch (Exception e)
            {
                log.LogError($"    {className}.GetCallerName failed: " + e.ToString());
                return null;
            }
        }

    }
}
