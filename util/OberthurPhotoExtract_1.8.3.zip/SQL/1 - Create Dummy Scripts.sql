USE MEMBERID
GO

-- ===============================================================================================================
-- Author:        Dmitri Ponarin
-- Last modified: 05/04/2020
-- Description: Creates dummy script of Stored Procedure and table-valued type for initial set up. All necessary 
--              permissions will be granted on this dummy SP. Later actual scripts will replace this dummy procedure 
--              with real one.
-- Benefit: Developers can create scripts as "ALTER" instead of "CREATE", so changing and re-running 
--              script defining actual stored procedure wouldn't erase permissions granted on this SP.
-- -------------------------------------------------------------------------------------------------
-- Special Instructions: Run ONLY ONCE in each environment during initial set up in target database	      
-- ===============================================================================================================

IF TYPE_ID(N'[dbo].[list_varchar]') IS NULL
    EXEC('CREATE TYPE dbo.list_varchar AS TABLE (id varchar(20) NOT NULL PRIMARY KEY);')
GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[OBERTHUR_SELECT_TVP]') AND type in (N'P', N'PC'))
    EXEC('CREATE PROCEDURE dbo.OBERTHUR_SELECT_TVP AS RETURN')
GO

